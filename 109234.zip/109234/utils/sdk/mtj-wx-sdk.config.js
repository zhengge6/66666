module.exports = {
    appKey: "2770bfeafe",
    hasPlugin: !1,
    getLocation: !1,
    getComponentScroll: !1,
    hasABTest: !1,
    hasHeatmap: !1
};