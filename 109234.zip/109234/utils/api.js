var e = require("../@babel/runtime/helpers/regeneratorRuntime"), r = require("../@babel/runtime/helpers/asyncToGenerator"), t = require("../@babel/runtime/helpers/createClass"), u = require("../@babel/runtime/helpers/classCallCheck"), n = s(require("config")), a = s(require("http")), i = (s(require("util")), 
s(require("log")));

function s(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var l = t(function e() {
    u(this, e);
});

l.getSysConfig = function() {
    var t = r(e().mark(function r(t) {
        var u;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, a.default.get({
                    url: "".concat(n.default.baseUrl, "/api/public/config"),
                    params: {
                        key: t
                    }
                });

              case 2:
                return u = e.sent, i.default.info("获取系统配置", u.data[t]), e.abrupt("return", u.data[t] || {});

              case 5:
              case "end":
                return e.stop();
            }
        }, r);
    }));
    return function(e) {
        return t.apply(this, arguments);
    };
}(), module.exports = l;