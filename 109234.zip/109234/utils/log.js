var e, r, t = require("../@babel/runtime/helpers/regeneratorRuntime"), n = require("../@babel/runtime/helpers/objectSpread2"), a = require("../@babel/runtime/helpers/toConsumableArray"), o = require("../@babel/runtime/helpers/asyncToGenerator"), s = require("../@babel/runtime/helpers/createClass"), i = require("../@babel/runtime/helpers/classCallCheck"), l = (e = require("./util")) && e.__esModule ? e : {
    default: e
};

var u = s(function e() {
    var r = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "base";
    i(this, e), this.info = function() {
        for (var t, n = arguments.length, a = new Array(n), o = 0; o < n; o++) a[o] = arguments[o];
        e.storage(a, r.key), (t = console).info.apply(t, a);
    }, this.error = function() {
        for (var t, n = arguments.length, a = new Array(n), o = 0; o < n; o++) a[o] = arguments[o];
        e.storage(a, r.key), (t = console).error.apply(t, a);
    }, this.key = t;
});

r = u, u.storage = function() {
    var e = o(t().mark(function e(r, o) {
        var s;
        return t().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                s = wx.getStorageSync("log.".concat(o)) || [], s = [ n({
                    time: new Date().toString()
                }, r) ].concat(a(s)).slice(0, 100), l.default.setStorage("log.".concat(o), s);

              case 3:
              case "end":
                return e.stop();
            }
        }, e);
    }));
    return function(r, t) {
        return e.apply(this, arguments);
    };
}(), u.info = function() {
    for (var e, t = arguments.length, n = new Array(t), a = 0; a < t; a++) n[a] = arguments[a];
    r.storage(n, "base"), (e = console).info.apply(e, n);
}, u.error = function() {
    for (var e, t = arguments.length, n = new Array(t), a = 0; a < t; a++) n[a] = arguments[a];
    r.storage(n, "base"), (e = console).error.apply(e, n);
}, module.exports = u;