module.exports = {
    setStorage: function(n, o) {
        wx.setStorageSync("".concat("v3", ".").concat(n), o);
    },
    getStorage: function(n) {
        var o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null, t = wx.getStorageSync("".concat("v3", ".").concat(n));
        return "" === t ? o : t;
    },
    info: wx.getAccountInfoSync(),
    device: wx.getDeviceInfo(),
    showLoading: function(n) {
        wx.showLoading({
            title: n,
            mask: !0
        });
    },
    hideLoading: function() {
        wx.hideLoading({
            noConflict: !0
        });
    },
    showInfo: function(n) {
        var o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "none", t = arguments.length > 2 && void 0 !== arguments[2] && arguments[2], e = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 1.5;
        wx.showToast({
            title: n,
            mask: t,
            icon: o,
            duration: 1e3 * e
        });
    },
    back: function() {
        getCurrentPages().length > 1 ? wx.navigateBack() : wx.reLaunch({
            url: "/pages/home/home"
        });
    }
};