require("../@babel/runtime/helpers/Objectentries");

var e, r = require("../@babel/runtime/helpers/regeneratorRuntime"), t = require("../@babel/runtime/helpers/asyncToGenerator"), n = require("../@babel/runtime/helpers/objectSpread2"), a = require("../@babel/runtime/helpers/slicedToArray"), i = require("../@babel/runtime/helpers/createClass"), o = require("../@babel/runtime/helpers/classCallCheck"), s = (u(require("./config")), 
u(require("./util")));

function u(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var c = function(e) {
    e.errMsg.includes("url not in domain list") && ("release" == s.default.info.miniProgram.envVersion ? wx.redirectTo({
        url: "/packages/static-package/pages/error/error?reason=请联系Misaka配置域名"
    }) : wx.redirectTo({
        url: "/packages/static-package/pages/error/error?reason=未打开调试"
    }));
}, l = i(function e() {
    var r = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    o(this, e), this.toJSON = function() {
        return r.data;
    }, this.toString = function() {
        return e.stringify(r.data);
    }, Array.isArray(t) ? this.data = e.parse(t) : this.data = t;
});

l.parse = function() {
    for (var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], r = {}, t = 0; t < e.length; t++) {
        var n = e[t].split(";"), a = n[0].split("="), i = a[0].trim(), o = decodeURIComponent(a[1]);
        r[i] = o;
    }
    return r;
}, l.stringify = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return Object.entries(e).map(function(e) {
        var r = a(e, 2), t = r[0], n = r[1];
        return "".concat(t, "=").concat(encodeURIComponent(n));
    }).join(";");
};

var d = i(function e() {
    o(this, e);
});

e = d, d.__request = function() {
    for (var e = arguments.length, r = new Array(e), t = 0; t < e; t++) r[t] = arguments[t];
    return !1 !== r[0].showLoading && s.default.showLoading("请稍候"), new Promise(function(e, t) {
        wx.request(n(n({}, r[0]), {}, {
            url: r[0].url,
            timeout: 1e3 * r[0].timeout,
            header: n({
                cookie: l.stringify(r[0].cookies || {}),
                appid: s.default.info.miniProgram.appId || "",
                env: s.default.info.miniProgram.envVersion || "",
                version: s.default.info.miniProgram.version || ""
            }, r[0].header || r[0].headers || {}),
            success: function(r) {
                r = "string" == typeof r.data ? r.data.slice(0, 30) : n(n({}, r.data), {}, {
                    cookies: l.parse(r.cookies)
                }), e(r);
            },
            fail: function(e) {
                c(e), t(e);
            },
            complete: function() {
                s.default.hideLoading();
            }
        }));
    });
}, d.get = t(r().mark(function t() {
    var a, i, o, s = arguments;
    return r().wrap(function(r) {
        for (;;) switch (r.prev = r.next) {
          case 0:
            for (a = s.length, i = new Array(a), o = 0; o < a; o++) i[o] = s[o];
            return r.next = 3, e.__request(n(n({}, i[0]), {}, {
                method: "GET",
                data: i[0].params || {}
            }));

          case 3:
            return r.abrupt("return", r.sent);

          case 4:
          case "end":
            return r.stop();
        }
    }, t);
})), d.post = t(r().mark(function t() {
    var i, o, s, u, c = arguments;
    return r().wrap(function(r) {
        for (;;) switch (r.prev = r.next) {
          case 0:
            for (i = c.length, o = new Array(i), s = 0; s < i; s++) o[s] = c[s];
            return u = Object.entries(o[0].params || {}).map(function(e) {
                var r = a(e, 2), t = r[0], n = r[1];
                return "".concat(encodeURIComponent(t), "=").concat(encodeURIComponent(n));
            }).join("&"), r.next = 4, e.__request(n(n({}, o[0]), {}, {
                method: "POST",
                url: "".concat(o[0].url, "?").concat(u),
                data: o[0].body || {}
            }));

          case 4:
            return r.abrupt("return", r.sent);

          case 5:
          case "end":
            return r.stop();
        }
    }, t);
})), module.exports = d;