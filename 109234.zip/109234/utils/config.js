var e, a = require("../@babel/runtime/helpers/objectSpread2"), t = (e = require("util")) && e.__esModule ? e : {
    default: e
};

module.exports = a(a({}, {
    swiperList: [ "https://cdn.loricloud.cn/2025/02/17/574809.webp", "https://cdn.loricloud.cn/2025/02/17/036330.webp" ],
    baseUrl: "https://cx.misaka-network.top",
    notice: "商务合作请在公众号后台留言，打击黑产等违法违规行为！",
    advertiseAppId: "wxb42fe32e6e071916",
    advertiseAppPath: "/pages/advertise/advertise",
    payAppId: "wxb42fe32e6e071916",
    baiduMapKey: "xYjRz7D6pjc3xV516qReaRgcTdoZTyxP",
    tianMapKey: "974d4b6e0a3e2491163c7d193eaa8dd1",
    advertise: {
        wxb42fe32e6e071916: {
            custom: "adunit-2af6b71381dd9394",
            reward: "adunit-bcc86fb2a2db4d18"
        },
        wx0ba7981861be3afc: {
            custom: "adunit-071de53de750648f"
        }
    },
    approveList: [ "wxb42fe32e6e071916" ]
}), t.default.getStorage("config.base", {}));