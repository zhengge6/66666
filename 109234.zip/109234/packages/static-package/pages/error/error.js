var a = require("../../../../packages/static-package/@babel/runtime/helpers/objectSpread2");

Page({
    data: {
        reason: "未知"
    },
    onLoad: function(e) {
        this.setData(a(a({}, e), {}, {
            info: wx.getAccountInfoSync()
        }));
    }
});