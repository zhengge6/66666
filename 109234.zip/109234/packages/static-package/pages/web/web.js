require("../../../../packages/static-package/@babel/runtime/helpers/Objectentries"), 
require("../../../../packages/static-package/@babel/runtime/helpers/Arrayincludes");

var e = require("../../../../packages/static-package/@babel/runtime/helpers/slicedToArray");

Page({
    data: {},
    onLoad: function(a) {
        var t = Object.entries(a).map(function(a) {
            var t = e(a, 2), r = t[0], n = t[1];
            return [ "url" ].includes(r) ? "" : "".concat(r, "=").concat(n);
        }).filter(function(e) {
            return e.length;
        }).join("&");
        console.info("进入Web页面", a), this.setData({
            url: "".concat(a.url, "?").concat(t)
        });
    },
    onShareAppMessage: function() {
        var a = Object.entries(this.options).map(function(a) {
            var t = e(a, 2), r = t[0], n = t[1];
            return "".concat(r, "=").concat(n);
        }).join("&");
        return {
            title: "御坂网络 Misaka",
            path: "/pages/share/share?package=static&path=/web/web&".concat(a),
            imageUrl: "/static/share.png"
        };
    },
    message: function(e) {
        var a = e.detail.data;
        console.info("收到 Web 消息", a);
    }
});