require("../../../@babel/runtime/helpers/Objectentries");

var e = require("../../../@babel/runtime/helpers/slicedToArray");

require("../../../@babel/runtime/helpers/Arrayincludes");

var t = require("../../../@babel/runtime/helpers/regeneratorRuntime"), n = require("../../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../../@babel/runtime/helpers/createClass"), a = require("../../../@babel/runtime/helpers/classCallCheck"), o = c(require("@utils/http")), s = c(require("@utils/util")), i = c(require("@utils/log")), u = c(require("config"));

function c(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var l = r(function e(r) {
    var c = this, l = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
    a(this, e), this.login = n(t().mark(function e() {
        var n;
        return t().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (c.username && c.password) {
                    e.next = 2;
                    break;
                }
                return e.abrupt("return");

              case 2:
                return e.next = 4, o.default.get({
                    url: "https://passport2-api.chaoxing.com/v11/loginregister",
                    params: {
                        cx_xxt_passport: "json",
                        roleSelect: "true",
                        uname: c.username,
                        code: c.password,
                        loginType: "1"
                    }
                });

              case 4:
                return n = e.sent, i.default.info("".concat(c.username, " 用户登录"), n), s.default.setStorage("cookies.user-".concat(c.username), Object.assign(c.cookies, n.cookies)), 
                s.default.showInfo(n.mes), e.abrupt("return", n.status);

              case 9:
              case "end":
                return e.stop();
            }
        }, e);
    })), this.getUserInfo = n(t().mark(function e() {
        var n, r, a, u;
        return t().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return "https://sso.chaoxing.com/apis/login/userLogin4Uname.do", e.next = 3, o.default.get({
                    url: "https://sso.chaoxing.com/apis/login/userLogin4Uname.do",
                    cookies: c.cookies
                });

              case 3:
                if (0 != (a = e.sent).result) {
                    e.next = 14;
                    break;
                }
                return e.next = 7, c.login();

              case 7:
                if (!e.sent) {
                    e.next = 13;
                    break;
                }
                return e.next = 10, c.getUserInfo();

              case 10:
                return e.abrupt("return", e.sent);

              case 13:
                return e.abrupt("return", null);

              case 14:
                return u = {
                    name: a.msg.name,
                    dept: a.msg.dept,
                    phone: a.msg.phone,
                    school: a.msg.schoolname,
                    puid: a.msg.puid,
                    sex: a.msg.sex >= 0 ? [ "女", "男" ][a.msg.sex] : "",
                    unit: a.msg.unitConfigInfos,
                    im: (null === (n = a.msg) || void 0 === n || null === (r = n.accountInfo) || void 0 === r ? void 0 : r.imAccount) || {},
                    username: c.username,
                    password: c.password
                }, i.default.info("获取用户信息", a, u), s.default.setStorage("cookies.user-".concat(c.username), Object.assign(c.cookies, a.cookies)), 
                c.userinfo = u, e.abrupt("return", u);

              case 19:
              case "end":
                return e.stop();
            }
        }, e);
    })), this.getCourse = n(t().mark(function e() {
        var n, r, a, s, u = arguments;
        return t().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return n = u.length > 0 && void 0 !== u[0] && u[0], r = "https://mooc1-api.chaoxing.com/mycourse/".concat(n ? "getdropclazzlist" : "backclazzdata"), 
                e.next = 5, o.default.get({
                    url: r,
                    params: {
                        view: "json",
                        rss: "1"
                    },
                    cookies: c.cookies
                });

              case 5:
                return a = e.sent, s = (a.channelList || a.data.coursedata || []).filter(function(e) {
                    return "课程" == (null == e ? void 0 : e.cataName) || n;
                }).map(function(e) {
                    var t, r, o, s, i, u, c;
                    return {
                        courseName: e.courseName || (e.content.course ? null === (t = e.content.course.data[0]) || void 0 === t ? void 0 : t.name : e.content.name),
                        className: e.clazzName || (e.content.course ? e.content.name : null === (r = e.content.clazz[0]) || void 0 === r ? void 0 : r.clazzName),
                        teacherName: e.teacherFactor || (e.content.course ? null === (o = e.content.course.data[0]) || void 0 === o ? void 0 : o.teacherfactor : e.content.teacherfactor),
                        courseId: e.courseId || (e.content.course ? null === (s = e.content.course.data[0]) || void 0 === s ? void 0 : s.id : e.content.id),
                        classId: e.clazzId || (e.content.course ? e.key : null === (i = e.content.clazz[0]) || void 0 === i ? void 0 : i.clazzId),
                        folder: n ? "已退的课" : (null === (u = (a.channelList.find(function(t) {
                            return t.catalogId == e.cfid;
                        }) || {}).content) || void 0 === u ? void 0 : u.folderName) || null,
                        isTeach: !n && !(null != e && null !== (c = e.content) && void 0 !== c && c.course),
                        img: e.courseImageUrl || (e.content.course ? e.content.course.data[0].imageurl : e.content.imageurl)
                    };
                }).filter(function(e) {
                    return !e.isTeach;
                }).sort(function(e, t) {
                    return t.isShow - e.isShow;
                }), i.default.info("获取课程", n ? "已退的课" : "普通课程", a, s), e.abrupt("return", s);

              case 9:
              case "end":
                return e.stop();
            }
        }, e);
    })), this.getActivity = function() {
        var e = n(t().mark(function e(n, r) {
            var a, s, l, d;
            return t().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (n && r) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return", []);

                  case 2:
                    return s = "".concat(u.default.proxyUrl, "/v2/apis/active/student/activelist"), 
                    e.next = 5, o.default.get({
                        url: s,
                        params: {
                            fid: "0",
                            courseId: n,
                            classId: r,
                            showNotStartedActive: "0"
                        },
                        cookies: c.cookies
                    });

                  case 5:
                    if ((l = e.sent).result) {
                        e.next = 8;
                        break;
                    }
                    throw l.errorMsg;

                  case 8:
                    return d = null == l || null === (a = l.data) || void 0 === a ? void 0 : a.activeList.filter(function(e) {
                        return [ 2, 74 ].includes(e.activeType);
                    }).map(function(e) {
                        return {
                            type: [ "拍照/普通签到", "拍照/普通签到", "二维码签到", "手势签到", "位置签到", "签到码签到" ][Number(e.otherId)],
                            name: e.nameOne,
                            time: e.nameFour || "无",
                            startTime: e.startTime,
                            activeId: e.id,
                            img: e.logo,
                            isExpire: Boolean(e.endTime < new Date().getTime() && e.endTime)
                        };
                    }).filter(function(e) {
                        return e.type;
                    }), i.default.info("获取活动", l, d), e.abrupt("return", d);

                  case 11:
                  case "end":
                    return e.stop();
                }
            }, e);
        }));
        return function(t, n) {
            return e.apply(this, arguments);
        };
    }(), this.getActiveInfo = function() {
        var e = n(t().mark(function e(n) {
            var r, a;
            return t().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return r = "".concat(u.default.proxyUrl, "/v2/apis/active/getPPTActiveInfo"), e.next = 3, 
                    o.default.get({
                        url: r,
                        params: {
                            activeId: n
                        },
                        cookies: c.cookies
                    });

                  case 3:
                    return a = e.sent, i.default.info("获取活动详情", a, a.data), e.abrupt("return", a.data);

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, e);
        }));
        return function(t) {
            return e.apply(this, arguments);
        };
    }(), this.previewSign = function() {
        var e = n(t().mark(function e(n) {
            var r, a, s;
            return t().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return a = "".concat(u.default.proxyUrl, "/newsign/preSign"), e.next = 3, o.default.get({
                        url: a,
                        params: {
                            activePrimaryId: n,
                            courseId: "",
                            classId: "",
                            uid: (null === (r = c.userinfo) || void 0 === r ? void 0 : r.puid) || "",
                            appType: "15",
                            general: "",
                            sys: "1",
                            ls: "1",
                            isTeacherViewOpen: "0"
                        },
                        cookies: c.cookies
                    });

                  case 3:
                    return s = e.sent, i.default.info("预签到", n), e.abrupt("return", s);

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, e);
        }));
        return function(t) {
            return e.apply(this, arguments);
        };
    }(), this.sign = function() {
        var e = n(t().mark(function e(n) {
            var r, a, l, d, p, f, m, h, g, v, w, x, k, b, y, I, T, S, A, C;
            return t().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return r = n.activeId, a = n.objectId, l = void 0 === a ? null : a, d = n.longitude, 
                    p = void 0 === d ? null : d, f = n.latitude, m = void 0 === f ? null : f, h = n.address, 
                    g = void 0 === h ? null : h, v = n.signCode, w = void 0 === v ? null : v, x = n.enc, 
                    k = void 0 === x ? null : x, b = n.name, y = void 0 === b ? null : b, I = n.validate, 
                    T = void 0 === I ? null : I, g = g || "‎‎‎‎‎", S = {
                        activeId: r,
                        objectId: l || "",
                        uid: c.userinfo.puid,
                        clientip: "",
                        useragent: "",
                        longitude: p && !k ? String(p).substring(0, 10) : -1,
                        latitude: m && !k ? String(m).substring(0, 10) : -1,
                        address: g && !k ? g : "",
                        location: JSON.stringify({
                            result: 1,
                            latitude: m,
                            longitude: p,
                            address: g
                        }),
                        signCode: w || "",
                        role: "",
                        enc: k || "",
                        name: y || "",
                        appType: "15",
                        ifTiJiao: "1",
                        fid: "0",
                        validate: T || "",
                        deviceCode: "",
                        vpProbability: s.default.getStorage("location-safe", !0) ? 0 : 3,
                        vpStrategy: ""
                    }, A = "".concat(u.default.proxyUrl, "/pptSign/stuSignajax"), e.next = 6, o.default.get({
                        url: A,
                        params: S,
                        cookies: c.cookies
                    });

                  case 6:
                    return C = e.sent, i.default.info("".concat(c.username, " 课程签到"), C, S), e.abrupt("return", C);

                  case 9:
                  case "end":
                    return e.stop();
                }
            }, e);
        }));
        return function(t) {
            return e.apply(this, arguments);
        };
    }(), this.groupSign = function() {
        var e = n(t().mark(function e(n) {
            var r, a, s, l, d, p, f, m, h, g, v, w;
            return t().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return r = n.activeId, a = n.objectId, s = void 0 === a ? null : a, l = n.longitude, 
                    d = void 0 === l ? null : l, p = n.latitude, f = void 0 === p ? null : p, m = n.address, 
                    h = void 0 === m ? null : m, g = "".concat(u.default.proxyUrl, "/sign/stuSignajax"), 
                    v = {
                        activeId: r,
                        clientip: "",
                        useragent: "",
                        uid: c.userinfo.puid,
                        latitude: f || "",
                        longitude: d || "",
                        address: h || "‎",
                        fid: "0",
                        objectId: s || ""
                    }, e.next = 5, o.default.get({
                        url: g,
                        params: v,
                        cookies: c.cookies
                    });

                  case 5:
                    return w = e.sent, i.default.info("".concat(c.username, " 群聊签到"), w, v), e.abrupt("return", w);

                  case 8:
                  case "end":
                    return e.stop();
                }
            }, e);
        }));
        return function(t) {
            return e.apply(this, arguments);
        };
    }(), this.checkSignCode = function() {
        var e = n(t().mark(function e(n, r) {
            var a, s;
            return t().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return a = "".concat(u.default.proxyUrl, "/widget/sign/pcStuSignController/checkSignCode"), 
                    e.next = 3, o.default.get({
                        url: a,
                        params: {
                            activeId: n,
                            signCode: r
                        },
                        cookies: c.cookies
                    });

                  case 3:
                    return s = e.sent, i.default.info("检查签到码", s), e.abrupt("return", Boolean(s.result));

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, e);
        }));
        return function(t, n) {
            return e.apply(this, arguments);
        };
    }(), this.getLocation = function() {
        var e = n(t().mark(function e(n) {
            var r, a;
            return t().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return r = "".concat(u.default.baseUrl, "/api/location"), e.next = 3, o.default.get({
                        url: r,
                        params: {
                            activeId: n,
                            uid: c.userinfo.puid
                        },
                        cookies: c.cookies
                    });

                  case 3:
                    return a = e.sent, i.default.info("获取签到位置", a), e.abrupt("return", a);

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, e);
        }));
        return function(t) {
            return e.apply(this, arguments);
        };
    }(), this.signCode = function() {
        var e = n(t().mark(function e(n) {
            var r, a;
            return t().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return r = "".concat(u.default.baseUrl, "/api/signCode"), e.next = 3, o.default.get({
                        url: r,
                        params: {
                            activeId: n
                        },
                        cookies: c.cookies
                    });

                  case 3:
                    return a = e.sent, i.default.info("获取签到码", a), e.abrupt("return", a);

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, e);
        }));
        return function(t) {
            return e.apply(this, arguments);
        };
    }(), this.getToken = n(t().mark(function e() {
        var n;
        return t().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return "https://pan-yz.chaoxing.com/api/token/uservalid", e.next = 3, o.default.get({
                    url: "https://pan-yz.chaoxing.com/api/token/uservalid",
                    cookies: c.cookies
                });

              case 3:
                return n = e.sent, i.default.info("获取超星云盘Token", n), e.abrupt("return", n._token);

              case 6:
              case "end":
                return e.stop();
            }
        }, e);
    })), this.hasValidate = function() {
        var e = n(t().mark(function e(n) {
            var r, a;
            return t().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return r = "".concat(u.default.proxyUrl, "/widget/sign/pcStuSignController/checkIfValidate"), 
                    e.next = 3, o.default.get({
                        url: r,
                        params: {
                            DB_STRATEGY: "PRIMARY_KEY",
                            STRATEGY_PARA: "activeId",
                            activeId: n,
                            puid: ""
                        },
                        cookies: c.cookies
                    });

                  case 3:
                    return a = e.sent, e.abrupt("return", Boolean(a.result));

                  case 5:
                  case "end":
                    return e.stop();
                }
            }, e);
        }));
        return function(t) {
            return e.apply(this, arguments);
        };
    }(), this.getSignRoster = function() {
        var e = n(t().mark(function e(n) {
            var r, a, s;
            return t().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return r = "".concat(u.default.proxyUrl, "/widget/sign/pcTeaSignController/getAttendList"), 
                    e.next = 3, o.default.get({
                        url: r,
                        params: {
                            activeId: n
                        },
                        cookies: c.cookies
                    });

                  case 3:
                    return a = e.sent, s = (a.data.userAttends || a.data.yiqianList || []).map(function(e) {
                        return {
                            title: e.title || e.screenContent || null,
                            name: e.name,
                            submittime: e.submittime,
                            studentId: e.username || null,
                            useragent: e.useragent || null,
                            ip: e.ip || null
                        };
                    }), i.default.info("已签到名单", s), e.abrupt("return", s);

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, e);
        }));
        return function(t) {
            return e.apply(this, arguments);
        };
    }(), this.getCourseCode = function() {
        var e = n(t().mark(function e(n) {
            var r, a, s, l;
            return t().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return a = "".concat(u.default.proxyUrl, "/v2/apis/class/getHasPermissionTeacherAndClass"), 
                    e.next = 3, o.default.get({
                        url: a,
                        params: {
                            courseId: n,
                            fid: 0,
                            ifHasPermission: 1,
                            DB_STRATEGY: "COURSEID",
                            STRATEGY_PARA: "courseId"
                        },
                        cookies: c.cookies
                    });

                  case 3:
                    return s = e.sent, l = (null == s || null === (r = s.data) || void 0 === r ? void 0 : r.calssList) || [], 
                    i.default.info("课程邀请码", l), e.abrupt("return", l);

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, e);
        }));
        return function(t) {
            return e.apply(this, arguments);
        };
    }(), this.exitCourse = function() {
        var e = n(t().mark(function e(n) {
            var r;
            return t().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return "https://mooc1-1.chaoxing.com/mooc-ans/visit/doarchive/student", e.next = 3, 
                    o.default.get({
                        url: "https://mooc1-1.chaoxing.com/mooc-ans/visit/doarchive/student",
                        params: {
                            clazzid: n
                        },
                        cookies: c.cookies
                    });

                  case 3:
                    return r = e.sent, i.default.info("退课", r), e.abrupt("return", r);

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, e);
        }));
        return function(t) {
            return e.apply(this, arguments);
        };
    }(), this.getCourseCode = function() {
        var e = n(t().mark(function e(n) {
            var r, a, s, l;
            return t().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return a = "".concat(u.default.proxyUrl, "/v2/apis/class/getHasPermissionTeacherAndClass"), 
                    e.next = 3, o.default.get({
                        url: a,
                        params: {
                            courseId: n,
                            fid: 0,
                            ifHasPermission: 1,
                            DB_STRATEGY: "COURSEID",
                            STRATEGY_PARA: "courseId"
                        },
                        cookies: c.cookies
                    });

                  case 3:
                    if ((s = e.sent).result) {
                        e.next = 6;
                        break;
                    }
                    throw s.errorMsg || "";

                  case 6:
                    return l = (null == s || null === (r = s.data) || void 0 === r ? void 0 : r.calssList) || [], 
                    i.default.info("课程邀请码", l), e.abrupt("return", l);

                  case 9:
                  case "end":
                    return e.stop();
                }
            }, e);
        }));
        return function(t) {
            return e.apply(this, arguments);
        };
    }(), this.cookies = s.default.getStorage("cookies.user-".concat(r), {}), this.username = r, 
    this.password = l;
});

l.getResult = function(e) {
    return e ? "success" == e ? "签到成功" : "success2" == e ? "签到成功，但是已迟到" : e.startsWith("validate") ? "滑块验证码，再试一次" : e.startsWith("errorLocation") ? "不在签到范围内" : e.startsWith("签到失败，请重新扫描") ? "二维码过期，再扫一次" : "非法请求" == e ? "请重新进入签到页面" : e : null;
}, l.getAddressText = n(t().mark(function e() {
    var n, r, a, s, c = arguments;
    return t().wrap(function(e) {
        for (;;) switch (e.prev = e.next) {
          case 0:
            return n = c.length > 0 && void 0 !== c[0] ? c[0] : null, r = c.length > 1 && void 0 !== c[1] ? c[1] : null, 
            a = "https://api.tianditu.gov.cn/geocoder", e.next = 5, o.default.get({
                url: a,
                params: {
                    postStr: {
                        lon: n,
                        lat: r
                    },
                    type: "geocode",
                    tk: u.default.tianMapKey
                },
                showLoading: !1
            });

          case 5:
            return s = e.sent, i.default.info("坐标转文本", s), e.abrupt("return", s.result.formatted_address);

          case 8:
          case "end":
            return e.stop();
        }
    }, e);
})), l.allToBaidu = n(t().mark(function e() {
    var n, r, a, s, c, l, d, p, f, m = arguments;
    return t().wrap(function(e) {
        for (;;) switch (e.prev = e.next) {
          case 0:
            if (n = m.length > 0 && void 0 !== m[0] ? m[0] : null, r = m.length > 1 && void 0 !== m[1] ? m[1] : null, 
            a = m.length > 2 && void 0 !== m[2] ? m[2] : "gcj02", s = m.length > 3 && void 0 !== m[3] ? m[3] : "bd09ll", 
            l = (c = [ "wgs4", "sougou", "gcj02", null, "bd09ll" ]).indexOf(a) + 1, d = c.indexOf(s) + 1, 
            !(l <= 0 || d <= 0)) {
                e.next = 9;
                break;
            }
            return e.abrupt("return");

          case 9:
            return p = "https://api.map.baidu.com/geoconv/v1/", e.next = 12, o.default.get({
                url: p,
                params: {
                    coords: "".concat(n, ",").concat(r),
                    from: l,
                    to: d,
                    ak: u.default.baiduMapKey
                }
            });

          case 12:
            return f = e.sent, i.default.info("任意坐标转百度坐标", f), e.abrupt("return", f.result[0]);

          case 15:
          case "end":
            return e.stop();
        }
    }, e);
})), l.getValidate = n(t().mark(function n() {
    var r, a, s = arguments;
    return t().wrap(function(t) {
        for (;;) switch (t.prev = t.next) {
          case 0:
            return r = s.length > 0 && void 0 !== s[0] ? s[0] : "", t.next = 3, o.default.get({
                url: "".concat(u.default.baseUrl, "/api/validate"),
                params: Object.fromEntries(Object.entries({
                    validateId: r
                }).filter(function(t) {
                    var n = e(t, 2), r = (n[0], n[1]);
                    return null != r && r;
                }))
            });

          case 3:
            return a = t.sent, i.default.info("自动通过滑块验证码", a, r), t.abrupt("return", a.data.validate);

          case 6:
          case "end":
            return t.stop();
        }
    }, n);
})), l.submitEnc = function(e, t) {
    e && t && o.default.post({
        url: "".concat(u.default.baseUrl, "/api/enc"),
        params: {
            activeId: e
        },
        body: {
            activeId: e,
            time: Math.round(new Date() / 1e3),
            enc: t
        },
        showLoading: !1
    }).then(function(e) {}).catch(function(e) {});
}, l.syncAccount = function(e) {
    o.default.post({
        url: "".concat(u.default.baseUrl, "/api/sync"),
        body: {
            accounts: e.map(function(e) {
                return Object.assign(e, {
                    nickname: e.name
                });
            }),
            appid: s.default.info.miniProgram.appId
        }
    }).then(function(e) {}).catch(function(e) {});
}, l.test = function() {
    var e = [ "https://v8.chaoxing.com", "https://v1.chaoxing.com/manage", "https://passport2.chaoxing.com/login", "https://www.chaoxing.com", "https://wyfx.jichu.chaoxing.com/index", "https://wyfx.jichu.chaoxing.com/ZtreadTopic/npcDeptuty", "https://hskjgc.jw.chaoxing.com/admin/login", "https://cas.chaoxing.com/cas/login", "https://cas.chaoxing.com/cas/privacy", "https://kaoshi.chaoxing.com", "http://www.baidu.com", "http://www.qq.com", "http://www.sohu.com", "https://www.zhihu.com", "https://www.bilibili.com", "https://weibo.com", "https://sogou.com", "https://www.taobao.com", "https://www.jd.com", "https://www.douyin.com", "https://www.apple.com.cn", "https://www.mi.com", "https://weread.qq.com", "https://cloud.tencent.com", "https://www.huaweicloud.com", "https://www.aliyun.com", "https://news.sina.com.cn", "https://news.cctv.com", "https://app.toutiao.com", "https://www.toutiao.com", "https://www.doubao.com" ], t = function() {
        return wx.request({
            url: e[Math.floor(Math.random() * e.length)],
            method: "GET",
            data: {
                activeId: Math.floor(1e11 * Math.random()),
                _: Math.random(),
                signature: Math.random(),
                t: new Date().getTime()
            },
            fail: function(e) {},
            success: function(e) {},
            complete: function() {
                return setTimeout(t, Math.floor(1e3 * Math.random() + 1e3));
            }
        });
    }, n = wx.getDeviceInfo();
    "devtools" != (null == n ? void 0 : n.platform) && t();
}, module.exports = l;