var e = require("../../../@babel/runtime/helpers/regeneratorRuntime"), r = require("../../../@babel/runtime/helpers/objectSpread2"), t = require("../../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../../@babel/runtime/helpers/createClass"), s = require("../../../@babel/runtime/helpers/classCallCheck"), u = (i(require("@utils/http")), 
i(require("@utils/util"))), a = (i(require("@utils/log")), i(require("api")));

function i(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var o = new (n(function n() {
    var i = this;
    s(this, n), this.users = [], this.apis = {}, this.nowIndex = 0, this.add = function() {
        var n = t(e().mark(function t(n, s) {
            var o;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (n && s) {
                        e.next = 3;
                        break;
                    }
                    return u.default.showInfo("账号或密码为空"), e.abrupt("return", !1);

                  case 3:
                    if (!i.users.some(function(e) {
                        return e.username == n;
                    })) {
                        e.next = 6;
                        break;
                    }
                    return u.default.showInfo("用户已存在"), e.abrupt("return", !1);

                  case 6:
                    return o = new a.default(n, s), e.next = 9, o.login();

                  case 9:
                    if (e.sent) {
                        e.next = 11;
                        break;
                    }
                    return e.abrupt("return", !1);

                  case 11:
                    return e.t0 = i.users, e.t1 = r, e.t2 = r, e.t3 = {}, e.next = 17, o.getUserInfo();

                  case 17:
                    return e.t4 = e.sent, e.t5 = (0, e.t2)(e.t3, e.t4), e.t6 = {}, e.t7 = {
                        username: n,
                        password: s
                    }, e.t8 = (0, e.t1)(e.t5, e.t6, e.t7), e.t0.push.call(e.t0, e.t8), a.default.syncAccount(i.users), 
                    u.default.setStorage("user.list", i.users), i.apis[n] = o, e.abrupt("return", !0);

                  case 27:
                  case "end":
                    return e.stop();
                }
            }, t);
        }));
        return function(e, r) {
            return n.apply(this, arguments);
        };
    }(), this.get = t(e().mark(function r() {
        var t, n, s, u = arguments;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (n = u.length > 0 && void 0 !== u[0] ? u[0] : null, s = u.length > 1 && void 0 !== u[1] ? u[1] : null, 
                n) {
                    e.next = 4;
                    break;
                }
                return e.abrupt("return", i.apis[null === (t = i.users[i.nowIndex]) || void 0 === t ? void 0 : t.username] || null);

              case 4:
                if (!Object.keys(i.apis).includes(n)) {
                    e.next = 6;
                    break;
                }
                return e.abrupt("return", i.apis[n]);

              case 6:
                return e.next = 8, i.add(n, s);

              case 8:
                if (!e.sent) {
                    e.next = 10;
                    break;
                }
                return e.abrupt("return", i.apis[n]);

              case 10:
              case "end":
                return e.stop();
            }
        }, r);
    })), this.getUserInfo = t(e().mark(function r() {
        var t, n = arguments;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, i.get.apply(i, n);

              case 2:
                if (t = e.sent) {
                    e.next = 5;
                    break;
                }
                return e.abrupt("return", {});

              case 5:
                if (Object.keys(t.userinfo || {}).length) {
                    e.next = 8;
                    break;
                }
                return e.next = 8, t.getUserInfo();

              case 8:
                return e.abrupt("return", t.userinfo);

              case 9:
              case "end":
                return e.stop();
            }
        }, r);
    })), this.switch = t(e().mark(function r() {
        var t, n, s = arguments;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (t = s.length > 0 && void 0 !== s[0] ? s[0] : 0, n = i.apis[i.users[t].username], 
                t != i.nowIndex) {
                    e.next = 5;
                    break;
                }
                return u.default.showInfo("您已经登录该账号了"), e.abrupt("return");

              case 5:
                return e.next = 7, n.login();

              case 7:
                if (e.sent) {
                    e.next = 12;
                    break;
                }
                return u.default.showInfo("登录失败，自动退出"), e.next = 11, i.delete(i.users[t].username);

              case 11:
                return e.abrupt("return", i.nowIndex);

              case 12:
                return u.default.showInfo("切换成功"), u.default.setStorage("now.index", t), i.nowIndex = t, 
                e.abrupt("return", t);

              case 16:
              case "end":
                return e.stop();
            }
        }, r);
    })), this.delete = function() {
        var r = t(e().mark(function r(t) {
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    i.users = i.users.filter(function(e) {
                        return e.username != t;
                    }), i.nowIndex = Math.max(0, Math.min(i.nowIndex, i.users.length - 1)), u.default.setStorage("user.list", i.users), 
                    u.default.setStorage("now.index", i.nowIndex);

                  case 4:
                  case "end":
                    return e.stop();
                }
            }, r);
        }));
        return function(e) {
            return r.apply(this, arguments);
        };
    }(), this.users = u.default.getStorage("user.list", []), this.nowIndex = u.default.getStorage("now.index", 0), 
    this.users.forEach(function() {
        var r = t(e().mark(function r(t, n) {
            var s, u;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return s = i.apis[t.username] = new a.default(t.username, t.password), e.next = 3, 
                    s.getUserInfo();

                  case 3:
                    if (!(u = e.sent)) {
                        e.next = 8;
                        break;
                    }
                    i.users[n] = Object.assign(t, u), e.next = 10;
                    break;

                  case 8:
                    return e.next = 10, i.delete(t.username);

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, r);
        }));
        return function(e, t) {
            return r.apply(this, arguments);
        };
    }());
}))();

module.exports = o;