var e = require("../../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../../@babel/runtime/helpers/createClass"), n = require("../../../@babel/runtime/helpers/classCallCheck"), a = u(require("config")), s = u(require("@utils/http")), o = u(require("@utils/util")), i = u(require("@utils/log"));

function u(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var c = r(function r(u) {
    var c = this, d = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
    n(this, r), this.login = t(e().mark(function t() {
        var r, n;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (c.username && c.password) {
                    e.next = 2;
                    break;
                }
                return e.abrupt("return");

              case 2:
                return r = {
                    grant_type: "password",
                    username: c.username,
                    password: c.password
                }, "https://a1-vip6.easemob.com/cx-dev/cxstudy/token", e.next = 6, s.default.post({
                    url: "https://a1-vip6.easemob.com/cx-dev/cxstudy/token",
                    body: r
                });

              case 6:
                return n = e.sent, c.token = n.access_token, o.default.setStorage("im-token-".concat(c.username), c.token), 
                c.updatetime = new Date().getTime(), o.default.setStorage("im-token-updatetime-".concat(c.username), c.updatetime), 
                i.default.info("登录", n), e.abrupt("return", c.token);

              case 13:
              case "end":
                return e.stop();
            }
        }, t);
    })), this.checkLogin = t(e().mark(function t() {
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (c.token) {
                    e.next = 4;
                    break;
                }
                return i.default.info("自动登录 未登录"), e.next = 4, c.login();

              case 4:
                if (!(c.updatetime + 864e5 <= new Date().getTime())) {
                    e.next = 8;
                    break;
                }
                return i.default.info("自动登录 登录过期"), e.next = 8, c.login();

              case 8:
              case "end":
                return e.stop();
            }
        }, t);
    })), this.getCourse = t(e().mark(function t() {
        var r, n, a;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, c.checkLogin();

              case 2:
                return r = "https://a1-vip6.easemob.com/cx-dev/cxstudy/users/".concat(c.username, "/joined_chatgroups"), 
                e.next = 5, s.default.get({
                    url: r,
                    params: {
                        detail: !0,
                        version: "v3",
                        pagenum: "1",
                        pagesize: "10000"
                    },
                    headers: {
                        Authorization: "Bearer ".concat(c.token)
                    }
                });

              case 5:
                return n = e.sent, a = n.data.map(function(e) {
                    return "面对面群聊" == e.description ? Object.assign(e, {
                        description: null
                    }) : Object.assign(e, {
                        description: JSON.parse(e.description || "{}")
                    });
                }).map(function(e) {
                    var t, r, n, a, s, o, i;
                    return {
                        courseName: (null === (t = e.description) || void 0 === t || null === (r = t.courseInfo) || void 0 === r ? void 0 : r.coursename) || e.name,
                        className: "IM 班级群聊",
                        teacherName: "",
                        courseId: ((null === (n = e.description) || void 0 === n ? void 0 : n.courseInfo) || {})["courseid "] || "",
                        classId: (null === (a = e.description) || void 0 === a || null === (s = a.courseInfo) || void 0 === s ? void 0 : s.classid) || "",
                        folder: "",
                        isTeach: "owner" == e.permission,
                        img: (null === (o = e.description) || void 0 === o || null === (i = o.courseInfo) || void 0 === i ? void 0 : i.imageUrl) || ""
                    };
                }).filter(function(e) {
                    return e.courseId && e.classId;
                }), i.default.info("获取IM加入的群", a, n), e.abrupt("return", a);

              case 9:
              case "end":
                return e.stop();
            }
        }, t);
    })), this.connect = t(e().mark(function r() {
        var n;
        return e().wrap(function(r) {
            for (;;) switch (r.prev = r.next) {
              case 0:
                (n = c.ws = wx.connectSocket({
                    url: "".concat(a.default.imUrl, "/api/im/").concat(c.username, "/").concat(c.token, "/ws")
                })).onClose(function() {
                    var r = t(e().mark(function t(r) {
                        return e().wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                i.default.info("连接关闭", r);

                              case 1:
                              case "end":
                                return e.stop();
                            }
                        }, t);
                    }));
                    return function(e) {
                        return r.apply(this, arguments);
                    };
                }()), n.onMessage(function() {
                    var r = t(e().mark(function t(r) {
                        return e().wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                i.default.info("收到消息", r);

                              case 1:
                              case "end":
                                return e.stop();
                            }
                        }, t);
                    }));
                    return function(e) {
                        return r.apply(this, arguments);
                    };
                }());

              case 3:
              case "end":
                return r.stop();
            }
        }, r);
    })), this.username = u, this.password = d, this.token = o.default.getStorage("im-token-".concat(this.username), null), 
    this.updatetime = o.default.getStorage("im-token-updatetime-".concat(this.username), 0);
});

module.exports = c;