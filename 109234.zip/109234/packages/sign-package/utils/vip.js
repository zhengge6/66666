var e = require("../../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../../@babel/runtime/helpers/createClass"), a = require("../../../@babel/runtime/helpers/classCallCheck"), n = o(require("@utils/http")), i = o(require("@utils/util")), u = o(require("@utils/log")), l = o(require("config"));

function o(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var s = r(function e() {
    a(this, e);
});

s.getVipState = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null, t = Math.max(i.default.getStorage("vip.user-expire-all", 0), i.default.getStorage("vip.user-expire-".concat(e || "all"), 0)), r = Math.floor(new Date().getTime() / 1e3), a = i.default.getStorage("safe.lasttime", 0);
    return a > r ? (wx.clearStorage(), u.default.info("时间校验异常，请重新进入", r, a), !1) : (i.default.setStorage("safe.lasttime", r), 
    t > r);
}, s.getVipExpire = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null, t = Math.max(i.default.getStorage("vip.user-expire-all", 0), i.default.getStorage("vip.user-expire-".concat(e), 0)), r = Math.floor(new Date().getTime() / 1e3);
    if (t < r) return "已过期";
    if (t - r < 60) return "".concat(t - r, "秒");
    var a = new Date(1e3 * t);
    return "".concat(a.getFullYear(), "/").concat(a.getMonth() + 1, "/").concat(a.getDate()) + " " + "".concat(("0" + String(a.getHours())).slice(-2), ":").concat(("0" + String(a.getMinutes())).slice(-2));
}, s.convertVipKey = function() {
    var r = t(e().mark(function t(r) {
        var a;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, n.default.post({
                    url: "".concat(l.default.baseUrl, "/api/vip/convert"),
                    params: {
                        appid: i.default.info.miniProgram.appId
                    },
                    body: {
                        key: r,
                        appid: i.default.info.miniProgram.appId
                    }
                });

              case 2:
                return a = e.sent, i.default.showInfo(a.msg), u.default.info("兑换会员", a, r), 0 == a.status && a.data.username && i.default.setStorage("vip.user-expire-".concat(a.data.username), a.data.exp), 
                e.abrupt("return", a);

              case 7:
              case "end":
                return e.stop();
            }
        }, t);
    }));
    return function(e) {
        return r.apply(this, arguments);
    };
}(), s.adGetVip = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
    if (!e || e == i.default.info.miniProgram.appId) {
        var t = new Date(), r = new Date(t.getFullYear(), t.getMonth(), t.getDate(), 23, 59, 59, 999);
        i.default.setStorage("vip.user-expire-all", Math.floor(r.getTime() / 1e3)), i.default.showInfo("获得奖励");
    }
}, module.exports = s;