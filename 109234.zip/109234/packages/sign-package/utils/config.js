var e = require("../../../@babel/runtime/helpers/objectSpread2"), t = i(require("@utils/ci.config")), a = i(require("@utils/config")), s = i(require("@utils/util"));

function i(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

module.exports = e(e(e(e(e({}, a.default), {
    baseUrl: "https://cx.misaka-network.top",
    proxyUrl: "https://cx.misaka-network.top/proxy",
    imUrl: "https://cx.misaka-network.top",
    shareAppId: "wxb42fe32e6e071916",
    shareAppPath: "/pages/share/share",
    whiteList: [ "wx0ba7981861be3afc" ],
    swiperList: [ "/packages/sign-package/static/swiper/1.png", "/packages/sign-package/static/swiper/2.png" ],
    notice: "本小程序由公众号御坂网络Misaka免费提供，谨防倒卖！"
}), t.default), s.default.getStorage("config.base", {})), s.default.getStorage("config.sign", {}));