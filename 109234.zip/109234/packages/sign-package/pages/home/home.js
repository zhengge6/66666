var e, a, t = s(require("@utils/util")), i = (s(require("@utils/log")), s(require("../../utils/config"))), r = s(require("../../utils/user")), u = s(require("../../utils/api"));

function s(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Page({
    data: {
        swiperList: i.default.swiperList,
        notice: i.default.notice,
        path: "/packages/sign-package",
        disabled: "wxb42fe32e6e071916" != t.default.info.miniProgram.appId && "release" == t.default.info.miniProgram.envVersion,
        adId: null === (e = i.default.advertise[t.default.info.miniProgram.appId]) || void 0 === e ? void 0 : e.custom,
        watermark: (null === (a = r.default.users[0]) || void 0 === a ? void 0 : a.username) || ""
    },
    onLoad: function(e) {
        wx.hideHomeButton(), t.default.setStorage("home-switch", Object.assign(t.default.getStorage("home-switch", {}), {
            "爱学习": !0
        })), u.default.test();
    },
    navigate: function(e) {
        wx.navigateTo({
            url: e.currentTarget.dataset.url
        });
    },
    onShareAppMessage: function() {
        return {
            title: "御坂网络 Misaka",
            imageUrl: "/static/share.png",
            path: "/packages/sign-package/pages/home/home"
        };
    }
});