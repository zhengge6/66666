var e = require("../../../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../../../@babel/runtime/helpers/objectSpread2"), a = require("../../../../@babel/runtime/helpers/slicedToArray");

require("../../../../@babel/runtime/helpers/Objectentries");

var n = require("../../../../@babel/runtime/helpers/defineProperty"), i = l(require("../../utils/config")), o = l(require("@utils/util"));

l(require("@utils/log"));

function l(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var u = {};

Page({
    data: {
        proxy: [ {
            label: "广州阿里云",
            value: "https://cx.misaka-network.top/proxy",
            desc: "默认服务器，小白请勿修改"
        }, {
            label: "境外 Cloudflare",
            value: "https://proxy.yangrucheng.top/mobilelearn.chaoxing.com",
            desc: "延迟较高"
        }, {
            label: "湘大 CSN",
            value: "https://rdhszg.xtu.edu.cn/proxy",
            desc: "使用 Frp 搭建，出口 IP 在湘潭"
        } ],
        setting: [ {
            label: "IM地址",
            value: "",
            key: "imUrl",
            placeholder: "留空即为默认，示例 https://im.com"
        }, {
            label: "百度地图 Key",
            value: "",
            key: "baiduMapKey",
            placeholder: "留空即为默认，详见百度地图开放平台"
        } ]
    },
    onLoad: function(e) {
        var t = this;
        u = o.default.getStorage("config.sign", {}), this.data.setting.forEach(function(e, r) {
            return t.setData(n({
                proxyUrl: i.default.proxyUrl
            }, "setting[".concat(r, "].value"), u[e.key] || ""));
        });
    },
    onShow: function() {
        u = o.default.getStorage("config.sign", {}), this.setData({
            version: o.default.info.miniProgram.version || o.default.info.miniProgram.envVersion,
            location: o.default.getStorage("location-safe", !0)
        });
    },
    onReady: function() {
        var i = this;
        this.save = function(e) {
            i.data.setting.forEach(function(e) {
                var t = e.value.trim() || "";
                t && (u[e.key] = t);
            }), o.default.setStorage("config.sign", Object.fromEntries(Object.entries(u).filter(function(e) {
                var t = a(e, 2), r = (t[0], t[1]);
                return null != r && r;
            })));
        }, this.input = function(e) {
            i.setData(n({}, "setting[".concat(e.currentTarget.dataset.index, "].value"), e.detail.value), i.save);
        }, this.close = function(e) {
            wx.exitMiniProgram();
        }, this.changeProxy = function(e) {
            o.default.setStorage("config.sign", r(r({}, o.default.getStorage("config.sign", {})), {}, {
                proxyUrl: e.detail.value
            })), o.default.showInfo("请点击下方保存修改");
        }, this.copy = function() {
            wx.setClipboardData({
                data: "https://doc.micono.eu.org"
            });
        }, this.location = function() {
            var r = t(e().mark(function t(r) {
                var a;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (a = r.detail.value) {
                            e.next = 6;
                            break;
                        }
                        return e.next = 4, wx.showModal({
                            title: "确认关闭吗？",
                            content: "关闭后您的位置签到均会标记为使用虚拟定位作弊"
                        });

                      case 4:
                        e.sent.confirm || (a = !0);

                      case 6:
                        o.default.setStorage("location-safe", a), i.setData({
                            location: a
                        });

                      case 8:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }));
            return function(e) {
                return r.apply(this, arguments);
            };
        }();
    }
});