require("../../../../@babel/runtime/helpers/Objectentries");

var t, e, a = require("../../../../@babel/runtime/helpers/defineProperty"), n = require("../../../../@babel/runtime/helpers/objectSpread2"), r = require("../../../../@babel/runtime/helpers/toConsumableArray"), i = require("../../../../@babel/runtime/helpers/regeneratorRuntime"), o = require("../../../../@babel/runtime/helpers/slicedToArray"), s = require("../../../../@babel/runtime/helpers/asyncToGenerator"), c = h(require("../../utils/api")), u = h(require("../../utils/vip")), d = h(require("../../utils/config")), l = h(require("../../utils/user")), f = h(require("@utils/util")), p = h(require("@utils/log"));

function h(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var g = null, v = {};

Page({
    data: {
        types: [ "拍照学习", "普通学习", "二维码学习", "手势学习", "位置学习", "考勤码学习" ],
        adId: null === (t = d.default.advertise[f.default.info.miniProgram.appId]) || void 0 === t ? void 0 : t.custom,
        watermark: (null === (e = l.default.users[0]) || void 0 === e ? void 0 : e.username) || "",
        accounts: [],
        checked: [],
        fileList: [],
        srcList: [],
        location: {},
        info: {},
        roster: [],
        host: d.default.baseUrl,
        loading: !0,
        locationSafe: f.default.getStorage("location-safe", !0)
    },
    onLoad: function(t) {
        var e = this;
        return s(i().mark(function a() {
            return i().wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    return p.default.info("签到页", t), e.getUserLocation(), a.next = 4, l.default.get(t.username, t.password);

                  case 4:
                    return g = a.sent, a.next = 7, l.default.getUserInfo(t.username, t.password);

                  case 7:
                    if (v = a.sent, e.setData({
                        accounts: l.default.users,
                        vip: u.default.getVipState(v.username),
                        checked: e.data.checked.length ? e.data.checked : [ v ],
                        approve: d.default.approveList.includes(f.default.info.miniProgram.appId),
                        options: t,
                        loading: Boolean(t.activeId)
                    }), t.activeId) {
                        a.next = 11;
                        break;
                    }
                    return a.abrupt("return");

                  case 11:
                    Promise.all([ g.previewSign(t.activeId), g.hasValidate(t.activeId), g.getActiveInfo(t.activeId), g.getToken() ]).then(function(t) {
                        var a = o(t, 4), n = (a[0], a[1]), r = a[2], i = a[3];
                        return e.setData({
                            hasValidate: n,
                            info: r,
                            token: i,
                            loading: !1
                        });
                    }).catch(function(t) {
                        p.default.error(t);
                    }), e.getSignRoster(t.activeId);

                  case 13:
                  case "end":
                    return a.stop();
                }
            }, a);
        }))();
    },
    getUserLocation: function() {
        var t = this;
        this.data.location.longitude && this.data.location.latitude || wx.getLocation({
            type: "gcj02"
        }).then(function(e) {
            p.default.info("获取用户位置", e), c.default.allToBaidu(e.longitude, e.latitude).then(function(e) {
                return t.setData({
                    "location.longitude": e.x,
                    "location.latitude": e.y
                });
            }), c.default.getAddressText(e.longitude, e.latitude).then(function(e) {
                return t.setData({
                    "location.address": e
                });
            });
        }).catch(function(t) {
            f.default.showInfo("定位取消"), p.default.error("定位取消", t);
        });
    },
    chooseLocation: function() {
        var t = this;
        wx.chooseLocation().then(function(e) {
            p.default.info("用户选择位置", e), c.default.allToBaidu(e.longitude, e.latitude).then(function(a) {
                return t.setData({
                    "location.latitude": a.y,
                    "location.longitude": a.x,
                    "location.address": e.name + e.address
                });
            });
        }).catch(function(t) {
            f.default.showInfo("取消位置选择"), p.default.error("取消位置选择", t);
        });
    },
    getSignRoster: function(t) {
        var e = this;
        return s(i().mark(function a() {
            return i().wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    return a.t0 = e, a.next = 3, g.getSignRoster(t);

                  case 3:
                    a.t1 = a.sent, a.t2 = {
                        roster: a.t1
                    }, a.t0.setData.call(a.t0, a.t2);

                  case 6:
                  case "end":
                    return a.stop();
                }
            }, a);
        }))();
    },
    auto: function() {
        var t = this;
        return s(i().mark(function e() {
            var a, n, r, o, u, d, l;
            return i().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (a = function(e) {
                        t.setData({
                            autoGetCD: e || 8
                        }, function() {
                            var e = setInterval(function() {
                                t.setData({
                                    autoGetCD: t.data.autoGetCD ? t.data.autoGetCD - 1 : 0
                                }), t.data.autoGetCD || clearInterval(e);
                            }, 1e3);
                        });
                    }, n = function() {
                        return t.data.vip || f.default.showInfo("您还不是会员用户"), t.data.vip;
                    }, ![ 0, 1 ].some(function(e) {
                        return e == t.data.info.otherId;
                    })) {
                        e.next = 10;
                        break;
                    }
                    if (n()) {
                        e.next = 5;
                        break;
                    }
                    return e.abrupt("return");

                  case 5:
                    return r = t.data.checked.length, o = t.data.roster.filter(function(t) {
                        return Boolean(t.title);
                    }), u = function() {
                        t.data.checked.forEach(function() {
                            var e = o[Math.floor(o.length * Math.random())];
                            f.default.showInfo("使用了".concat(e.name, "的照片")), t.setData({
                                fileList: t.data.fileList.concat([ {
                                    type: "image",
                                    status: "done",
                                    url: "https://p.ananas.chaoxing.com/star3/440_0/".concat(e.title)
                                } ]).slice(-r),
                                srcList: t.data.srcList.concat([ e.title ]).slice(-r)
                            });
                        });
                    }, o.length >= r ? u() : t.getSignRoster(t.options.activeId).then(function() {
                        if (0 == (o = t.data.roster.filter(function(t) {
                            return Boolean(t.title);
                        })).length) return f.default.showInfo("还没有人签到，等一会儿"), void a(10);
                        u();
                    }).finally(a), e.abrupt("return");

                  case 10:
                    if (![ 2, 4 ].some(function(e) {
                        return e == t.data.info.otherId;
                    }) && t.options.activeId) {
                        e.next = 24;
                        break;
                    }
                    if (n()) {
                        e.next = 13;
                        break;
                    }
                    return e.abrupt("return");

                  case 13:
                    if (d = function() {
                        var t = s(i().mark(function t() {
                            var e, a;
                            return i().wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, wx.scanCode();

                                  case 2:
                                    return e = t.sent, p.default.info("扫码结果", e), a = {}, e.result.split("?")[1].split("&").forEach(function(t) {
                                        var e = t.split("="), n = decodeURIComponent(e[0]), r = decodeURIComponent(e[1]);
                                        a[n] = r;
                                    }), c.default.submitEnc(a.id || "", a.enc), t.abrupt("return", a || {});

                                  case 8:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }));
                        return function() {
                            return t.apply(this, arguments);
                        };
                    }(), t.options.activeId) {
                        e.next = 20;
                        break;
                    }
                    return e.next = 17, d();

                  case 17:
                    e.t0 = e.sent, e.next = 21;
                    break;

                  case 20:
                    e.t0 = {};

                  case 21:
                    return l = e.t0, g.getLocation(t.options.activeId || l.id).then(function(e) {
                        if (f.default.showInfo(e.msg), 0 != e.status) throw "解析失败 请手动获取";
                        t.setData({
                            "location.longitude": e.data.locationLongitude || t.data.location.longitude,
                            "location.latitude": e.data.locationLatitude || t.data.location.latitude,
                            "location.address": e.data.locationText || t.data.location.address
                        });
                    }).catch(function(t) {
                        p.default.error("自动定位失败", t), f.default.showInfo(String(t));
                    }).finally(a), e.abrupt("return");

                  case 24:
                    if (![ 3, 5 ].some(function(e) {
                        return e == t.data.info.otherId;
                    })) {
                        e.next = 27;
                        break;
                    }
                    return g.signCode(t.options.activeId).then(function(e) {
                        if (f.default.showInfo(e.msg), 0 != e.status) throw "获取失败 请自行输入";
                        t.setData({
                            signCode: e.data.signCode,
                            signCodeState: !0
                        });
                    }).catch(function(t) {
                        p.default.error("自动获取签到码失败", t), f.default.showInfo(String(t));
                    }).finally(a), e.abrupt("return");

                  case 27:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    handleAdd: function(t) {
        var e = this, i = t.detail.files, o = this.data.fileList;
        i.forEach(function(t) {
            e.setData({
                fileList: [].concat(r(o), [ n(n({}, t), {}, {
                    status: "loading"
                }) ])
            });
            var i = o.length;
            wx.compressImage({
                src: t.url,
                quality: Math.floor(10 * Math.random()) + 85
            }).then(function(t) {
                wx.uploadFile({
                    url: "https://pan-yz.chaoxing.com/upload?_token=".concat(e.data.token),
                    filePath: t.tempFilePath,
                    name: "file",
                    formData: {
                        puid: v.puid
                    },
                    success: function(t) {
                        var n = JSON.parse(t.data);
                        p.default.info("图片上传结果", n), f.default.showInfo("success" == n.msg ? "图片上传成功" : n.msg), 
                        e.setData(a(a({}, "fileList[".concat(i, "].status"), "done"), "srcList[".concat(i, "]"), n.objectId));
                    }
                }).onProgressUpdate(function(t) {
                    return e.setData(a({}, "fileList[".concat(i, "].percent"), Math.floor(.99 * t.progress)));
                });
            });
        });
    },
    onReady: function() {
        var t = this;
        this.copy = function(t) {
            wx.setClipboardData({
                data: t.currentTarget.dataset.text
            });
        }, this.input = function(e) {
            t.setData(a({}, e.currentTarget.dataset.input, e.detail.value));
        }, this.checkSignCode = function() {
            var e = s(i().mark(function e(a) {
                var n;
                return i().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (!(n = t.data.signCode)) {
                            e.next = 10;
                            break;
                        }
                        return e.t0 = t, e.next = 5, g.checkSignCode(t.options.activeId, n);

                      case 5:
                        e.t1 = e.sent, e.t2 = {
                            signCodeState: e.t1
                        }, e.t0.setData.call(e.t0, e.t2), e.next = 11;
                        break;

                      case 10:
                        f.default.showInfo("请输入签到码");

                      case 11:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }));
            return function(t) {
                return e.apply(this, arguments);
            };
        }(), this.check = function(e) {
            var a = e.currentTarget.dataset.item;
            "all" === e.currentTarget.dataset.type ? t.setData({
                checked: t.data.checked.length == t.data.accounts.length ? [] : t.data.accounts
            }) : t.data.checked.some(function(t) {
                return t.username == a.username;
            }) ? t.setData({
                checked: t.data.checked.filter(function(t) {
                    return t.username != a.username;
                })
            }) : t.setData({
                checked: t.data.checked.concat([ a ])
            });
        }, this.toVIP = function(t) {
            wx.redirectTo({
                url: "../../pages/vip/vip"
            });
        }, this.handleRemove = function(e) {
            var a = e.detail.index;
            t.data.fileList.splice(a, 1), t.data.srcList.splice(a, 1), t.setData({
                fileList: t.data.fileList,
                srcList: t.data.srcList
            });
        }, this.gesture = function(e) {
            return wx.previewImage({
                urls: [ "".concat(d.default.baseUrl, "/api/public/gesture?signCode=").concat(t.data.signCode) ],
                referrerPolicy: "origin"
            });
        };
    },
    signin: function() {
        var t = this;
        return s(i().mark(function e() {
            var a, r, o, u, d;
            return i().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (r = t.data.info, o = "", t.data.checked.length) {
                        e.next = 5;
                        break;
                    }
                    return f.default.showInfo("请选择签到的用户"), e.abrupt("return");

                  case 5:
                    if (u = function() {
                        var e = s(i().mark(function e() {
                            var a, r, o;
                            return i().wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return e.next = 2, wx.scanCode();

                                  case 2:
                                    if (r = e.sent, p.default.info("扫码结果", r), o = {}, r.result.split("?")[1].split("&").forEach(function(t) {
                                        var e = t.split("="), a = decodeURIComponent(e[0]), n = decodeURIComponent(e[1]);
                                        o[a] = n;
                                    }), c.default.submitEnc(o.id || "", o.enc), !t.options.activeId || t.options.activeId == o.id) {
                                        e.next = 18;
                                        break;
                                    }
                                    return e.next = 10, wx.showModal({
                                        title: "是否前往二维码签到",
                                        content: "二维码与当前签到不一致"
                                    });

                                  case 10:
                                    if (!e.sent.confirm) {
                                        e.next = 15;
                                        break;
                                    }
                                    return wx.redirectTo({
                                        url: "./signin?username=".concat(t.options.username, "&password=").concat(t.options.password, "&activeId=").concat(o.id)
                                    }), e.abrupt("return", {});

                                  case 15:
                                    throw "二维码与当前签到不一致";

                                  case 16:
                                    e.next = 19;
                                    break;

                                  case 18:
                                    t.options.activeId || null !== (a = t.data.info) && void 0 !== a && a.id || t.onLoad(n(n({}, t.options), {}, {
                                        activeId: o.id
                                    }));

                                  case 19:
                                    return e.abrupt("return", o || {});

                                  case 20:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }));
                        return function() {
                            return e.apply(this, arguments);
                        };
                    }(), 2 != (null !== (a = r.otherId) && void 0 !== a ? a : 2)) {
                        e.next = 12;
                        break;
                    }
                    return e.next = 9, u();

                  case 9:
                    e.t0 = e.sent, e.next = 13;
                    break;

                  case 12:
                    e.t0 = {};

                  case 13:
                    d = e.t0, t.data.checked.forEach(function() {
                        var e = s(i().mark(function e(a, n) {
                            var s, u, f, p;
                            return i().wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return e.next = 2, l.default.get(a.username, a.password);

                                  case 2:
                                    return s = e.sent, e.next = 5, s.previewSign(d.id || t.options.activeId);

                                  case 5:
                                    if (u = t.data.srcList[n % t.data.srcList.length] || "", !t.data.hasValidate) {
                                        e.next = 12;
                                        break;
                                    }
                                    return e.next = 9, c.default.getValidate();

                                  case 9:
                                    e.t0 = e.sent, e.next = 13;
                                    break;

                                  case 12:
                                    e.t0 = "";

                                  case 13:
                                    if (f = e.t0, 0 != r.otherId || u || !r.ifphoto) {
                                        e.next = 20;
                                        break;
                                    }
                                    return e.next = 17, wx.showModal({
                                        title: "确认直接签到吗?",
                                        content: "你还没有上传图片"
                                    });

                                  case 17:
                                    if (1 == e.sent.confirm) {
                                        e.next = 20;
                                        break;
                                    }
                                    return e.abrupt("return");

                                  case 20:
                                    return e.next = 22, s.sign({
                                        activeId: d.id || t.options.activeId,
                                        objectId: u,
                                        longitude: t.data.location.longitude,
                                        latitude: t.data.location.latitude,
                                        address: t.data.location.address,
                                        signCode: t.data.signCode || null,
                                        enc: d.enc || null,
                                        name: a.name,
                                        validate: f
                                    });

                                  case 22:
                                    p = e.sent, o += "".concat(a.name, " - ").concat(c.default.getResult(p), "\n"), 
                                    t.setData({
                                        result: o
                                    });

                                  case 25:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }));
                        return function(t, a) {
                            return e.apply(this, arguments);
                        };
                    }());

                  case 15:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    share: function() {
        var t = Object.entries({
            username: this.data.checked[0].username,
            password: this.data.checked[0].password,
            activeId: this.options.activeId || this.data.info.id || ""
        }).map(function(t) {
            var e = o(t, 2), a = e[0], n = e[1];
            return "".concat(a, "=").concat(n);
        }).join("&");
        p.default.info("中转分享", t), wx.navigateToMiniProgram({
            appId: d.default.shareAppId,
            path: "".concat(d.default.shareAppPath, "?").concat(t, "&path=/signin/signin&package=sign"),
            envVersion: d.default.whiteList.includes(f.default.info.miniProgram.appId) ? "trial" : "release"
        });
    },
    onShareAppMessage: function() {
        var t = Object.entries({
            username: this.data.checked[0].username,
            password: this.data.checked[0].password,
            activeId: this.options.activeId || this.data.info.id || ""
        }).map(function(t) {
            var e = o(t, 2), a = e[0], n = e[1];
            return "".concat(a, "=").concat(n);
        }).join("&");
        p.default.info("请人代签", t);
        var e = getCurrentPages(), a = e[e.length - 1];
        return {
            path: "/".concat(a.route, "?").concat(t),
            title: "御坂网络 Misaka",
            imageUrl: "/static/share.png"
        };
    }
});