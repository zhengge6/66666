require("../../../../@babel/runtime/helpers/Objectentries");

var e, t, n = require("../../../../@babel/runtime/helpers/slicedToArray"), r = require("../../../../@babel/runtime/helpers/regeneratorRuntime"), a = require("../../../../@babel/runtime/helpers/asyncToGenerator"), i = (c(require("../../utils/api")), 
c(require("../../utils/config"))), o = c(require("../../utils/user")), s = c(require("@utils/util")), u = c(require("@utils/log"));

function c(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Page({
    data: {
        notice: "Misaka提醒您，要按时完成学习计划哦~",
        activities: [],
        adId: null === (e = i.default.advertise[s.default.info.miniProgram.appId]) || void 0 === e ? void 0 : e.custom,
        watermark: (null === (t = o.default.users[0]) || void 0 === t ? void 0 : t.username) || ""
    },
    onLoad: function(e) {
        var t = this;
        return a(r().mark(function n() {
            return r().wrap(function(n) {
                for (;;) switch (n.prev = n.next) {
                  case 0:
                    return n.next = 2, o.default.get(e.username, e.password);

                  case 2:
                    n.sent.getActivity(e.courseId, e.classId).then(function(e) {
                        return t.setData({
                            activities: e.slice(0, 20)
                        });
                    }).catch(function(e) {
                        s.default.showInfo(String(e)), u.default.error("获取活动失败", e);
                    }).finally(function() {
                        return t.setData({
                            isLoad: !0
                        });
                    }), wx.setNavigationBarTitle({
                        title: e.name ? "".concat(e.name, " - 活动列表") : "活动列表"
                    });

                  case 5:
                  case "end":
                    return n.stop();
                }
            }, n);
        }))();
    },
    onReady: function() {
        var e = this;
        this.to = function(t) {
            var r = t.currentTarget.dataset.item, a = Object.entries({
                username: e.options.username || "",
                password: e.options.password || "",
                activeId: r.activeId
            }).map(function(e) {
                var t = n(e, 2), r = t[0], a = t[1];
                return "".concat(r, "=").concat(a);
            }).join("&");
            wx.navigateTo({
                url: "../signin/signin?".concat(a)
            });
        };
    },
    onShareAppMessage: function() {
        var e = Object.entries(this.options).map(function(e) {
            var t = n(e, 2), r = t[0], a = t[1];
            return "".concat(r, "=").concat(a);
        }).join("&");
        u.default.info("分享", e);
        var t = getCurrentPages(), r = t[t.length - 1];
        return {
            path: "/".concat(r.route, "?").concat(e),
            title: "御坂网络 Misaka",
            imageUrl: "/static/share.png"
        };
    },
    onPullDownRefresh: function() {
        var e = this;
        wx.showModal({
            title: "确认重新获取活动吗?",
            content: "获取次数过多可能提示【请勿频繁操作】"
        }).then(function(t) {
            t.confirm && e.onLoad(e.options);
        });
    }
});