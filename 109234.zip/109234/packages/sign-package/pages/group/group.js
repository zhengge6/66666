var t, e = require("../../../../@babel/runtime/helpers/defineProperty"), a = require("../../../../@babel/runtime/helpers/objectSpread2"), n = require("../../../../@babel/runtime/helpers/toConsumableArray"), r = require("../../../../@babel/runtime/helpers/regeneratorRuntime"), i = require("../../../../@babel/runtime/helpers/asyncToGenerator"), s = f(require("../../utils/api")), u = f(require("../../utils/vip")), o = f(require("../../utils/config")), c = f(require("../../utils/user")), d = (f(require("../../utils/im")), 
f(require("@utils/util"))), l = f(require("@utils/log"));

function f(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var h = null, p = {};

Page({
    data: {
        adId: null === (t = o.default.advertise[d.default.info.miniProgram.appId]) || void 0 === t ? void 0 : t.custom,
        location: {},
        srcList: [],
        fileList: [],
        accounts: [],
        checked: []
    },
    onLoad: function(t) {
        var e = this;
        return i(r().mark(function a() {
            return r().wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    return e.getUserLocation(), a.next = 3, c.default.get(t.username, t.password);

                  case 3:
                    return h = a.sent, a.next = 6, c.default.getUserInfo(t.username, t.password);

                  case 6:
                    return p = a.sent, a.t0 = e, a.t1 = u.default.getVipState(p.username), a.t2 = t, 
                    a.t3 = c.default.users, a.t4 = e.data.checked.length ? e.data.checked : [ p ], a.next = 14, 
                    h.getToken();

                  case 14:
                    a.t5 = a.sent, a.t6 = {
                        vip: a.t1,
                        options: a.t2,
                        accounts: a.t3,
                        checked: a.t4,
                        token: a.t5
                    }, a.t0.setData.call(a.t0, a.t6);

                  case 17:
                  case "end":
                    return a.stop();
                }
            }, a);
        }))();
    },
    onReady: function() {
        var t = this;
        this.check = function(e) {
            var a = e.currentTarget.dataset.item;
            t.data.checked.some(function(t) {
                return t.username == a.username;
            }) ? t.setData({
                checked: t.data.checked.filter(function(t) {
                    return t.username != a.username;
                })
            }) : t.setData({
                checked: t.data.checked.concat([ a ])
            });
        };
    },
    signin: function() {
        var t = this, e = "";
        this.data.checked.forEach(function() {
            var a = i(r().mark(function a(n, i) {
                var u, o, d;
                return r().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        return a.next = 2, c.default.get(n.username, n.password);

                      case 2:
                        return u = a.sent, o = t.data.srcList[i % t.data.srcList.length] || "", a.next = 6, 
                        u.groupSign({
                            activeId: t.options.activeId,
                            objectId: o,
                            longitude: t.data.location.longitude,
                            latitude: t.data.location.latitude,
                            address: t.data.location.address
                        });

                      case 6:
                        d = a.sent, e += "".concat(n.name, " - ").concat(s.default.getResult(d), "\n"), 
                        t.setData({
                            result: e
                        });

                      case 9:
                      case "end":
                        return a.stop();
                    }
                }, a);
            }));
            return function(t, e) {
                return a.apply(this, arguments);
            };
        }());
    },
    handleAdd: function(t) {
        var r = this, i = t.detail.files, s = this.data.fileList;
        i.forEach(function(t) {
            r.setData({
                fileList: [].concat(n(s), [ a(a({}, t), {}, {
                    status: "loading"
                }) ])
            });
            var i = s.length;
            wx.uploadFile({
                url: "https://pan-yz.chaoxing.com/upload?_token=".concat(r.data.token),
                filePath: t.url,
                name: "file",
                formData: {
                    puid: p.puid
                },
                success: function(t) {
                    var a = JSON.parse(t.data);
                    l.default.info("图片上传结果", a), d.default.showInfo("success" == a.msg ? "图片上传成功" : a.msg), 
                    r.setData(e(e({}, "fileList[".concat(i, "].status"), "done"), "srcList[".concat(i, "]"), a.objectId));
                }
            }).onProgressUpdate(function(t) {
                return r.setData(e({}, "fileList[".concat(i, "].percent"), Math.floor(.99 * t.progress)));
            });
        }), this.handleRemove = function(t) {
            var e = t.detail.index;
            r.data.fileList.splice(e, 1), r.data.srcList.splice(e, 1), r.setData({
                fileList: r.data.fileList,
                srcList: r.data.srcList
            });
        };
    },
    getUserLocation: function() {
        var t = this;
        this.data.location.longitude && this.data.location.latitude || wx.getLocation({
            type: "gcj02"
        }).then(function(e) {
            l.default.info("获取用户位置", e), s.default.allToBaidu(e.longitude, e.latitude).then(function(e) {
                return t.setData({
                    "location.longitude": e.x,
                    "location.latitude": e.y
                });
            }), s.default.getAddressText(e.longitude, e.latitude).then(function(e) {
                return t.setData({
                    "location.address": e
                });
            });
        }).catch(function(t) {
            d.default.showInfo("定位取消"), l.default.error("定位取消", t);
        });
    }
});