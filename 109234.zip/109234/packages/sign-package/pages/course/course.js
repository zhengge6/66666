require("../../../../@babel/runtime/helpers/Objectentries");

var e, r, t = require("../../../../@babel/runtime/helpers/regeneratorRuntime"), n = require("../../../../@babel/runtime/helpers/toConsumableArray"), a = require("../../../../@babel/runtime/helpers/slicedToArray"), u = require("../../../../@babel/runtime/helpers/asyncToGenerator"), s = (d(require("../../utils/api")), 
d(require("../../utils/config"))), o = d(require("../../utils/user")), i = d(require("../../utils/im")), c = d(require("@utils/util")), l = d(require("@utils/log"));

function d(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var f = null, m = {}, h = null;

Page({
    data: {
        courses: [],
        "search.courses": [],
        "search.query": "",
        adId: null === (e = s.default.advertise[c.default.info.miniProgram.appId]) || void 0 === e ? void 0 : e.custom,
        watermark: (null === (r = o.default.users[0]) || void 0 === r ? void 0 : r.username) || ""
    },
    onLoad: function(e) {
        var r = this;
        return u(t().mark(function u() {
            var s, l;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, o.default.get(e.username, e.password);

                  case 2:
                    return f = t.sent, t.next = 5, o.default.getUserInfo(e.username, e.password);

                  case 5:
                    if (m = t.sent, f) {
                        t.next = 9;
                        break;
                    }
                    return wx.redirectTo({
                        url: "../login/login"
                    }), t.abrupt("return");

                  case 9:
                    h = new i.default((null === (s = m.im) || void 0 === s ? void 0 : s.username) || "", (null === (l = m.im) || void 0 === l ? void 0 : l.password) || ""), 
                    Promise.all([ f.getCourse().then(function(e) {
                        return e;
                    }).catch(function(e) {
                        return c.default.showInfo(String(e)), [];
                    }), h.getCourse().then(function(e) {
                        return e;
                    }) ]).then(function(e) {
                        var t = a(e, 2), u = t[0], s = t[1];
                        r.setData({
                            courses: [].concat(n(u), n(s.filter(function(e) {
                                return !u.some(function(r) {
                                    return e.classId == r.classId && r.courseId == e.courseId;
                                });
                            })))
                        }), c.default.showInfo("获取课程成功");
                    }).finally(function() {
                        return r.setData({
                            isLoad: !0
                        });
                    });

                  case 11:
                  case "end":
                    return t.stop();
                }
            }, u);
        }))();
    },
    onReady: function() {
        var e = this;
        this.search = function(r) {
            var t = r.detail.value;
            e.setData({
                "search.courses": function(e, r) {
                    var t = [ "courseName", "className", "teacherName", "folder" ];
                    if (!e || !r.length) return [];
                    var n = new RegExp(e.split("").join(".*"), "i");
                    return r.filter(function(e) {
                        return t.some(function(r) {
                            var t;
                            return n.test(null === (t = e[r]) || void 0 === t ? void 0 : t.toString());
                        });
                    });
                }(t, e.data.courses),
                "search.query": t
            });
        }, this.to = function(r) {
            var t = r.currentTarget.dataset.item, n = Object.entries({
                username: e.options.username || m.username || m.phone || "",
                password: e.options.password || m.password || "",
                classId: t.classId,
                courseId: t.courseId,
                name: t.courseName || ""
            }).map(function(e) {
                var r = a(e, 2), t = r[0], n = r[1];
                return "".concat(t, "=").concat(n);
            }).join("&");
            wx.navigateTo({
                url: "../activity/activity?".concat(n)
            });
        };
    },
    onShareAppMessage: function() {
        var e = Object.entries(this.options).map(function(e) {
            var r = a(e, 2), t = r[0], n = r[1];
            return "".concat(t, "=").concat(n);
        }).join("&");
        l.default.info("分享", e);
        var r = getCurrentPages(), t = r[r.length - 1];
        return {
            path: "/".concat(t.route, "?").concat(e),
            title: "御坂网络 Misaka",
            imageUrl: "/static/share.png"
        };
    },
    onPullDownRefresh: function() {
        var e = this;
        wx.showModal({
            title: "确认重新获取课程吗?",
            content: "获取次数过多可能提示【请勿频繁操作】"
        }).then(function(r) {
            r.confirm && e.onLoad(e.options);
        });
    }
});