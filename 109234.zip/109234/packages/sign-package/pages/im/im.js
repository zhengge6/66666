var e = require("../../../../@babel/runtime/helpers/slicedToArray");

require("../../../../@babel/runtime/helpers/Objectentries");

var r, i = require("../../../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../../../@babel/runtime/helpers/asyncToGenerator"), a = (s(require("../../utils/api")), 
s(require("../../utils/vip")), s(require("../../utils/config"))), u = s(require("../../utils/user")), n = (s(require("../../utils/im")), 
s(require("@utils/util")));

s(require("@utils/log"));

function s(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Page({
    data: {
        adId: null === (r = a.default.advertise[n.default.info.miniProgram.appId]) || void 0 === r ? void 0 : r.custom,
        disabled: "wxb42fe32e6e071916" != n.default.info.miniProgram.appId && "release" == n.default.info.miniProgram.envVersion,
        userinfo: {},
        url: null
    },
    onLoad: function(e) {
        var r = this;
        return t(i().mark(function t() {
            return i().wrap(function(i) {
                for (;;) switch (i.prev = i.next) {
                  case 0:
                    return i.t0 = r, i.next = 3, u.default.getUserInfo(e.username, e.password);

                  case 3:
                    i.t1 = i.sent, i.t2 = {
                        userinfo: i.t1
                    }, i.t0.setData.call(i.t0, i.t2);

                  case 6:
                  case "end":
                    return i.stop();
                }
            }, t);
        }))();
    },
    connect: function() {
        var r, i;
        if (!this.data.disabeld) {
            var t = Object.entries({
                user: null === (r = this.data.userinfo.im) || void 0 === r ? void 0 : r.username,
                pwd: null === (i = this.data.userinfo.im) || void 0 === i ? void 0 : i.password
            }).map(function(r) {
                var i = e(r, 2), t = i[0], a = i[1];
                return "".concat(t, "=").concat(a);
            }).join("&");
            this.setData({
                url: "".concat(a.default.imUrl, "/api/public/im?").concat(t)
            });
        }
    }
});