var t, e = require("../../../../@babel/runtime/helpers/regeneratorRuntime"), n = require("../../../../@babel/runtime/helpers/asyncToGenerator"), a = s(require("../../utils/api")), i = s(require("../../utils/config")), o = s(require("crypto-aes")), r = s(require("@utils/util")), u = s(require("@utils/log"));

function s(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

Page({
    data: {
        adId: null === (t = i.default.advertise[r.default.info.miniProgram.appId]) || void 0 === t ? void 0 : t.custom
    },
    onLoad: function(t) {
        var e = this;
        this.data.count = 0, setInterval(function() {
            e.data.aid && e.data.count++ < 20 && e.getSignRoster(e.data.aid);
        }, 2e3);
    },
    exit: function() {
        wx.exitMiniProgram();
    },
    scan: function() {
        var t = this;
        return new Promise(function(e) {
            wx.scanCode().then(function(n) {
                u.default.info("扫码结果", n);
                var i = {};
                n.result.split("?")[1].split("&").forEach(function(t) {
                    var e = t.split("="), n = decodeURIComponent(e[0]), a = decodeURIComponent(e[1]);
                    i[n] = a;
                }), a.default.submitEnc(i.id, i.enc), t.getSignRoster(i.id), t.setData({
                    aid: i.id,
                    count: 0,
                    text: "活动ID: ".concat(i.id, "\nENC: ").concat(i.enc)
                }), r.default.showInfo("提交成功"), e();
            }).catch(function(t) {
                t.errMsg.includes("cancel") ? r.default.showInfo("用户取消扫码") : r.default.showInfo("扫码失败");
            });
        });
    },
    changeCollapse: function(t) {
        this.setData({
            collapses: t.detail.value
        });
    },
    autoScan: function() {
        var t = this;
        this.scan().then(function() {
            return t.autoScan();
        });
    },
    getSignRoster: function(t) {
        var a = this;
        return n(e().mark(function n() {
            var i;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    i = Math.round(new Date() / 1e3), wx.request({
                        url: "https://cx.waadri.top/get_qrcode_status",
                        method: "POST",
                        data: {
                            aid: t.toString(),
                            t: i,
                            token: (0, o.default.MD5)("R8Vq3sNKdxGQwlyNCpw6J49SOFAC982X" + t.toString() + "CJpgxaT" + i.toString()).toString()
                        },
                        success: function(e) {
                            var n, i;
                            u.default.info("获取签到结果", t, e), a.setData({
                                yiqian: (null === (n = e.data) || void 0 === n ? void 0 : n.yiqian) || [],
                                weiqian: (null === (i = e.data) || void 0 === i ? void 0 : i.weiqian) || []
                            });
                        }
                    });

                  case 2:
                  case "end":
                    return e.stop();
                }
            }, n);
        }))();
    },
    onShareAppMessage: function() {
        var t = getCurrentPages(), e = t[t.length - 1];
        return {
            path: "/".concat(e.route),
            title: "扫码小助手",
            imageUrl: "https://cdn.micono.eu.org/icon/logo.png"
        };
    }
});