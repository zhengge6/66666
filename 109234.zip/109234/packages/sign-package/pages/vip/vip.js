var e, t, a = require("../../../../@babel/runtime/helpers/defineProperty"), i = o(require("../../utils/vip")), r = o(require("../../utils/config")), n = o(require("../../utils/user")), u = o(require("@utils/util")), d = o(require("@utils/log"));

function o(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Page({
    data: {
        expire: "正在获取",
        key: "",
        adId: null === (e = r.default.advertise[u.default.info.miniProgram.appId]) || void 0 === e ? void 0 : e.custom,
        watermark: (null === (t = n.default.users[0]) || void 0 === t ? void 0 : t.username) || ""
    },
    onReady: function() {
        var e = this;
        this.input = function(t) {
            e.setData(a({}, "".concat(t.currentTarget.dataset.input), t.detail.value));
        }, this.showKeyUse = function(t) {
            e.setData({
                showKeyUse: !0
            });
        };
    },
    convert: function() {
        !this.data.key || this.data.key.length <= 20 ? u.default.showInfo("暂未开放，敬请期待！") : i.default.convertVipKey(this.data.key.trim()).then(function(e) {
            wx.redirectTo({
                url: "./vip"
            });
        });
    },
    toAd: function() {
        u.default.info.miniProgram.appId == r.default.advertiseAppId ? wx.navigateTo({
            url: "".concat(r.default.advertiseAppPath, "?appid=").concat(u.default.info.miniProgram.appId),
            events: {
                extraData: function(e) {
                    e.appid === u.default.info.miniProgram.appId && e.result ? i.default.adGetVip(e.appid) : u.default.showInfo("未获得奖励");
                }
            }
        }) : wx.openEmbeddedMiniProgram({
            appId: r.default.advertiseAppId,
            path: "".concat(r.default.advertiseAppPath, "?appid=").concat(u.default.info.miniProgram.appId),
            envVersion: r.default.whiteList.includes(u.default.info.miniProgram.appId) ? "trial" : "release",
            allowFullScreen: !0
        });
    },
    onShow: function() {
        var e, t = wx.getEnterOptionsSync(), a = (null == t || null === (e = t.referrerInfo) || void 0 === e ? void 0 : e.extraData) || null;
        d.default.info("进入VIP页面", a), a && "ad" === a.type && (a.appid === u.default.info.miniProgram.appId && a.result ? i.default.adGetVip(a.appid) : u.default.showInfo("未获得奖励")), 
        this.setData({
            vip: i.default.getVipState(),
            expire: i.default.getVipExpire(),
            accounts: n.default.users.map(function(e) {
                return Object.assign(e, {
                    expire: i.default.getVipExpire(e.username)
                });
            })
        });
    }
});