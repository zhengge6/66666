var t = require("../../../../@babel/runtime/helpers/regeneratorRuntime"), e = require("../../../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../../../@babel/runtime/helpers/defineProperty"), a = s(require("../../utils/user")), r = s(require("@utils/util"));

s(require("@utils/log"));

function s(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

Page({
    data: {
        username: "",
        password: "",
        accounts: []
    },
    onLoad: function(t) {
        var e = this;
        this.sync = function() {
            e.setData({
                accounts: a.default.users,
                nowIndex: a.default.nowIndex
            });
        }, this.sync(), setInterval(this.sync, 5e3);
    },
    onReady: function() {
        var s = this;
        this.showPassword = function() {
            s.setData({
                showPassword: !Boolean(s.data.showPassword)
            });
        }, this.addAccount = function() {
            s.setData({
                addAccount: !0
            });
        }, this.input = function(t) {
            var e = t.currentTarget.dataset.key;
            s.setData(n({}, e, t.detail.value.trim()));
        }, this.back = function() {
            s.setData({
                accounts: a.default.users,
                addAccount: !1
            });
        }, this.login = e(t().mark(function e() {
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (![ "=", "?", "&" ].some(function(t) {
                        return s.data.password.includes(t);
                    })) {
                        t.next = 7;
                        break;
                    }
                    return t.next = 3, wx.showModal({
                        title: "此账号无法使用请人代签",
                        content: "密码中包含符号，无法请人代签",
                        confirmText: "继续登录",
                        cancelText: "取消登录"
                    });

                  case 3:
                    if (t.sent.confirm) {
                        t.next = 7;
                        break;
                    }
                    return r.default.showInfo("用户取消登录"), t.abrupt("return");

                  case 7:
                    return t.next = 9, a.default.add(s.data.username, s.data.password);

                  case 9:
                    if (!t.sent) {
                        t.next = 11;
                        break;
                    }
                    s.back(), s.sync();

                  case 11:
                  case "end":
                    return t.stop();
                }
            }, e);
        })), this.switch = function() {
            var n = e(t().mark(function e(n) {
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.t0 = s, t.next = 3, a.default.switch(n.currentTarget.dataset.index);

                      case 3:
                        t.t1 = t.sent, t.t2 = {
                            nowIndex: t.t1
                        }, t.t0.setData.call(t.t0, t.t2), s.sync();

                      case 7:
                      case "end":
                        return t.stop();
                    }
                }, e);
            }));
            return function(t) {
                return n.apply(this, arguments);
            };
        }(), this.privacy = function() {
            wx.openPrivacyContract();
        }, this.agree = function() {
            r.default.showInfo("".concat(s.data.privacy ? "您不同意协议" : "您已同意协议")), s.setData({
                privacy: !Boolean(s.data.privacy)
            });
        }, this.logout = function() {
            var n = e(t().mark(function e(n) {
                var r;
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return r = n.currentTarget.dataset.item, t.next = 3, a.default.delete(r.username);

                      case 3:
                        s.sync();

                      case 4:
                      case "end":
                        return t.stop();
                    }
                }, e);
            }));
            return function(t) {
                return n.apply(this, arguments);
            };
        }();
    },
    onShow: function() {}
});