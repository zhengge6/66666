module.exports = [ {
    name: "锻炼",
    unit: [ "time", "calorie" ],
    id: 1001
}, {
    name: "体能训练",
    unit: [ "time", "calorie" ],
    id: 1002
}, {
    name: "功能性训练",
    unit: [ "time", "calorie" ],
    id: 1003
}, {
    name: "瑜伽",
    unit: [ "time", "calorie" ],
    id: 2001
}, {
    name: "钓鱼",
    unit: [ "time", "calorie" ],
    id: 2002
}, {
    name: "广场舞",
    unit: [ "time", "calorie" ],
    id: 2003
}, {
    name: "足球",
    unit: [ "time", "calorie" ],
    id: 2004
}, {
    name: "篮球",
    unit: [ "time", "calorie" ],
    id: 2005
}, {
    name: "羽毛球",
    unit: [ "time", "calorie" ],
    id: 2006
}, {
    name: "乒乓球",
    unit: [ "time", "calorie" ],
    id: 2007
}, {
    name: "网球",
    unit: [ "time", "calorie" ],
    id: 2008
}, {
    name: "跑步",
    unit: [ "time", "distance", "calorie" ],
    id: 3001
}, {
    name: "登山",
    unit: [ "time", "distance", "calorie" ],
    id: 3002
}, {
    name: "骑车",
    unit: [ "time", "distance", "calorie" ],
    id: 3003
}, {
    name: "游泳",
    unit: [ "time", "distance", "calorie" ],
    id: 3004
}, {
    name: "滑雪",
    unit: [ "time", "distance", "calorie" ],
    id: 3005
}, {
    name: "跳绳",
    unit: [ "number", "calorie" ],
    id: 4001
}, {
    name: "俯卧撑",
    unit: [ "number", "calorie" ],
    id: 4002
}, {
    name: "深蹲",
    unit: [ "number", "calorie" ],
    id: 4003
} ];