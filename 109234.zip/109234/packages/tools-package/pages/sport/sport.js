var t = require("../../../../@babel/runtime/helpers/slicedToArray");

require("../../../../@babel/runtime/helpers/Objectentries");

var e = require("../../../../@babel/runtime/helpers/defineProperty"), s = r(require("@utils/util")), a = r(require("@utils/http")), n = r(require("@utils/log")), i = r(require("list"));

function r(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

Page({
    data: {
        notice: "诚信打卡，适量运动！Misaka 祝您身体健康！",
        units: {
            time: "分钟",
            number: "个",
            distance: "米",
            calorie: "卡路里"
        },
        sports: [],
        unit: "time"
    },
    onLoad: function(t) {
        var e = s.default.getStorage("sports.steps");
        (null == e ? void 0 : e.date) == new Date().toDateString() ? this.setData({
            steps: e.steps + Math.floor(3 * Math.random() * 1e4),
            "mini.steps": e.steps
        }) : this.setData({
            steps: Math.floor(3 * Math.random() * 1e4) + 1e4
        }), this.setData({
            username: (null == e ? void 0 : e.username) || "",
            password: (null == e ? void 0 : e.password) || ""
        });
    },
    onReady: function() {
        var t = this;
        this.input = function(s) {
            t.setData(e({}, s.currentTarget.dataset.input, s.detail.value));
        }, this.switchUnit = function(e) {
            var s = e.detail.value;
            t.setData({
                unit: s,
                sports: i.default.filter(function(t) {
                    return t.unit.includes(s);
                })
            });
        }, this.showSteps = function(e) {
            t.setData({
                showSteps: !0
            });
        };
    },
    shareToWeRun: function() {
        var a = this, i = this.data.sports.filter(function(t) {
            return t.value;
        }).map(function(s) {
            var n = e({
                typeId: s.id
            }, a.data.unit, Number(s.value));
            return n.number = Math.min(1e4, n.number || 0), n.distance = Math.min(1e5, n.distance || 0), 
            n.time = Math.min(1440, n.time || 0), Object.fromEntries(Object.entries(n).filter(function(e) {
                var s = t(e, 2), a = (s[0], s[1]);
                return Boolean(a);
            }));
        });
        i.length ? (n.default.info("运动内容", i), wx.shareToWeRun({
            recordList: i
        }).catch(function(t) {
            return s.default.showInfo("打卡失败");
        }).then(function(t) {
            s.default.showInfo("打卡成功"), a.setData({
                sports: a.data.sports.map(function(t) {
                    return Object.assign(t, {
                        value: ""
                    });
                })
            });
        })) : s.default.showInfo("请先输入运动数据");
    },
    steps: function() {
        this.data.username && this.data.password ? (s.default.setStorage("sports.steps", {
            username: this.data.username,
            password: this.data.password,
            steps: this.data.steps,
            date: new Date().toDateString()
        }), a.default.get({
            url: "https://proxy.yangrucheng.top/https://steps.api.030101.xyz/api",
            params: {
                account: this.data.username,
                password: this.data.password,
                steps: Math.max(this.data.steps, (this.data.steps.mini || 0) + 1)
            }
        }).then(function(t) {
            s.default.showInfo(t.message);
        })) : s.default.showInfo("账号或密码不能为空");
    }
});