var t = require("../../../../@babel/runtime/helpers/slicedToArray");

require("../../../../@babel/runtime/helpers/Objectentries");

var e, a = require("../../../../@babel/runtime/helpers/objectSpread2"), n = require("../../../../@babel/runtime/helpers/defineProperty"), i = u(require("@utils/config")), o = u(require("@utils/util")), r = u(require("@utils/http")), s = u(require("@utils/log"));

function u(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

Page({
    data: {
        adId: Math.random() <= .6 ? null === (e = i.default.advertise[o.default.info.miniProgram.appId]) || void 0 === e ? void 0 : e.custom : "",
        questions: [],
        list: {},
        link: "",
        begin: !1,
        score: "0.00",
        nowIndex: 0,
        confirm: !1
    },
    onLoad: function(t) {
        var e = this;
        r.default.get({
            url: "https://cx-api.waadri.top/cx-signin-question.json"
        }).then(function(a) {
            return e.setData({
                list: a.data,
                mobile: t.mobile || ""
            });
        });
    },
    onReady: function() {
        var e = this;
        this.input = function(t) {
            e.setData(n({}, t.currentTarget.dataset.input, t.detail.value));
        }, this.click = function(t) {
            e.data.confirm || e.setData(n({}, "questions[".concat(e.data.nowIndex, "].choose"), t.currentTarget.dataset.key));
        }, this.confirm = function(t) {
            var a;
            e.setData({
                confirm: !0,
                score: (100 * e.data.questions.filter(function(t) {
                    return t.choose == t.correct;
                }).length / e.data.questions.length).toFixed(2)
            }), a = 2, e.setData({
                clickCD: a || 3
            }, function() {
                var t = setInterval(function() {
                    e.setData({
                        clickCD: e.data.clickCD ? e.data.clickCD - 1 : 0
                    }), e.data.clickCD || clearInterval(t);
                }, 1e3);
            });
        }, this.next = function(t) {
            e.setData({
                confirm: !1,
                nowIndex: (e.data.nowIndex + 1) % e.data.questions.length
            });
        }, this.finish = function(t) {
            var a = e.data.score, n = function(t) {
                var e = function(t) {
                    var e = t >= 0 ? 1 : -1, a = 1 / (1 + .3275911 * (t = Math.abs(t)));
                    return e * (1 - ((((1.061405429 * a - 1.453152027) * a + 1.421413741) * a - .284496736) * a + .254829592) * a * Math.exp(-t * t));
                }, a = .5 * (1 + e((Number(t) - 80) / 10 / Math.sqrt(2))), n = .5 * (1 + e(-2 / Math.sqrt(2))), i = .5 * (1 + e(2 / Math.sqrt(2))) - n;
                return Math.min(100, Math.max(.01, (a - n) / i * 100));
            }(a).toFixed(2), i = a >= 90 ? "答题侠" : "菜鸟";
            e.setData({
                dialog: "您的答题得分为 ".concat(a, "分！\n恭喜您超越了 ").concat(n, "% 的人，\n获得【").concat(i, "】称号！")
            });
        }, this.begin = function(n) {
            var i = e.data.list["必答题"].concat(e.data.list["随机题"].sort(function() {
                return Math.random() - .5;
            }).slice(0, e.data.list["题数"] - e.data.list["必答题"].length));
            e.setData({
                questions: i.map(function(e) {
                    return a(a({}, e), {}, {
                        options: Object.entries(e.options).map(function(e) {
                            var a = t(e, 2);
                            return {
                                key: a[0],
                                value: a[1]
                            };
                        }),
                        choose: ""
                    });
                }).sort(function() {
                    return Math.random() - .5;
                }),
                confirm: !1,
                nowIndex: 0
            });
        }, this.award = function(t) {
            var a = e.data.mobile;
            a ? r.default.post({
                url: "https://cx.waadri.top/exam",
                body: {
                    phone: a
                }
            }).then(function(t) {
                s.default.info("领取答题奖励", t), o.default.showInfo(t.msg), t.result && e.closeDialog();
            }) : o.default.showInfo("请填写手机号");
        }, this.closeDialog = function(t) {
            e.setData({
                dialog: !1,
                questions: []
            });
        };
    },
    onShow: function() {
        wx.hideHomeButton();
    }
});