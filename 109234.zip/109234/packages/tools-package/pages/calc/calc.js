Page({
    data: {
        title: "计算器",
        value: null,
        showValue: "0",
        operate: null,
        waitingForOperate: !1
    },
    onLoad: function(t) {
        wx.setNavigationBarTitle({
            title: this.data.title
        }), this.calculatorOperations = {
            "key-divide": function(t, a) {
                return t / a;
            },
            "key-multiply": function(t, a) {
                return t * a;
            },
            "key-add": function(t, a) {
                return t + a;
            },
            "key-subtract": function(t, a) {
                return t - a;
            },
            "key-equals": function(t, a) {
                return a;
            }
        };
    },
    clearAll: function() {
        this.setData({
            value: null,
            showValue: "0",
            operate: null,
            waitingForOperate: !1
        });
    },
    clearDisplay: function() {
        this.setData({
            showValue: "0"
        });
    },
    onTapFunction: function(t) {
        switch (t.target.dataset.key) {
          case "key-clear":
            "0" !== this.data.showValue ? this.clearDisplay() : this.clearAll();
            break;

          case "key-sign":
            var a = -1 * parseFloat(this.data.showValue);
            this.setData({
                showValue: String(a)
            });
            break;

          case "key-percent":
            var e = this.data.showValue.replace(/^-?\d*\.?/, "");
            a = parseFloat(this.data.showValue) / 100;
            this.setData({
                showValue: String(a.toFixed(e.length + 2))
            });
        }
    },
    onTapOperate: function(t) {
        var a = t.target.dataset.key, e = parseFloat(this.data.showValue);
        if (null == this.data.value) this.setData({
            value: e
        }); else if (this.data.operate) {
            var s = this.data.value || 0, i = this.calculatorOperations[this.data.operate](s, e);
            this.setData({
                value: i,
                showValue: String(i)
            });
        }
        this.setData({
            waitingForOperate: !0,
            operate: a
        });
    },
    onTapNum: function(t) {
        var a = t.target.dataset.key || "";
        if ("" != a) if ("key-dot" == a) /\./.test(this.data.showValue) || this.setData({
            showValue: this.data.showValue + ".",
            waitingForOperate: !1
        }); else {
            var e = a[a.length - 1];
            this.data.waitingForOperate ? this.setData({
                showValue: String(e),
                waitingForOperate: !1
            }) : this.setData({
                showValue: "0" === this.data.showValue ? String(e) : this.data.showValue + e
            });
        }
    }
});