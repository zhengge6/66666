var t = require("../../../../@babel/runtime/helpers/toConsumableArray"), e = require("../../../../@babel/runtime/helpers/slicedToArray");

require("../../../../@babel/runtime/helpers/Objectentries");

var n, a = require("../../../../@babel/runtime/helpers/defineProperty"), i = c(require("@utils/config")), r = c(require("@utils/util")), o = c(require("@utils/http")), s = c(require("@utils/log")), u = c(require("list"));

function c(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

Page({
    data: {
        adId: null === (n = i.default.advertise[r.default.info.miniProgram.appId]) || void 0 === n ? void 0 : n.custom,
        questions: [],
        list: [],
        link: "",
        score: "0.00",
        nowIndex: 0,
        confirm: !1
    },
    onLoad: function(t) {
        s.default.info("题库", u.default), this.setData({
            list: u.default.map(function(t) {
                return {
                    id: t.id,
                    name: t.name,
                    author: t.author,
                    desc: t.desc
                };
            }),
            link: t.link || ""
        });
    },
    onReady: function() {
        var n = this;
        this.input = function(t) {
            n.setData(a({}, t.currentTarget.dataset.input, t.detail.value));
        }, this.click = function(t) {
            n.data.confirm || n.setData(a({}, "questions[".concat(n.data.nowIndex, "].choose"), t.currentTarget.dataset.key));
        }, this.confirm = function(t) {
            var e;
            n.setData({
                confirm: !0,
                score: (100 * n.data.questions.filter(function(t) {
                    return t.choose == t.correct;
                }).length / n.data.questions.length).toFixed(2)
            }), e = 2, n.setData({
                clickCD: e || 3
            }, function() {
                var t = setInterval(function() {
                    n.setData({
                        clickCD: n.data.clickCD ? n.data.clickCD - 1 : 0
                    }), n.data.clickCD || clearInterval(t);
                }, 1e3);
            });
        }, this.next = function(t) {
            n.setData({
                confirm: !1,
                nowIndex: (n.data.nowIndex + 1) % n.data.questions.length
            });
        }, this.finish = function(t) {
            var e = n.data.score, a = function(t) {
                var e = function(t) {
                    var e = t >= 0 ? 1 : -1, n = 1 / (1 + .3275911 * (t = Math.abs(t)));
                    return e * (1 - ((((1.061405429 * n - 1.453152027) * n + 1.421413741) * n - .284496736) * n + .254829592) * n * Math.exp(-t * t));
                }, n = .5 * (1 + e((Number(t) - 80) / 10 / Math.sqrt(2))), a = .5 * (1 + e(-2 / Math.sqrt(2))), i = .5 * (1 + e(2 / Math.sqrt(2))) - a;
                return Math.min(100, Math.max(.01, (n - a) / i * 100));
            }(e).toFixed(2), i = e >= 90 ? "至尊答题侠" : e >= 80 ? "答题侠" : e >= 60 ? "小天才" : "菜鸟";
            n.setData({
                dialog: "您的答题得分为 ".concat(e, "分！\n恭喜您超越了 ").concat(a, "% 的人，\n获得【").concat(i, "】称号！")
            });
        }, this.begin = function(t) {
            wx.hideHomeButton(), n.setData({
                questions: JSON.parse(JSON.stringify(u.default))[t.currentTarget.dataset.index].content.map(function(t) {
                    return Object.assign(t, {
                        options: Object.entries(t.options).map(function(t) {
                            var n = e(t, 2);
                            return {
                                key: n[0],
                                value: n[1]
                            };
                        }).sort(function() {
                            return Math.random() - .5;
                        })
                    });
                }).sort(function() {
                    return Math.random() - .5;
                }).slice(0, 20)
            });
        }, this.closeDialog = function(t) {
            n.setData({
                dialog: !1,
                questions: []
            });
        }, this.add = function(e) {
            var a = n.data.link;
            a ? o.default.get({
                url: "https://proxy.yangrucheng.top/".concat(a)
            }).then(function(e) {
                s.default.info("导入题库", e), n.setData({
                    list: [].concat(t(e.questions.map(function(t) {
                        return Object.assign(t, {
                            name: "【导入】".concat(t.name)
                        });
                    })), t(n.data.list))
                });
            }) : r.default.showInfo("链接不能为空");
        };
    }
});