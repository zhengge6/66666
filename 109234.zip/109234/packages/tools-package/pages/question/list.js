module.exports = [ {
    id: "misaka-1",
    name: "默认题库",
    author: "Misaka",
    desc: "本题库涉及 计算机使用基础、Python入门、Windows系统常识、二次元常识，请不了解的用户谨慎选择。",
    content: [ {
        question: "御坂19090号在网络上搜索减肥知识，她打开了 “https://www.baidu.com/s?wd=减肥”，请问下列哪个是该网站的域名？",
        options: {
            A: "https://www.baidu.com/s?wd=减肥",
            B: "https://www.baidu.com/s",
            C: "https://www.baidu.com",
            D: "www.baidu.com"
        },
        correct: "D",
        analysis: "域名是网站的基本标识，不包含路径、参数、协议头。因此正确答案是 www.baidu.com。"
    }, {
        question: "御坂15001号正在整理文件，她发现一个文件名是 “学习资料.mp4”，请问这个文件最可能是什么类型？",
        options: {
            A: "图片文件",
            B: "视频文件",
            C: "文档文件",
            D: "音频文件"
        },
        correct: "B",
        analysis: ".mp4是常见的视频文件格式。"
    }, {
        question: "御坂16023号在网购时发现地址栏显示的是 “https://”，这表示什么？",
        options: {
            A: "网站是安全加密的",
            B: "网站正在维护",
            C: "网站内容未经工信部ICP备案",
            D: "网站禁止访问"
        },
        correct: "A",
        analysis: " https 表示网站使用了SSL/TLS加密协议，确保数据传输的安全性。"
    }, {
        question: "御坂17045号在清理电脑时发现一个文件夹名字是“Downloads”，这个文件夹通常用来存放什么？",
        options: {
            A: "下载的文件",
            B: "系统日志",
            C: "音乐文件",
            D: "视频剪辑"
        },
        correct: "A",
        analysis: "“Downloads”文件夹通常是系统默认的下载位置，用于存放从网络下载的文件。"
    }, {
        question: "御坂19090号在制作幻灯片时保存了一个文件，后缀为“.pptx”，请问这个文件最可能是用什么软件创建的？",
        options: {
            A: "Microsoft PowerPoint",
            B: "Adobe Photoshop",
            C: "Microsoft Word",
            D: "Windows Media Player"
        },
        correct: "A",
        analysis: ".pptx是Microsoft PowerPoint生成的幻灯片文件格式，广泛用于演示文稿。"
    }, {
        question: "御坂15067号在播放音乐时发现声音很小，她可以尝试做什么？",
        options: {
            A: "调高系统音量",
            B: "删除音乐文件",
            C: "重命名音乐文件",
            D: "关机重启电脑"
        },
        correct: "A",
        analysis: "声音很小时，可以先尝试调高系统音量，这通常是最直接的解决方法。"
    }, {
        question: "御坂19091号想发一张图片给朋友，但发现文件大小超过了10MB，她可以怎么做？",
        options: {
            A: "直接用邮件发送",
            B: "压缩图片后再发送",
            C: "复制图片到文档中再发送",
            D: "将图片改名后再发送"
        },
        correct: "B",
        analysis: "当图片文件过大时，可以通过压缩工具或调整分辨率来缩小图片大小再发送。"
    }, {
        question: "御坂19092号在整理文档时，发现一个文件名是 “某科学的超电磁炮.docx”，请问这个文件最可能是？",
        options: {
            A: "视频文件",
            B: "图片文件",
            C: "Word文档",
            D: "音频文件"
        },
        correct: "C",
        analysis: ".docx是Microsoft Word文档的文件格式，用于保存文字处理的内容。"
    }, {
        question: "御坂19094号想安装一个新软件，但发现存储空间不足，她应该首先做什么？",
        options: {
            A: "删除不需要的文件",
            B: "关闭所有窗口",
            C: "增加屏幕亮度",
            D: "更换键盘"
        },
        correct: "A",
        analysis: "存储空间不足时，最有效的方法是删除不需要的文件，以腾出空间安装新软件。"
    }, {
        question: "御坂15091号听说“设备指纹”技术在网上很常见，请问设备指纹的主要作用是什么？",
        options: {
            A: "识别设备的唯一性",
            B: "加快网络速度",
            C: "保护文件安全",
            D: "提高屏幕分辨率"
        },
        correct: "A",
        analysis: "设备指纹技术通过收集设备特征（如操作系统、浏览器等）来识别设备的唯一性，广泛应用于身份验证和反欺诈。"
    }, {
        question: "御坂16092号在浏览某些网站时被提示“基于设备指纹进行验证”，以下哪种信息可能会被用来生成设备指纹？",
        options: {
            A: "浏览器版本",
            B: "网络带宽",
            C: "下载文件的数量",
            D: "正在播放的音乐"
        },
        correct: "A",
        analysis: "设备指纹通常基于浏览器版本、操作系统、屏幕分辨率等信息来生成，用于唯一识别设备。"
    }, {
        question: "御坂17093号担心隐私泄露，想了解设备指纹是否会收集个人信息。以下哪项正确描述了设备指纹？",
        options: {
            A: "设备指纹会收集用户的身份证信息",
            B: "设备指纹可以存储用户的银行密码",
            C: "设备指纹会获取用户的通话记录",
            D: "设备指纹主要依赖设备特征，不直接涉及用户的隐私数据"
        },
        correct: "D",
        analysis: "设备指纹通常只收集设备的硬件和软件特征，不直接涉及用户的敏感隐私数据。"
    }, {
        question: "御坂18094号发现设备指纹被用来检测欺诈活动，请问以下哪种场景最可能用到设备指纹？",
        options: {
            A: "防止多人使用同一账号登录",
            B: "自动播放音乐",
            C: "提升图片分辨率",
            D: "修改文本文件"
        },
        correct: "A",
        analysis: "设备指纹可用于识别登录设备的唯一性，从而防止多人使用同一账号进行欺诈活动。"
    }, {
        question: "御坂19095号想知道设备指纹与传统的Cookies相比有什么不同，以下哪项正确？",
        options: {
            A: "设备指纹无需存储在设备中即可实现识别",
            B: "设备指纹需要用户手动安装",
            C: "设备指纹只能识别手机设备",
            D: "设备指纹会自动删除用户数据"
        },
        correct: "A",
        analysis: "设备指纹通过分析设备特征来进行识别，不像Cookies需要存储在设备中，因此更加持久。"
    }, {
        question: "御坂19001号收到一条短信，声称她的银行账户存在问题，并附带了一个链接，她应该怎么做？",
        options: {
            A: "不要点击链接，直接联系银行官方客服",
            B: "立即点击链接登录账户核实",
            C: "把链接发给朋友验证",
            D: "保存链接，稍后再看"
        },
        correct: "A",
        analysis: "遇到此类短信，应直接联系银行官方客服核实，避免点击不明链接以防被骗。"
    }, {
        question: "御坂16002号在登录某个网站时发现网址是“www.bank-secure.com”，但网页设计和她常用的银行官网类似，这可能是？",
        options: {
            A: "假冒网站",
            B: "银行的新子网站",
            C: "银行的备用服务器",
            D: "银行的加密网页"
        },
        correct: "A",
        analysis: "假冒网站通常伪装成真实网站，通过相似的设计诱导用户输入敏感信息。应检查官网的域名或直接联系银行确认。"
    }, {
        question: "御坂14003号在收到一封电子邮件，要求她提供密码和身份证号来验证身份，这种行为可能是？",
        options: {
            A: "网络钓鱼",
            B: "身份认证",
            C: "账户升级",
            D: "安全检查"
        },
        correct: "A",
        analysis: "网络钓鱼通过伪造邮件或信息，诱导用户提供敏感数据。正规机构不会直接索取密码等信息。"
    }, {
        question: "御坂13492号发现一个打折力度很大的网购网站，但要求直接转账付款，她应该？",
        options: {
            A: "警惕并避免交易",
            B: "立即购买以免错过折扣",
            C: "联系网站客服要求发票",
            D: "保存网站链接，稍后查看"
        },
        correct: "A",
        analysis: "要求直接转账的购物网站可能是诈骗行为。正规购物平台通常支持安全支付方式。"
    }, {
        question: "御坂12005号在支付宝或微信支付时，发现二维码的来源不明，她应该怎么做？",
        options: {
            A: "拒绝支付并确认二维码来源",
            B: "立即支付以完成交易",
            C: "将二维码分享给他人",
            D: "随意扫描以测试安全性"
        },
        correct: "A",
        analysis: "面对来源不明的二维码，拒绝支付并核实信息是最安全的做法，避免资金损失。"
    }, {
        question: "御坂13006号在浏览器地址栏发现一个绿色的锁标志，这意味着？",
        options: {
            A: "该网站使用了安全加密连接",
            B: "该网站是政府认证的",
            C: "该网站没有任何风险",
            D: "该网站无法被黑客攻击"
        },
        correct: "A",
        analysis: "绿色锁标志表示网站使用了HTTPS协议，传输数据是加密的，但并不完全保证网站内容的可信度。"
    }, {
        question: "御坂12007号在社交平台看到“转发立送红包”的信息，她应该？",
        options: {
            A: "警惕此类信息，可能是骗局",
            B: "立即转发，尝试获取红包",
            C: "向朋友推荐并一同参与",
            D: "保存信息，稍后操作"
        },
        correct: "A",
        analysis: "“转发立送红包”类信息通常是诈骗手段，可能诱导用户泄露个人信息或下载恶意软件。"
    }, {
        question: "御坂10008号在公共Wi-Fi下登录银行账户，这可能存在什么风险？",
        options: {
            A: "账户信息可能被窃取",
            B: "银行会自动冻结账户",
            C: "电脑可能会自动关机",
            D: "账户余额会增加"
        },
        correct: "A",
        analysis: "公共Wi-Fi存在被监听的风险，在此网络环境下登录敏感账户可能导致信息被窃取。"
    }, {
        question: "御坂15017号想要快速整理桌面上的文件，以下哪种方法可以帮助她？",
        options: {
            A: "右键桌面空白处，选择“按类型排列”",
            B: "打开任务管理器",
            C: "按下电源按钮关机",
            D: "更改电脑的分辨率"
        },
        correct: "A",
        analysis: "右键桌面空白处可以选择“按类型排列”、“按名称排列”等方式，帮助快速整理文件。"
    }, {
        question: "御坂15018号的电脑空间不足，以下哪种操作可以释放更多磁盘空间？",
        options: {
            A: "使用“磁盘清理”工具删除临时文件",
            B: "将文件复制到电脑的其他分区",
            C: "降低屏幕亮度",
            D: "更换鼠标"
        },
        correct: "A",
        analysis: "“磁盘清理”工具可以清理系统缓存和临时文件，从而释放磁盘空间。"
    }, {
        question: "御坂15019号想检查自己电脑的性能和内存使用情况，应该打开什么？",
        options: {
            A: "任务管理器",
            B: "控制面板",
            C: "文件资源管理器",
            D: "计算器"
        },
        correct: "A",
        analysis: "任务管理器可以显示电脑性能和内存使用情况，是监控系统运行状态的重要工具。"
    }, {
        question: "御坂15020号希望让电脑文件更容易找到，以下哪种方式是有效的？",
        options: {
            A: "为文件命名时使用有意义的名称",
            B: "将所有文件放在桌面上",
            C: "删除不常用的文件夹",
            D: "缩小文件图标大小"
        },
        correct: "A",
        analysis: "为文件命名时使用有意义的名称可以帮助快速定位文件，而不是依赖默认命名。"
    }, {
        question: "御坂15021号的电脑运行速度很慢，以下哪种方法可以尝试提升速度？",
        options: {
            A: "卸载不需要的程序",
            B: "更改桌面背景颜色",
            C: "禁用鼠标右键菜单",
            D: "使用耳机代替扬声器"
        },
        correct: "A",
        analysis: "卸载不需要的程序可以减少系统负担，从而提升电脑运行速度。"
    }, {
        question: "御坂15022号需要为电脑设置自动关机，以下操作正确的是？",
        options: {
            A: "通过任务计划程序设置关机任务",
            B: "拔掉电源",
            C: "在桌面上创建新的文件夹",
            D: "关闭所有程序后直接关机"
        },
        correct: "A",
        analysis: "任务计划程序可以设置定时任务，包括定时关机，是Windows系统的便捷工具。"
    }, {
        question: "御坂15023号发现电脑中毒了，以下哪种方法可以帮助她解决？",
        options: {
            A: "使用系统自带的“Windows Defender”进行全盘扫描",
            B: "重启电脑两次",
            C: "关闭显示器",
            D: "增加电脑的内存条"
        },
        correct: "A",
        analysis: "Windows Defender 是系统自带的防病毒软件，可以通过扫描清理电脑病毒。"
    }, {
        question: "御坂美琴的超能力被称为什么？",
        options: {
            A: "超电磁炮",
            B: "念动力",
            C: "心灵感应",
            D: "隐身术"
        },
        correct: "A",
        analysis: "御坂美琴的超能力是利用电磁力发射硬币或其他金属物体，被称为“超电磁炮”。"
    }, {
        question: "御坂美琴的能力等级是学园都市的第几等级？",
        options: {
            A: "Level 5",
            B: "Level 4",
            C: "Level 3",
            D: "Level 6"
        },
        correct: "A",
        analysis: "御坂美琴是学园都市仅有的七名Level 5超能力者之一，被称为“电击使”。"
    }, {
        question: "御坂美琴的代表性攻击方式是什么？",
        options: {
            A: "用电磁力发射硬币",
            B: "召唤火焰",
            C: "操控水流",
            D: "制造黑洞"
        },
        correct: "A",
        analysis: "御坂美琴的标志性技能是使用电磁力发射硬币，成为超电磁炮的核心招式。"
    }, {
        question: "《某科学的超电磁炮》的故事发生在以下哪座城市？",
        options: {
            A: "学园都市",
            B: "御坂市",
            C: "电磁城",
            D: "超能力都市"
        },
        correct: "A",
        analysis: "《某科学的超电磁炮》的主要故事发生在“学园都市”，一个超能力开发与科技并行的地方。"
    }, {
        question: "以下哪个角色是御坂美琴最好的朋友之一？",
        options: {
            A: "白井黑子",
            B: "食蜂操祈",
            C: "一方通行",
            D: "垣根帝督"
        },
        correct: "A",
        analysis: "白井黑子是御坂美琴的好友，也是充满喜剧色彩的角色，经常跟随在美琴身边。"
    }, {
        question: "御坂美琴最喜欢的动物是什么？",
        options: {
            A: "青蛙",
            B: "猫",
            C: "乌龟",
            D: "狗"
        },
        correct: "A",
        analysis: "御坂美琴非常喜欢呱太，她的手机挂饰是呱太（青蛙）。"
    }, {
        question: "御坂美琴在学园都市就读于哪所学校？",
        options: {
            A: "常盘台中学",
            B: "长点学园",
            C: "柊学园",
            D: "风纪委员会"
        },
        correct: "A",
        analysis: "御坂美琴就读于常盘台中学，这是一所学园都市中专门培养精英能力者的学校。"
    }, {
        question: "御坂美琴的能力可以控制以下哪种物理现象？",
        options: {
            A: "电和磁",
            B: "重力",
            C: "光速",
            D: "空气流动"
        },
        correct: "A",
        analysis: "御坂美琴的超能力与电磁相关，她可以控制电流和磁场，从而产生多种强大的技能。"
    }, {
        question: "伊蕾娜的称号是什么？",
        options: {
            A: "灰之魔女",
            B: "白之魔女",
            C: "红之魔女",
            D: "蓝之魔女"
        },
        correct: "A",
        analysis: "伊蕾娜被称为“灰之魔女”，这一称号源于她灰色的头发以及她独特的魔女身份。"
    }, {
        question: "伊蕾娜成为魔女的主要目标是什么？",
        options: {
            A: "环游世界",
            B: "保护村庄",
            C: "收集魔法书",
            D: "消灭恶魔"
        },
        correct: "A",
        analysis: "伊蕾娜的梦想是环游世界，探索各地的风土人情，记录下自己的旅程。"
    }, {
        question: "伊蕾娜的老师被称为什么魔女？",
        options: {
            A: "星之魔女",
            B: "风之魔女",
            C: "夜之魔女",
            D: "光之魔女"
        },
        correct: "A",
        analysis: "伊蕾娜的老师是“星之魔女”芙兰，负责指导伊蕾娜完成魔女修行。"
    }, {
        question: "伊蕾娜在旅途中最常用的交通工具是什么？",
        options: {
            A: "扫帚",
            B: "飞毯",
            C: "马车",
            D: "步行"
        },
        correct: "A",
        analysis: "伊蕾娜作为魔女，最常用的交通工具是扫帚，这也是魔女的经典象征之一。"
    }, {
        question: "伊蕾娜的性格可以用以下哪一个词来形容？",
        options: {
            A: "自信",
            B: "胆怯",
            C: "严肃",
            D: "冷漠"
        },
        correct: "A",
        analysis: "伊蕾娜性格自信，有时候甚至有点自恋，但这也为她的旅途增添了许多趣味。"
    }, {
        question: "以下哪个是 Python 中用于输出的函数？",
        options: {
            A: "print()",
            B: "echo()",
            C: "write()",
            D: "display()"
        },
        correct: "A",
        analysis: "Python 使用 print() 函数来输出信息到控制台，例如：print('Hello, World!')。"
    }, {
        question: "在 Python 中，用于存储多个值且不可修改的集合类型是？",
        options: {
            A: "tuple",
            B: "list",
            C: "set",
            D: "dictionary"
        },
        correct: "A",
        analysis: "tuple（元组）是不可变的有序集合，创建后不能修改。"
    }, {
        question: "以下哪个符号用来表示注释？",
        options: {
            A: "#",
            B: "//",
            C: "/* */",
            D: "--"
        },
        correct: "A",
        analysis: "在 Python 中，注释以 # 开头，后面的内容会被忽略。"
    }, {
        question: "Python 中的缩进作用是？",
        options: {
            A: "表示代码块的层次",
            B: "仅用于美化代码",
            C: "没有任何作用",
            D: "减少代码的执行时间"
        },
        correct: "A",
        analysis: "Python 使用缩进来表示代码块的层次结构，例如 if 或循环语句的内容块。"
    }, {
        question: "以下哪一个不是 Python 的数据类型？",
        options: {
            A: "array",
            B: "list",
            C: "dict",
            D: "str"
        },
        correct: "A",
        analysis: "Python 没有原生的 array 类型，但可以使用列表（list）或 numpy 提供的 array。"
    }, {
        question: "在 Python 中，如何获取列表的长度？",
        options: {
            A: "len()",
            B: "size()",
            C: "length()",
            D: "count()"
        },
        correct: "A",
        analysis: "使用 len() 函数可以获取列表的长度，例如 len([1, 2, 3]) 返回 3。"
    }, {
        question: "在 Python 中，以下哪个模块用于生成随机数？",
        options: {
            A: "random",
            B: "math",
            C: "os",
            D: "time"
        },
        correct: "A",
        analysis: "random 模块提供生成随机数的功能，例如 random.randint(1, 10)。"
    }, {
        question: "在 Linux 中，显示当前工作目录的命令是什么？",
        options: {
            A: "pwd",
            B: "ls",
            C: "cd",
            D: "dir"
        },
        correct: "A",
        analysis: "pwd（print working directory）命令用于显示当前工作目录的路径。"
    }, {
        question: "在 Linux 中，查看目录内容的命令是什么？",
        options: {
            A: "ls",
            B: "cat",
            C: "mkdir",
            D: "touch"
        },
        correct: "A",
        analysis: "ls 命令用于列出当前目录或指定目录中的文件和文件夹。"
    }, {
        question: "在 Linux 中，切换到上级目录的命令是什么？",
        options: {
            A: "cd ..",
            B: "cd ~",
            C: "cd /",
            D: "cd -"
        },
        correct: "A",
        analysis: "cd .. 命令用于切换到当前目录的上一级目录。"
    }, {
        question: "在 Linux 中，查看文件内容的命令是什么？",
        options: {
            A: "cat",
            B: "rm",
            C: "echo",
            D: "cp"
        },
        correct: "A",
        analysis: "cat 命令用于显示文件的内容，通常用来查看文本文件。"
    }, {
        question: "在 Linux 中，终止一个正在运行的进程的命令是什么？",
        options: {
            A: "kill",
            B: "stop",
            C: "halt",
            D: "end"
        },
        correct: "A",
        analysis: "kill 命令用于终止指定进程，通常通过指定进程号（PID）来执行。"
    }, {
        question: "在 Linux 中，查看系统磁盘空间的命令是什么？",
        options: {
            A: "df",
            B: "du",
            C: "lsblk",
            D: "disk"
        },
        correct: "A",
        analysis: "df 命令用于查看系统磁盘的使用情况和可用空间。"
    }, {
        question: "在 Linux 中，如何显示当前系统的内存使用情况？",
        options: {
            A: "free",
            B: "mem",
            C: "top",
            D: "ps aux"
        },
        correct: "A",
        analysis: "free 命令用于显示系统内存的使用情况，包括空闲、已使用和缓存的内存。"
    }, {
        question: "在 Linux 中，修改文件或目录权限的命令是什么？",
        options: {
            A: "chmod",
            B: "chown",
            C: "cp",
            D: "mv"
        },
        correct: "A",
        analysis: "chmod 命令用于修改文件或目录的权限，例如使文件变为可读、可写或可执行。"
    } ]
}, {
    id: "misaka-3",
    name: "台词金句题库",
    author: "Misaka",
    desc: "本题库改编自 知名电影、文学作品的台词、剧情。",
    content: [ {
        question: "在姜文电影中，梁老师的手特别____。",
        options: {
            A: "硬",
            B: "黑",
            C: "软",
            D: "大"
        },
        correct: "C",
        analysis: "姜文电影《太阳照常升起》原台词：“我只记得他的手特柔软”。"
    }, {
        question: "《猎场》中胡歌饰演的陈秋冬扔飞镖曾落到过以下哪个地方？",
        options: {
            A: "西乌尔特",
            B: "温都尔汗",
            C: "乌兰巴托",
            D: "呼伦贝尔"
        },
        correct: "B",
        analysis: "胡歌饰演的陈秋冬扔飞镖，第一镖扎在海里，第二镖扎在了温都尔汗。"
    } ]
} ];