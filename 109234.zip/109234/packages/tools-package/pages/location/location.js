var t = require("../../../../@babel/runtime/helpers/regeneratorRuntime"), e = require("../../../../@babel/runtime/helpers/asyncToGenerator"), r = i(require("@utils/config")), a = (i(require("@utils/util")), 
i(require("@utils/http"))), n = i(require("@utils/log"));

function i(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

Page({
    data: {
        wgs84: {},
        gcj02: {},
        bd09ll: {},
        marker: {
            id: 0,
            width: "40rpx",
            height: "60rpx"
        }
    },
    coordinate: function() {
        var i = arguments;
        return e(t().mark(function e() {
            var o, u, c, s, l, d, g, p;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (o = i.length > 0 && void 0 !== i[0] ? i[0] : null, u = i.length > 1 && void 0 !== i[1] ? i[1] : null, 
                    c = i.length > 2 && void 0 !== i[2] ? i[2] : "gcj02", s = i.length > 3 && void 0 !== i[3] ? i[3] : "bd09ll", 
                    d = (l = [ "wgs4", "sougou", "gcj02", null, "bd09ll" ]).indexOf(c) + 1, g = l.indexOf(s) + 1, 
                    !(d <= 0 || g <= 0)) {
                        t.next = 9;
                        break;
                    }
                    return t.abrupt("return");

                  case 9:
                    return "https://api.map.baidu.com/geoconv/v1/", t.next = 12, a.default.get({
                        url: "https://api.map.baidu.com/geoconv/v1/",
                        params: {
                            coords: "".concat(o, ",").concat(u),
                            from: d,
                            to: g,
                            ak: r.default.baiduMapKey
                        }
                    });

                  case 12:
                    return p = t.sent, n.default.info("坐标转换", p), t.abrupt("return", {
                        longitude: p.result[0].x,
                        latitude: p.result[0].y
                    });

                  case 15:
                  case "end":
                    return t.stop();
                }
            }, e);
        }))();
    },
    getLocation: function() {
        var r = this;
        wx.getLocation({
            type: "wgs84",
            altitude: !0,
            isHighAccuracy: !0,
            highAccuracyExpireTime: 3e3
        }).then(function() {
            var a = e(t().mark(function e(a) {
                var n;
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, r.coordinate(a.longitude, a.latitude, "wgs4", "gcj02");

                      case 2:
                        return n = t.sent, t.t0 = r, t.t1 = a, t.t2 = n, t.t3 = Object.assign(r.data.marker, n), 
                        t.next = 9, r.coordinate(a.longitude, a.latitude, "wgs4", "bd09ll");

                      case 9:
                        t.t4 = t.sent, t.t5 = {
                            wgs84: t.t1,
                            gcj02: t.t2,
                            marker: t.t3,
                            bd09ll: t.t4
                        }, t.t0.setData.call(t.t0, t.t5);

                      case 12:
                      case "end":
                        return t.stop();
                    }
                }, e);
            }));
            return function(t) {
                return a.apply(this, arguments);
            };
        }());
    },
    chooseLocation: function() {
        var r = this;
        wx.chooseLocation().then(function() {
            var a = e(t().mark(function e(a) {
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.t0 = r, t.t1 = {}, t.t2 = a, t.t3 = Object.assign(r.data.marker, a), t.next = 6, 
                        r.coordinate(a.longitude, a.latitude, "gcj02", "bd09ll");

                      case 6:
                        t.t4 = t.sent, t.t5 = {
                            wgs84: t.t1,
                            gcj02: t.t2,
                            marker: t.t3,
                            bd09ll: t.t4
                        }, t.t0.setData.call(t.t0, t.t5);

                      case 9:
                      case "end":
                        return t.stop();
                    }
                }, e);
            }));
            return function(t) {
                return a.apply(this, arguments);
            };
        }());
    },
    copy: function(t) {
        var e = t.target.dataset.content;
        wx.setClipboardData({
            data: e
        });
    },
    onShareAppMessage: function() {
        return {
            path: "/packages/tools-package/pages/location/location",
            title: "坐标拾取工具",
            imageUrl: "/static/share.png"
        };
    }
});