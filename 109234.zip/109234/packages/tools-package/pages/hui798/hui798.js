var t = require("../../../../@babel/runtime/helpers/defineProperty"), a = (o(require("@utils/config")), 
o(require("@utils/util"))), i = o(require("@utils/http")), e = o(require("@utils/log"));

function o(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

Page({
    data: {
        text: {
            1: {
                status: "运行中",
                action: "立即结算",
                style: "background: #ffae52"
            },
            99: {
                status: "在线",
                action: "立即使用",
                style: ""
            },
            10: {
                status: "运行中",
                action: "他人在用",
                style: "background: gray"
            }
        }
    },
    onLoad: function(t) {
        this.data.info = a.default.getStorage("hui798", {}), this.data.info.token ? this.init() : this.setData({
            random: Math.random(),
            timestape: Math.floor(new Date()),
            mode: "login"
        });
    },
    onReady: function() {
        var o = this;
        this.input = function(a) {
            o.setData(t({}, a.currentTarget.dataset.input, a.detail.value));
        }, this.sendSms = function(t) {
            i.default.post({
                url: "https://i.ilife798.com/api/v1/acc/login/code",
                body: {
                    un: o.data.mobile,
                    authCode: o.data.imgCode,
                    s: o.data.random
                }
            }).then(function(t) {
                a.default.showInfo("已发送短信验证码"), e.default.info("发送短信验证码", t), 0 == t.code && o.setData({
                    disableSendSms: !0
                });
            });
        }, this.login = function(t) {
            i.default.post({
                url: "https://i.ilife798.com/api/v1/acc/login",
                body: {
                    authCode: o.data.smsCode,
                    un: o.data.mobile,
                    cid: "",
                    openCode: ""
                }
            }).then(function(t) {
                e.default.info("登录", t), 0 == t.code && (a.default.setStorage("hui798", t.data.al), 
                a.default.showInfo("登录成功"), wx.redirectTo({
                    url: "./hui798"
                }));
            });
        };
    },
    init: function() {
        var t = this;
        i.default.get({
            url: "https://i.ilife798.com/api/v1/ad/swtich",
            cookies: {
                Authorization: this.data.info.token
            }
        }).then(function(t) {}).catch(function(t) {}), i.default.get({
            url: "https://i.ilife798.com/api/v1/ui/app/master",
            cookies: {
                Authorization: this.data.info.token
            }
        }).then(function(i) {
            var o, n, u;
            e.default.info("首页信息", i), 0 == i.code && null != i && null !== (o = i.data) && void 0 !== o && o.account ? t.setData({
                mode: "home",
                favorites: (null == i || null === (n = i.data) || void 0 === n ? void 0 : n.favos) || [],
                userinfo: null == i || null === (u = i.data) || void 0 === u ? void 0 : u.account
            }, function() {
                setInterval(function() {
                    t.data.favorites.forEach(function(a) {
                        "show" == t.data.page && t.status(a.id);
                    });
                }, 1500);
            }) : (a.default.setStorage("hui798", {}), wx.redirectTo({
                url: "./hui798"
            }));
        });
    },
    status: function(t) {
        var a = this;
        i.default.get({
            url: "https://i.ilife798.com/api/v1/ui/app/dev/status",
            params: {
                did: t,
                more: !1,
                promo: !1
            },
            cookies: {
                Authorization: this.data.info.token
            },
            showLoading: !1
        }).then(function(i) {
            e.default.info("获取设备状态", t, i), a.setData({
                favorites: a.data.favorites.map(function(t) {
                    var a, e, o, n;
                    return t.id == (null == i || null === (a = i.data) || void 0 === a || null === (e = a.device) || void 0 === e ? void 0 : e.id) ? Object.assign(t, {
                        gene: null == i || null === (o = i.data) || void 0 === o || null === (n = o.device) || void 0 === n ? void 0 : n.gene
                    }) : t;
                })
            });
        });
    },
    action: function(t) {
        var a = t.currentTarget.dataset.action, o = t.currentTarget.dataset.id;
        a ? "立即使用" != a ? "立即结算" != a || i.default.get({
            url: "https://i.ilife798.com/api/v1/dev/end",
            params: {
                did: o
            },
            cookies: {
                Authorization: this.data.info.token
            }
        }).then(function(t) {
            e.default.info("停止设备", t);
        }) : i.default.get({
            url: "https://i.ilife798.com/api/v1/dev/start",
            params: {
                did: o,
                upgrade: !0,
                ptype: 21,
                rcp: !1
            },
            cookies: {
                Authorization: this.data.info.token
            }
        }).then(function(t) {
            e.default.info("开启设备", t);
        }) : this.status(o);
    },
    onShow: function() {
        this.data.page = "show";
    },
    onUnload: function() {
        this.data.page = "hide";
    },
    onHide: function() {
        this.data.page = "hide";
    }
});