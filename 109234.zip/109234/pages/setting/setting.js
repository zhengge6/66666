var t = e(require("@utils/util"));

e(require("@utils/log"));

function e(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var n = {
    "爱学习": "release" != t.default.info.miniProgram.envVersion,
    "计算器": !0,
    "惠生活": !1,
    "在线答题": !0,
    "运动健身": !0,
    "扫码器": !0,
    "坐标拾取": !1
};

Page({
    data: {
        home: [],
        logo: __wxConfig.accountInfo.icon
    },
    onShow: function() {
        Object.assign(n, t.default.getStorage("home-switch", {})), this.setData({
            version: t.default.info.miniProgram.version || t.default.info.miniProgram.envVersion,
            home: Array.from(Object.keys(n), function(t) {
                return {
                    name: t,
                    value: n[t]
                };
            })
        });
    },
    onReady: function() {
        var e = this;
        this.output = function(e) {
            var n = wx.getLogManager(), o = t.default.getStorage("log.base", []);
            o.forEach(function(t) {
                return n.info(t);
            }), wx.getFileSystemManager().writeFile({
                filePath: "".concat(wx.env.USER_DATA_PATH, "/log.txt"),
                data: JSON.stringify(o),
                encoding: "utf8",
                success: function(t) {
                    wx.openDocument({
                        filePath: "".concat(wx.env.USER_DATA_PATH, "/log.txt")
                    });
                }
            });
        }, this.switch = function(o) {
            n[o.currentTarget.dataset.switch] = !n[o.currentTarget.dataset.switch], t.default.setStorage("home-switch", n), 
            e.setData({
                home: Array.from(Object.keys(n), function(t) {
                    return {
                        name: t,
                        value: n[t]
                    };
                })
            });
        }, this.clear = function(t) {
            wx.showModal({
                title: "确定注销小程序吗？",
                content: "注销将会清除小程序数据"
            }).then(function(t) {
                t.confirm && (wx.clearStorageSync(), wx.exitMiniProgram());
            });
        }, this.closePopup = function(t) {
            e.setData({
                popup: !1
            });
        }, this.openPopup = function(t) {
            e.setData({
                popup: t.currentTarget.dataset.popup
            });
        };
    }
});