require("../../@babel/runtime/helpers/Objectentries"), require("../../@babel/runtime/helpers/Arrayincludes");

var t, e = require("../../@babel/runtime/helpers/slicedToArray"), a = o(require("@utils/config")), n = o(require("@utils/util")), i = o(require("@utils/log"));

function o(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var r = [ "青，取之于蓝而青于蓝；冰，水为之而寒于水", "海内存知己，天涯若比邻", "千门万户曈曈日，总把新桃换旧府", "与君初相识，犹如故人归", "有朋自远方来，不亦乐乎", "剑阁峥嵘而崔嵬，一夫当关，万夫莫开", "千门万户曈曈日，总把新桃换旧符", "休对故人思故国，且将新火试新茶" ];

Page({
    data: {
        vedioAd: !0,
        type: "share",
        adId: null === (t = a.default.advertise[n.default.info.miniProgram.appId]) || void 0 === t ? void 0 : t.custom
    },
    onLoad: function(t) {
        var e = this;
        if (i.default.info("进入分享页", t), wx.hideHomeButton(), t.q) {
            var a = decodeURIComponent(t.q);
            this.options.timestape = parseInt(t.scancode_time);
            var n = {};
            a.split("?")[1].split("&").forEach(function(t) {
                var e = t.split("="), a = decodeURIComponent(e[0]), i = decodeURIComponent(e[1]);
                n[a] = i;
            }), i.default.info("二维码参数", n), Object.assign(this.options, n);
        }
        if (t.scene) {
            var o = decodeURIComponent(t.scene), s = {};
            o.split("&").forEach(function(t) {
                var e = t.split("="), a = decodeURIComponent(e[0]), n = decodeURIComponent(e[1]);
                s[a] = n;
            }), i.default.info("小程序码参数", s), Object.assign(this.options, s);
        }
        setTimeout(function() {
            e.setData({
                path: t.path || "",
                appid: t.appid || "",
                isLoad: !0
            });
        }, 1250);
        var c = function() {
            e.setData({
                title: r[Math.floor(Math.random() * r.length)]
            });
        };
        c(), setInterval(c, 2500), "true" == t.auto && this.to();
    },
    back: function() {
        wx.switchTab({
            url: "/pages/home/home"
        });
    },
    to: function() {
        var t = this.options.path || null, a = Object.entries(this.options).map(function(t) {
            var a = e(t, 2), n = a[0], i = a[1];
            return [ "path", "appid", "package", "auto" ].includes(n) ? "" : "".concat(n, "=").concat(i);
        }).filter(function(t) {
            return t.length;
        }).join("&");
        if (this.options.appid) wx.openEmbeddedMiniProgram({
            appId: this.options.appid,
            path: t ? "".concat(t, "?").concat(a) : "",
            allowFullScreen: !0
        }); else if (this.options.appid) ; else {
            var n = "".concat(this.options.package, "-package");
            wx.navigateTo({
                url: "/packages/".concat(n, "/pages").concat(t, "?").concat(a)
            });
        }
    },
    onShareAppMessage: function() {
        var t = Object.entries(this.options).map(function(t) {
            var a = e(t, 2), n = a[0], i = a[1];
            return "".concat(n, "=").concat(i);
        }).join("&");
        return i.default.info("分享", t), {
            path: "/pages/share/share?".concat(t),
            title: "御坂网络 Misaka",
            imageUrl: "/static/share.png"
        };
    },
    onShareTimeline: function() {
        var t = Object.entries(this.options).map(function(t) {
            var a = e(t, 2), n = a[0], i = a[1];
            return "".concat(n, "=").concat(i);
        }).join("&");
        return i.default.info("分享朋友圈", t), {
            title: "御坂网络 Misaka",
            imageUrl: "/static/share.png",
            query: t
        };
    },
    onAddToFavorites: function() {
        var t = Object.entries(this.options).map(function(t) {
            var a = e(t, 2), n = a[0], i = a[1];
            return "".concat(n, "=").concat(i);
        }).join("&");
        return i.default.info("收藏", t), {
            query: t,
            title: "御坂网络 Misaka",
            imageUrl: "/static/share.png"
        };
    }
});