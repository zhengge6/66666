var t, a, e = n(require("@utils/config")), i = n(require("@utils/util")), d = n(require("@utils/log"));

function n(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var o = null;

Page({
    data: {
        status: !1,
        text: "",
        adId: null === (t = e.default.advertise[i.default.info.miniProgram.appId]) || void 0 === t ? void 0 : t.custom,
        rewardId: (null === (a = e.default.advertise[i.default.info.miniProgram.appId]) || void 0 === a ? void 0 : a.reward) || null
    },
    onLoad: function(t) {
        var a = this;
        wx.hideHomeButton(), setTimeout(function() {
            t.appid && a.play(), a.setData({
                isLoad: !0,
                text: a.data.rewardId ? "激励广告" : "前往播放"
            });
        }, 1200), this.data.rewardId && ((o = wx.createRewardedVideoAd({
            adUnitId: this.data.rewardId
        })).onError(function(t) {
            d.default.info("激励广告失败事件", t), t.errMsg.includes("no ad unit id") && a.toAd();
        }), o.onClose(function(t) {
            d.default.info("激励广告结束事件", t), a.setData({
                status: t && t.isEnded
            });
        }), o.load());
    },
    toAd: function() {
        wx.openEmbeddedMiniProgram({
            appId: e.default.advertiseAppId,
            path: "".concat(e.default.advertiseAppPath, "?appid=").concat(i.default.info.miniProgram.appId),
            envVersion: "release",
            allowFullScreen: !0
        });
    },
    onShow: function() {
        var t, a = wx.getEnterOptionsSync(), e = (null == a || null === (t = a.referrerInfo) || void 0 === t ? void 0 : t.extraData) || null;
        e && e.appid == i.default.info.miniProgram.appId && this.setData({
            status: e.result
        });
    },
    play: function() {
        var t = this;
        this.data.rewardId && (i.default.showLoading("正在加载广告"), o.load().then(function() {
            return o.show();
        }).then(function() {
            return i.default.hideLoading();
        }).then(function() {
            return t.setData({
                text: "重新播放"
            });
        }).catch(function(t) {
            d.default.info("激励广告加载/播放失败", t), i.default.showInfo("广告加载失败"), i.default.hideLoading();
        })), this.data.rewardId || this.toAd();
    },
    onUnload: function() {
        o.destroy();
    },
    back: function() {
        var t = {
            result: this.data.status,
            type: "ad",
            appid: this.options.appid
        };
        this.options.appid && i.default.info.miniProgram.appId != this.options.appid ? wx.navigateBackMiniProgram({
            extraData: t
        }) : (wx.navigateBack(), this.getOpenerEventChannel().emit("extraData", t));
    }
});