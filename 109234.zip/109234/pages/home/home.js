require("../../@babel/runtime/helpers/Objectentries");

var e, a = require("../../@babel/runtime/helpers/slicedToArray"), t = n(require("@utils/api")), i = n(require("@utils/config")), s = n(require("@utils/util")), o = n(require("@utils/log"));

function n(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var c = [ {
    name: "爱学习",
    default: "release" != s.default.info.miniProgram.envVersion,
    desc: "不学怎么行",
    image: "/static/svg/home-icon/sign.svg",
    url: "/packages/sign-package/pages/home/home"
}, {
    name: "计算器",
    default: !0,
    desc: "遥遥领先",
    image: "/static/svg/home-icon/cal.svg",
    url: "/packages/tools-package/pages/calc/calc"
}, {
    name: "惠生活",
    default: !1,
    desc: "惠生活 798",
    image: "/static/svg/home-icon/cal.svg",
    url: "/packages/tools-package/pages/hui798/hui798"
}, {
    name: "在线答题",
    default: !0,
    desc: "精选优质题库",
    image: "/static/svg/home-icon/question.svg",
    url: "/packages/tools-package/pages/question/question"
}, {
    name: "运动健身",
    default: !0,
    desc: "爱运动身体棒",
    image: "/static/svg/home-icon/sport.svg",
    url: "/packages/tools-package/pages/sport/sport"
}, {
    name: "扫码器",
    default: !0,
    desc: "扫一扫更快乐",
    image: "/static/svg/home-icon/scan.svg",
    url: "/packages/sign-package/pages/scan/scan"
}, {
    name: "坐标拾取",
    default: !1,
    desc: "获取当前坐标",
    image: "/static/svg/home-icon/location.svg",
    url: "/packages/tools-package/pages/location/location"
}, {
    name: "爱看广告",
    default: !0,
    desc: "看广告爽一下",
    image: "/static/svg/home-icon/ad.svg",
    url: "/pages/advertise/advertise"
}, {
    name: "设置",
    default: !0,
    desc: "高级选项",
    image: "/static/svg/home-icon/setting.svg",
    url: "/pages/setting/setting"
} ];

Page({
    data: {
        swiperList: i.default.swiperList,
        notice: i.default.notice,
        adId: null === (e = i.default.advertise[s.default.info.miniProgram.appId]) || void 0 === e ? void 0 : e.custom
    },
    onShow: function() {
        var e = s.default.getStorage("home-switch", {});
        this.setData({
            env: s.default.getStorage("env", s.default.info.miniProgram.envVersion),
            home: c.filter(function(a) {
                var t;
                return null !== (t = e[a.name]) && void 0 !== t ? t : a.default;
            })
        });
    },
    onLoad: function(e) {
        var a = this;
        t.default.getSysConfig("global").then(function(e) {
            var t, i, o, n = s.default.getStorage("last-dialog-id", null), c = null === (t = e.home) || void 0 === t ? void 0 : t.id;
            n != c && a.setData({
                dialog: (null === (i = e.home) || void 0 === i ? void 0 : i.dialog) || {}
            }, function() {
                return a.confirm = function() {
                    a.setData({
                        "dialog.content": ""
                    });
                };
            }, s.default.setStorage("last-dialog-id", c)), s.default.setStorage("config.base", Object.assign(s.default.getStorage("config.base", {}), (null === (o = e.config) || void 0 === o ? void 0 : o.base) || {}, (e.config || {})[s.default.info.appId] || {}));
        });
    },
    navigate: function(e) {
        wx.navigateTo({
            url: e.currentTarget.dataset.url
        });
    },
    onShareAppMessage: function() {
        var e = Object.entries(this.options).map(function(e) {
            var t = a(e, 2), i = t[0], s = t[1];
            return "".concat(i, "=").concat(s);
        }).join("&");
        return o.default.info("分享", e), {
            title: "御坂网络 Misaka",
            imageUrl: "/static/share.png",
            path: "/pages/home/home?".concat(e)
        };
    },
    onShareTimeline: function() {
        return {
            title: "御坂网络 Misaka",
            imageUrl: "/static/share.png",
            query: Object.entries(this.options).map(function(e) {
                var t = a(e, 2), i = t[0], s = t[1];
                return "".concat(i, "=").concat(s);
            }).join("&")
        };
    }
});