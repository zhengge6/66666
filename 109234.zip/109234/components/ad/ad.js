Component({
    properties: {
        text: {
            type: String,
            value: "Misaka为您关闭了广告"
        },
        aid: {
            type: null,
            value: null
        },
        margin: {
            type: String,
            value: "0"
        }
    },
    lifetimes: {
        attached: function() {}
    },
    methods: {
        close: function(t) {
            var e = this;
            this.setData({
                close: !0
            }), setTimeout(function() {
                e.setData({
                    close: !1
                });
            }, 1e4);
        }
    }
});