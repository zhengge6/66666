Component({
    properties: {
        text: {
            type: String,
            value: "暂无数据"
        },
        desc: {
            type: String,
            value: ""
        }
    },
    lifetimes: {
        attached: function() {}
    },
    methods: {}
});