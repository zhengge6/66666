Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.SuperComponent = void 0;

var e = require("../../../../@babel/runtime/helpers/createClass"), r = require("../../../../@babel/runtime/helpers/classCallCheck");

exports.SuperComponent = e(function e() {
    r(this, e), this.app = getApp();
});