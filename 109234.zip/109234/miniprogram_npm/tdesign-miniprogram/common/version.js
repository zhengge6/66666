Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.canIUseFormFieldButton = function() {
    return n("2.10.3");
}, exports.canUseVirtualHost = function() {
    return n("2.19.2");
}, exports.compareVersion = t;

var e, r = require("./wechat");

function t(e, r) {
    e = e.split("."), r = r.split(".");
    for (var t = Math.max(e.length, r.length); e.length < t; ) e.push("0");
    for (;r.length < t; ) r.push("0");
    for (var n = 0; n < t; n++) {
        var o = parseInt(e[n]), s = parseInt(r[n]);
        if (o > s) return 1;
        if (o < s) return -1;
    }
    return 0;
}

function n(n) {
    return t((null == e && (e = (0, r.getAppBaseInfo)()), e).SDKVersion, n) >= 0;
}