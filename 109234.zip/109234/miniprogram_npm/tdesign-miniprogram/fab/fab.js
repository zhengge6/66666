Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), o = require("../../../@babel/runtime/helpers/getPrototypeOf"), n = require("../../../@babel/runtime/helpers/inherits"), i = require("../../../@babel/runtime/helpers/typeof"), s = require("../common/src/index"), a = p(require("../common/config")), c = p(require("./props")), u = p(require("../mixins/using-custom-navbar")), l = require("../common/utils");

function p(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function f(e, t, n) {
    return t = o(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, n || [], o(e).constructor) : t.apply(e, n));
}

var d = function(e, t, r, o) {
    var n, s = arguments.length, a = s < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, r) : o;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : i(Reflect)) && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, r, o); else for (var c = e.length - 1; c >= 0; c--) (n = e[c]) && (a = (s < 3 ? n(a) : s > 3 ? n(t, r, a) : n(t, r)) || a);
    return s > 3 && a && Object.defineProperty(t, r, a), a;
}, h = a.default.prefix, b = "".concat(h, "-fab"), m = {
    size: "large",
    shape: "circle",
    theme: "primary",
    externalClass: "".concat(h, "-fab__button")
}, v = function(r) {
    function o() {
        var e;
        return t(this, o), (e = f(this, o, arguments)).behaviors = [ u.default ], e.properties = c.default, 
        e.externalClasses = [ "class", "".concat(h, "-class"), "".concat(h, "-class-button") ], 
        e.data = {
            prefix: h,
            classPrefix: b,
            buttonData: m,
            moveStyle: null
        }, e.observers = {
            "buttonProps.**, icon, text, ariaLabel, yBounds": function() {
                var e;
                this.setData({
                    buttonData: Object.assign(Object.assign(Object.assign(Object.assign({}, m), {
                        shape: this.properties.text ? "round" : "circle",
                        icon: this.properties.icon
                    }), this.properties.buttonProps), {
                        content: this.properties.text,
                        ariaLabel: this.properties.ariaLabel
                    })
                }, null === (e = this.computedSize) || void 0 === e ? void 0 : e.bind(this));
            }
        }, e.methods = {
            onTplButtonTap: function(e) {
                this.triggerEvent("click", e);
            },
            onMove: function(e) {
                var t = this.properties.yBounds, r = this.data.distanceTop, o = e.detail, n = o.x, i = o.y, s = o.rect, a = l.systemInfo.windowWidth - s.width, c = l.systemInfo.windowHeight - Math.max(r, (0, 
                l.unitConvert)(t[0])) - s.height, u = Math.max(0, Math.min(n, a)), p = Math.max(0, (0, 
                l.unitConvert)(t[1]), Math.min(i, c));
                this.setData({
                    moveStyle: "right: ".concat(u, "px; bottom: ").concat(p, "px;")
                });
            },
            computedSize: function() {
                var e, t;
                if (this.properties.draggable) {
                    var r = this.selectComponent("#draggable");
                    (null === (t = null === (e = this.properties) || void 0 === e ? void 0 : e.yBounds) || void 0 === t ? void 0 : t[1]) ? this.setData({
                        moveStyle: "bottom: ".concat((0, l.unitConvert)(this.properties.yBounds[1]), "px")
                    }, r.computedRect) : r.computedRect();
                }
            }
        }, e;
    }
    return n(o, r), e(o);
}(s.SuperComponent);

v = d([ (0, s.wxComponent)() ], v);

exports.default = v;