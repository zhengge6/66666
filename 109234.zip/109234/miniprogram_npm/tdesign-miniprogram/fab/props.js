Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    buttonProps: {
        type: Object
    },
    draggable: {
        type: null,
        value: !1
    },
    icon: {
        type: String,
        value: ""
    },
    style: {
        type: String,
        value: "right: 16px; bottom: 32px;"
    },
    text: {
        type: String,
        value: ""
    },
    usingCustomNavbar: {
        type: Boolean,
        value: !1
    },
    yBounds: {
        type: Array
    }
};

exports.default = e;