Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), i = require("../../../@babel/runtime/helpers/getPrototypeOf"), n = require("../../../@babel/runtime/helpers/inherits"), o = require("../../../@babel/runtime/helpers/typeof"), a = require("../common/src/index"), c = d(require("./props")), s = d(require("../common/config")), l = require("../common/utils"), u = require("../common/version");

function d(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function f(e, t, n) {
    return t = i(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, n || [], i(e).constructor) : t.apply(e, n));
}

var p = function(e, t, r, i) {
    var n, a = arguments.length, c = a < 3 ? t : null === i ? i = Object.getOwnPropertyDescriptor(t, r) : i;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : o(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, t, r, i); else for (var s = e.length - 1; s >= 0; s--) (n = e[s]) && (c = (a < 3 ? n(c) : a > 3 ? n(t, r, c) : n(t, r)) || c);
    return a > 3 && c && Object.defineProperty(t, r, c), c;
}, h = s.default.prefix, g = "".concat(h, "-image"), m = function(r) {
    function i() {
        var e;
        return t(this, i), (e = f(this, i, arguments)).externalClasses = [ "".concat(h, "-class"), "".concat(h, "-class-load"), "".concat(h, "-class-image"), "".concat(h, "-class-error") ], 
        e.options = {
            multipleSlots: !0
        }, e.properties = c.default, e.data = {
            prefix: h,
            isLoading: !0,
            isFailed: !1,
            innerStyle: "",
            classPrefix: g
        }, e.preSrc = "", e.observers = {
            src: function() {
                this.preSrc !== this.properties.src && this.update();
            },
            "width, height": function(e, t) {
                this.calcSize(e, t);
            }
        }, e.methods = {
            onLoaded: function(e) {
                var t = this, r = l.appBaseInfo.SDKVersion, i = this.properties, n = i.mode, o = i.tId, a = (0, 
                u.compareVersion)(r, "2.10.3") < 0;
                if ("heightFix" === n && a) {
                    var c = e.detail, s = c.height, d = c.width;
                    (0, l.getRect)(this, "#".concat(o || "image")).then(function(e) {
                        var r = e.height, i = (r / s * d).toFixed(2);
                        t.setData({
                            innerStyle: "height: ".concat((0, l.addUnit)(r), "; width: ").concat(i, "px;")
                        });
                    });
                }
                this.setData({
                    isLoading: !1,
                    isFailed: !1
                }), this.triggerEvent("load", e.detail);
            },
            onLoadError: function(e) {
                this.setData({
                    isLoading: !1,
                    isFailed: !0
                }), this.triggerEvent("error", e.detail);
            },
            calcSize: function(e, t) {
                var r = "";
                e && (r += "width: ".concat((0, l.addUnit)(e), ";")), t && (r += "height: ".concat((0, 
                l.addUnit)(t), ";")), this.setData({
                    innerStyle: r
                });
            },
            update: function() {
                var e = this.properties.src;
                this.preSrc = e, e ? this.setData({
                    isLoading: !0,
                    isFailed: !1
                }) : this.onLoadError({
                    errMsg: "图片链接为空"
                });
            }
        }, e;
    }
    return n(i, r), e(i);
}(a.SuperComponent);

m = p([ (0, a.wxComponent)() ], m);

exports.default = m;