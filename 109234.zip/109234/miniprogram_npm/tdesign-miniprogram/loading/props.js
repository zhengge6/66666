Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    delay: {
        type: Number,
        value: 0
    },
    duration: {
        type: Number,
        value: 800
    },
    externalClasses: {
        type: Array
    },
    indicator: {
        type: Boolean,
        value: !0
    },
    inheritColor: {
        type: Boolean,
        value: !1
    },
    layout: {
        type: String,
        value: "horizontal"
    },
    loading: {
        type: Boolean,
        value: !0
    },
    pause: {
        type: Boolean,
        value: !1
    },
    progress: {
        type: Number
    },
    reverse: {
        type: Boolean
    },
    size: {
        type: String,
        value: "40rpx"
    },
    text: {
        type: String
    },
    theme: {
        type: String,
        value: "circular"
    }
};

exports.default = e;