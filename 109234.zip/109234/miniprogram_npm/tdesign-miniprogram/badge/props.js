Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    color: {
        type: String,
        value: ""
    },
    content: {
        type: String,
        value: ""
    },
    count: {
        type: null,
        value: 0
    },
    dot: {
        type: Boolean,
        value: !1
    },
    externalClasses: {
        type: Array
    },
    maxCount: {
        type: Number,
        value: 99
    },
    offset: {
        type: Array
    },
    shape: {
        type: String,
        value: "circle"
    },
    showZero: {
        type: Boolean,
        value: !1
    },
    size: {
        type: String,
        value: "medium"
    }
};

exports.default = e;