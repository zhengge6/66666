Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/classCallCheck"), t = require("../../../@babel/runtime/helpers/createClass"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), i = require("../../../@babel/runtime/helpers/inherits"), a = require("../../../@babel/runtime/helpers/typeof"), s = require("../common/src/index"), l = o(require("../common/config")), c = o(require("./props")), u = require("../common/utils");

function o(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function f(e, t, i) {
    return t = n(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, i || [], n(e).constructor) : t.apply(e, i));
}

var h = function(e, t, r, n) {
    var i, s = arguments.length, l = s < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : a(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(e, t, r, n); else for (var c = e.length - 1; c >= 0; c--) (i = e[c]) && (l = (s < 3 ? i(l) : s > 3 ? i(t, r, l) : i(t, r)) || l);
    return s > 3 && l && Object.defineProperty(t, r, l), l;
}, v = l.default.prefix, p = "".concat(v, "-search"), d = function(r) {
    function n() {
        var t;
        return e(this, n), (t = f(this, n, arguments)).externalClasses = [ "".concat(v, "-class"), "".concat(v, "-class-input-container"), "".concat(v, "-class-input"), "".concat(v, "-class-action"), "".concat(v, "-class-left"), "".concat(v, "-class-clear") ], 
        t.options = {
            multipleSlots: !0
        }, t.properties = c.default, t.observers = {
            resultList: function(e) {
                var t = this.data.isSelected;
                e.length ? t ? this.setData({
                    isShowResultList: !1,
                    isSelected: !1
                }) : this.setData({
                    isShowResultList: !0
                }) : this.setData({
                    isShowResultList: !1
                });
            }
        }, t.data = {
            classPrefix: p,
            prefix: v,
            isShowResultList: !1,
            isSelected: !1
        }, t;
    }
    return i(n, r), t(n, [ {
        key: "onInput",
        value: function(e) {
            var t = e.detail.value, r = this.properties.maxcharacter;
            r && "number" == typeof r && r > 0 && (t = (0, u.getCharacterLength)("maxcharacter", t, r).characters);
            this.setData({
                value: t
            }), this.triggerEvent("change", {
                value: t
            });
        }
    }, {
        key: "onFocus",
        value: function(e) {
            var t = e.detail.value;
            this.triggerEvent("focus", {
                value: t
            });
        }
    }, {
        key: "onBlur",
        value: function(e) {
            var t = e.detail.value;
            this.triggerEvent("blur", {
                value: t
            });
        }
    }, {
        key: "handleClear",
        value: function() {
            this.setData({
                value: ""
            }), this.triggerEvent("clear", {
                value: ""
            }), this.triggerEvent("change", {
                value: ""
            });
        }
    }, {
        key: "onConfirm",
        value: function(e) {
            var t = e.detail.value;
            this.triggerEvent("submit", {
                value: t
            });
        }
    }, {
        key: "onActionClick",
        value: function() {
            this.triggerEvent("action-click");
        }
    }, {
        key: "onSelectResultItem",
        value: function(e) {
            var t = e.currentTarget.dataset.index, r = this.properties.resultList[t];
            this.setData({
                value: r,
                isSelected: !0
            }), this.triggerEvent("change", {
                value: r
            }), this.triggerEvent("selectresult", {
                index: t,
                item: r
            });
        }
    } ]);
}(s.SuperComponent);

d = h([ (0, s.wxComponent)() ], d);

exports.default = d;