Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    content: {
        type: null
    },
    direction: {
        type: String,
        value: "horizontal"
    },
    interval: {
        type: Number,
        value: 2e3
    },
    marquee: {
        type: null,
        value: !1
    },
    operation: {
        type: String
    },
    prefixIcon: {
        type: null,
        value: !0
    },
    suffixIcon: {
        type: null
    },
    theme: {
        type: String,
        value: "info"
    },
    visible: {
        type: Boolean,
        value: null
    },
    defaultVisible: {
        type: Boolean,
        value: !1
    }
};

exports.default = e;