Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), o = require("../../../@babel/runtime/helpers/inherits"), c = require("../../../@babel/runtime/helpers/typeof"), u = require("../common/src/index"), i = s(require("../common/config")), l = s(require("./props"));

function s(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function a(e, t, o) {
    return t = n(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, o || [], n(e).constructor) : t.apply(e, o));
}

var f = function(e, t, r, n) {
    var o, u = arguments.length, i = u < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : c(Reflect)) && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, r, n); else for (var l = e.length - 1; l >= 0; l--) (o = e[l]) && (i = (u < 3 ? o(i) : u > 3 ? o(t, r, i) : o(t, r)) || i);
    return u > 3 && i && Object.defineProperty(t, r, i), i;
}, p = i.default.prefix, d = "".concat(p, "-cell-group"), h = function(r) {
    function n() {
        var e;
        return t(this, n), (e = a(this, n, arguments)).externalClasses = [ "".concat(p, "-class"), "".concat(p, "-class-title") ], 
        e.relations = {
            "../cell/cell": {
                type: "child",
                linked: function() {
                    this.updateLastChid();
                },
                unlinked: function() {
                    this.updateLastChid();
                }
            }
        }, e.properties = l.default, e.data = {
            prefix: p,
            classPrefix: d
        }, e.methods = {
            updateLastChid: function() {
                var e = this.$children;
                e.forEach(function(t, r) {
                    return t.setData({
                        isLastChild: r === e.length - 1
                    });
                });
            }
        }, e;
    }
    return o(n, r), e(n);
}(u.SuperComponent);

h = f([ (0, u.wxComponent)() ], h);

exports.default = h;