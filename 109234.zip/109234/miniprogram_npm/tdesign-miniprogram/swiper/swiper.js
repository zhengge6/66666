Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), i = require("../../../@babel/runtime/helpers/inherits"), a = require("../../../@babel/runtime/helpers/typeof"), o = require("../common/src/index"), c = u(require("../common/config")), s = u(require("./props"));

function u(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function l(e, t, i) {
    return t = n(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, i || [], n(e).constructor) : t.apply(e, i));
}

var f = function(e, t, r, n) {
    var i, o = arguments.length, c = o < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : a(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, t, r, n); else for (var s = e.length - 1; s >= 0; s--) (i = e[s]) && (c = (o < 3 ? i(c) : o > 3 ? i(t, r, c) : i(t, r)) || c);
    return o > 3 && c && Object.defineProperty(t, r, c), c;
}, p = c.default.prefix, d = "".concat(p, "-swiper"), h = function(r) {
    function n() {
        var e;
        return t(this, n), (e = l(this, n, arguments)).externalClasses = [ "".concat(p, "-class"), "".concat(p, "-class-nav"), "".concat(p, "-class-image"), "".concat(p, "-class-prev-image"), "".concat(p, "-class-next-image") ], 
        e.options = {
            multipleSlots: !0
        }, e.properties = s.default, e.observers = {
            navCurrent: function(e) {
                this.updateNav(e);
            }
        }, e.$nav = null, e.relations = {
            "../swiper-nav/swiper-nav": {
                type: "child"
            }
        }, e.data = {
            prefix: p,
            classPrefix: d
        }, e.lifetimes = {
            ready: function() {
                var e = this.properties.current;
                this.setData({
                    navCurrent: e
                });
            }
        }, e.methods = {
            updateNav: function(e) {
                var t;
                if (!this.data.navigation) {
                    var r = null === (t = this.getRelationNodes("./swiper-nav")) || void 0 === t ? void 0 : t[0];
                    if (r) {
                        var n = this.properties, i = n.direction, a = n.paginationPosition, o = n.list;
                        r.setData({
                            current: e,
                            total: o.length,
                            direction: i,
                            paginationPosition: a
                        });
                    }
                }
            },
            onTap: function(e) {
                var t = e.currentTarget.dataset.index;
                this.triggerEvent("click", {
                    index: t
                });
            },
            onChange: function(e) {
                var t = e.detail, r = t.current, n = t.source;
                this.setData({
                    navCurrent: r
                }), this.triggerEvent("change", {
                    current: r,
                    source: n
                });
            },
            onNavBtnChange: function(e) {
                var t = e.detail, r = t.dir, n = t.source;
                this.doNavBtnChange(r, n);
            },
            doNavBtnChange: function(e, t) {
                var r = this.data, n = r.current, i = r.list, a = r.loop, o = i.length, c = "next" === e ? n + 1 : n - 1;
                (c = a ? "next" === e ? (n + 1) % o : (n - 1 + o) % o : c < 0 || c >= o ? n : c) !== n && (this.setData({
                    current: c
                }), this.triggerEvent("change", {
                    current: c,
                    source: t
                }));
            },
            onImageLoad: function(e) {
                this.triggerEvent("image-load", {
                    index: e.target.dataset.custom
                });
            }
        }, e;
    }
    return i(n, r), e(n);
}(o.SuperComponent);

h = f([ (0, o.wxComponent)() ], h);

exports.default = h;