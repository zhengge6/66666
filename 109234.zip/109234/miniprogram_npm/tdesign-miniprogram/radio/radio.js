Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), n = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), r = require("../../../@babel/runtime/helpers/getPrototypeOf"), o = require("../../../@babel/runtime/helpers/inherits"), a = require("../../../@babel/runtime/helpers/typeof"), i = s(require("../common/config")), l = require("../common/src/index"), c = s(require("./props"));

function s(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function u(e, t, o) {
    return t = r(t), n(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, o || [], r(e).constructor) : t.apply(e, o));
}

var d = function(e, t, n, r) {
    var o, i = arguments.length, l = i < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, n) : r;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : a(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(e, t, n, r); else for (var c = e.length - 1; c >= 0; c--) (o = e[c]) && (l = (i < 3 ? o(l) : i > 3 ? o(t, n, l) : o(t, n)) || l);
    return i > 3 && l && Object.defineProperty(t, n, l), l;
}, f = i.default.prefix, p = "".concat(f, "-radio"), h = function(n) {
    function r() {
        var e;
        return t(this, r), (e = u(this, r, arguments)).externalClasses = [ "".concat(f, "-class"), "".concat(f, "-class-label"), "".concat(f, "-class-icon"), "".concat(f, "-class-content"), "".concat(f, "-class-border") ], 
        e.behaviors = [ "wx://form-field" ], e.relations = {
            "../radio-group/radio-group": {
                type: "ancestor",
                linked: function(e) {
                    e.data.borderless && this.setData({
                        borderless: !0
                    });
                }
            }
        }, e.options = {
            multipleSlots: !0
        }, e.lifetimes = {
            attached: function() {
                this.init();
            }
        }, e.properties = Object.assign(Object.assign({}, c.default), {
            borderless: {
                type: Boolean,
                value: !1
            }
        }), e.controlledProps = [ {
            key: "checked",
            event: "change"
        } ], e.data = {
            prefix: f,
            classPrefix: p,
            customIcon: !1,
            slotIcon: !1,
            optionLinked: !1,
            iconVal: [],
            _placement: "",
            _disabled: !1
        }, e.observers = {
            disabled: function(e) {
                this.setData({
                    _disabled: e
                });
            }
        }, e.methods = {
            handleTap: function(e) {
                var t = this.data, n = t._disabled, r = t.readonly, o = t.contentDisabled, a = e.currentTarget.dataset.target;
                n || r || "text" === a && o || this.doChange();
            },
            doChange: function() {
                var e, t = this.data, n = t.value, r = t.checked, o = t.allowUncheck, a = Boolean(o || (null === (e = this.$parent) || void 0 === e ? void 0 : e.data.allowUncheck));
                this.$parent ? this.$parent.updateValue(r && a ? null : n) : this._trigger("change", {
                    checked: !a || !r
                });
            },
            init: function() {
                var e, t, n, r, o, a, i = this.data.icon, l = Array.isArray((null === (e = this.$parent) || void 0 === e ? void 0 : e.icon) || i);
                this.setData({
                    customIcon: l,
                    slotIcon: "slot" === i,
                    iconVal: l ? (null === (t = this.$parent) || void 0 === t ? void 0 : t.icon) || i : [],
                    _placement: null !== (a = null !== (n = this.data.placement) && void 0 !== n ? n : null === (o = null === (r = this.$parent) || void 0 === r ? void 0 : r.data) || void 0 === o ? void 0 : o.placement) && void 0 !== a ? a : "left"
                });
            },
            setDisabled: function(e) {
                this.setData({
                    _disabled: this.data.disabled || e
                });
            }
        }, e;
    }
    return o(r, n), e(r);
}(l.SuperComponent);

h = d([ (0, l.wxComponent)() ], h);

exports.default = h;