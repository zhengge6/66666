Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0, require("../../../@babel/runtime/helpers/Arrayincludes");

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), i = require("../../../@babel/runtime/helpers/inherits"), a = require("../../../@babel/runtime/helpers/typeof"), o = require("../common/src/index"), s = c(require("../common/config")), l = c(require("./props")), u = require("../common/utils");

function c(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function p(e, t, i) {
    return t = n(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, i || [], n(e).constructor) : t.apply(e, i));
}

var d = function(e, t, r, n) {
    var i, o = arguments.length, s = o < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : a(Reflect)) && "function" == typeof Reflect.decorate) s = Reflect.decorate(e, t, r, n); else for (var l = e.length - 1; l >= 0; l--) (i = e[l]) && (s = (o < 3 ? i(s) : o > 3 ? i(t, r, s) : i(t, r)) || s);
    return o > 3 && s && Object.defineProperty(t, r, s), s;
}, f = s.default.prefix, h = "".concat(f, "-collapse-panel"), b = function(r) {
    function n() {
        var e;
        return t(this, n), (e = p(this, n, arguments)).externalClasses = [ "".concat(f, "-class"), "".concat(f, "-class-content"), "".concat(f, "-class-header") ], 
        e.options = {
            multipleSlots: !0
        }, e.relations = {
            "../collapse/collapse": {
                type: "ancestor",
                linked: function(e) {
                    var t = e.properties, r = t.value, n = t.expandIcon, i = t.disabled;
                    this.setData({
                        ultimateExpandIcon: null == this.properties.expandIcon ? n : this.properties.expandIcon,
                        ultimateDisabled: null == this.properties.disabled ? i : this.properties.disabled
                    }), this.updateExpanded(r);
                }
            }
        }, e.properties = l.default, e.data = {
            prefix: f,
            expanded: !1,
            classPrefix: h,
            classBasePrefix: f,
            ultimateExpandIcon: !1,
            ultimateDisabled: !1
        }, e.observers = {
            disabled: function(e) {
                this.setData({
                    ultimateDisabled: !!e
                });
            }
        }, e.methods = {
            updateExpanded: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
                if (this.$parent) {
                    var t = this.properties.value, r = this.$parent.data.defaultExpandAll, n = r ? !this.data.expanded : e.includes(t);
                    n !== this.properties.expanded && (this.setData({
                        expanded: n
                    }), this.updateStyle(n));
                }
            },
            updateStyle: function(e) {
                var t = this;
                return (0, u.getRect)(this, ".".concat(h, "__content")).then(function(e) {
                    return e.height;
                }).then(function(r) {
                    var n = wx.createAnimation({
                        duration: 0,
                        timingFunction: "ease-in-out"
                    });
                    e ? n.height(r).top(0).step({
                        duration: 300
                    }).height("auto").step() : n.height(r).top(1).step({
                        duration: 1
                    }).height(0).step({
                        duration: 300
                    }), t.setData({
                        animation: n.export()
                    });
                });
            },
            onClick: function() {
                var e = this.data.ultimateDisabled, t = this.properties.value;
                e || (this.$parent.data.defaultExpandAll ? this.updateExpanded() : this.$parent.switch(t));
            }
        }, e;
    }
    return i(n, r), e(n);
}(o.SuperComponent);

b = d([ (0, o.wxComponent)() ], b);

exports.default = b;