Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    borderless: {
        type: Boolean,
        value: !1
    },
    disabled: {
        type: null,
        value: void 0
    },
    keys: {
        type: Object
    },
    max: {
        type: Number,
        value: void 0
    },
    name: {
        type: String,
        value: ""
    },
    options: {
        type: Array,
        value: []
    },
    value: {
        type: Array,
        value: null
    },
    defaultValue: {
        type: Array,
        value: []
    }
};

exports.default = e;