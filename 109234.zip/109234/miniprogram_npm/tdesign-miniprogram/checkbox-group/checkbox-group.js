Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0, require("../../../@babel/runtime/helpers/Arrayincludes");

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), n = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), i = require("../../../@babel/runtime/helpers/getPrototypeOf"), l = require("../../../@babel/runtime/helpers/inherits"), r = require("../../../@babel/runtime/helpers/typeof"), a = require("../common/src/index"), c = o(require("../common/config")), u = o(require("./props"));

function o(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function s(e, t, l) {
    return t = i(t), n(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, l || [], i(e).constructor) : t.apply(e, l));
}

var d = function(e, t, n, i) {
    var l, a = arguments.length, c = a < 3 ? t : null === i ? i = Object.getOwnPropertyDescriptor(t, n) : i;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : r(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, t, n, i); else for (var u = e.length - 1; u >= 0; u--) (l = e[u]) && (c = (a < 3 ? l(c) : a > 3 ? l(t, n, c) : l(t, n)) || c);
    return a > 3 && c && Object.defineProperty(t, n, c), c;
}, h = c.default.prefix, f = "".concat(h, "-checkbox-group"), v = function(n) {
    function i() {
        var e;
        return t(this, i), (e = s(this, i, arguments)).externalClasses = [ "".concat(h, "-class") ], 
        e.relations = {
            "../checkbox/checkbox": {
                type: "descendant"
            }
        }, e.data = {
            prefix: h,
            classPrefix: f,
            checkboxOptions: []
        }, e.properties = u.default, e.observers = {
            value: function() {
                this.updateChildren();
            },
            options: function() {
                this.initWithOptions();
            },
            disabled: function(e) {
                var t;
                (null === (t = this.data.options) || void 0 === t ? void 0 : t.length) ? this.initWithOptions() : this.getChildren().forEach(function(t) {
                    t.setDisabled(e);
                });
            }
        }, e.lifetimes = {
            ready: function() {
                this.setCheckall();
            }
        }, e.controlledProps = [ {
            key: "value",
            event: "change"
        } ], e.$checkAll = null, e.methods = {
            getChildren: function() {
                var e = this.$children;
                return e.length || (e = this.selectAllComponents(".".concat(h, "-checkbox-option"))), 
                e || [];
            },
            updateChildren: function() {
                var e = this.getChildren(), t = this.data.value;
                e.length > 0 && (e.forEach(function(e) {
                    !e.data.checkAll && e.setData({
                        checked: null == t ? void 0 : t.includes(e.data.value)
                    });
                }), e.some(function(e) {
                    return e.data.checkAll;
                }) && this.setCheckall());
            },
            updateValue: function(e) {
                var t = e.value, n = e.checked, i = e.checkAll, l = e.item, r = e.indeterminate, a = this.data.value, c = this.data.max, u = new Set(this.getChildren().map(function(e) {
                    return e.data.value;
                }));
                if (a = a.filter(function(e) {
                    return u.has(e);
                }), !c || !n || a.length !== c) {
                    if (i) {
                        var o = this.getChildren();
                        a = !n && r ? o.filter(function(e) {
                            var t = e.data;
                            return !(t.disabled && !a.includes(t.value));
                        }).map(function(e) {
                            return e.data.value;
                        }) : o.filter(function(e) {
                            var t = e.data;
                            return t.disabled ? a.includes(t.value) : n && !t.checkAll;
                        }).map(function(e) {
                            return e.data.value;
                        });
                    } else if (n) a = a.concat(t); else {
                        var s = a.findIndex(function(e) {
                            return e === t;
                        });
                        a.splice(s, 1);
                    }
                    this._trigger("change", {
                        value: a,
                        context: l
                    });
                }
            },
            initWithOptions: function() {
                var e = this.data, t = e.options, n = e.value, i = e.keys;
                if ((null == t ? void 0 : t.length) && Array.isArray(t)) {
                    var l = t.map(function(e) {
                        var t, l, a;
                        return [ "number", "string" ].includes(r(e)) ? {
                            label: "".concat(e),
                            value: e,
                            checked: null == n ? void 0 : n.includes(e)
                        } : Object.assign(Object.assign({}, e), {
                            label: e[null !== (t = null == i ? void 0 : i.label) && void 0 !== t ? t : "label"],
                            value: e[null !== (l = null == i ? void 0 : i.value) && void 0 !== l ? l : "value"],
                            checked: null == n ? void 0 : n.includes(e[null !== (a = null == i ? void 0 : i.value) && void 0 !== a ? a : "value"])
                        });
                    });
                    this.setData({
                        checkboxOptions: l
                    });
                }
            },
            handleInnerChildChange: function(e) {
                var t, n = e.target.dataset.item, i = e.detail.checked, l = {};
                n.checkAll && (l.indeterminate = null === (t = this.$checkAll) || void 0 === t ? void 0 : t.data.indeterminate), 
                this.updateValue(Object.assign(Object.assign(Object.assign({}, n), {
                    checked: i,
                    item: n
                }), l));
            },
            setCheckall: function() {
                var e = this, t = this.getChildren();
                if (this.$checkAll || (this.$checkAll = t.find(function(e) {
                    return e.data.checkAll;
                })), this.$checkAll) {
                    var n = this.data.value, i = new Set(null == n ? void 0 : n.filter(function(t) {
                        return t !== e.$checkAll.data.value;
                    })), l = t.every(function(e) {
                        return !!e.data.checkAll || i.has(e.data.value);
                    });
                    this.$checkAll.setData({
                        checked: i.size > 0,
                        indeterminate: !l
                    });
                }
            }
        }, e;
    }
    return l(i, n), e(i);
}(a.SuperComponent);

v = d([ (0, a.wxComponent)() ], v);

exports.default = v;