Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    actions: {
        type: Array
    },
    buttonLayout: {
        type: String,
        value: "horizontal"
    },
    cancelBtn: {
        type: null
    },
    closeBtn: {
        type: null,
        value: !1
    },
    closeOnOverlayClick: {
        type: Boolean,
        value: !1
    },
    confirmBtn: {
        type: null
    },
    content: {
        type: String
    },
    externalClasses: {
        type: Array
    },
    overlayProps: {
        type: Object,
        value: {}
    },
    preventScrollThrough: {
        type: Boolean,
        value: !0
    },
    showOverlay: {
        type: Boolean,
        value: !0
    },
    style: {
        type: String,
        value: ""
    },
    title: {
        type: String
    },
    visible: {
        type: Boolean
    },
    zIndex: {
        type: Number,
        value: 11500
    }
};

exports.default = e;