Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0, require("../../../@babel/runtime/helpers/Arrayincludes");

var t = require("../../../@babel/runtime/helpers/createClass"), e = require("../../../@babel/runtime/helpers/classCallCheck"), n = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), o = require("../../../@babel/runtime/helpers/getPrototypeOf"), r = require("../../../@babel/runtime/helpers/inherits"), c = require("../../../@babel/runtime/helpers/typeof"), i = require("../common/src/index"), a = f(require("../common/config")), s = f(require("./props")), l = require("../common/utils"), u = f(require("../mixins/using-custom-navbar"));

function f(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function p(t, e, r) {
    return e = o(e), n(t, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (t) {
            return !1;
        }
    }() ? Reflect.construct(e, r || [], o(t).constructor) : e.apply(t, r));
}

var h = function(t, e, n, o) {
    var r, i = arguments.length, a = i < 3 ? e : null === o ? o = Object.getOwnPropertyDescriptor(e, n) : o;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : c(Reflect)) && "function" == typeof Reflect.decorate) a = Reflect.decorate(t, e, n, o); else for (var s = t.length - 1; s >= 0; s--) (r = t[s]) && (a = (i < 3 ? r(a) : i > 3 ? r(e, n, a) : r(e, n)) || a);
    return i > 3 && a && Object.defineProperty(e, n, a), a;
}, b = a.default.prefix, d = "".concat(b, "-dialog"), g = function(n) {
    function o() {
        var t;
        return e(this, o), (t = p(this, o, arguments)).behaviors = [ u.default ], t.options = {
            multipleSlots: !0
        }, t.externalClasses = [ "".concat(b, "-class"), "".concat(b, "-class-content"), "".concat(b, "-class-confirm"), "".concat(b, "-class-cancel"), "".concat(b, "-class-action") ], 
        t.properties = s.default, t.data = {
            prefix: b,
            classPrefix: d,
            buttonVariant: "text"
        }, t.observers = {
            "confirmBtn, cancelBtn": function(t, e) {
                var n = this.data, o = n.prefix, r = n.classPrefix, i = n.buttonLayout, a = {
                    buttonVariant: "text"
                }, s = [ t, e ].some(function(t) {
                    return (0, l.isObject)(t) && t.variant && "text" !== t.variant;
                }), u = {
                    confirm: t,
                    cancel: e
                }, f = [ "".concat(r, "__button") ], p = [];
                s ? (a.buttonVariant = "base", f.push("".concat(r, "__button--").concat(i))) : (f.push("".concat(r, "__button--text")), 
                p.push("".concat(r, "-button"))), Object.keys(u).forEach(function(t) {
                    var e = u[t], n = {
                        block: !0,
                        class: [].concat(f, [ "".concat(r, "__button--").concat(t) ]),
                        externalClass: [].concat(p, [ "".concat(o, "-class-").concat(t) ]),
                        variant: a.buttonVariant,
                        openType: ""
                    };
                    "cancel" === t && "base" === a.buttonVariant && (n.theme = "light"), "string" == typeof e ? a["_".concat(t)] = Object.assign(Object.assign({}, n), {
                        content: e
                    }) : e && "object" === c(e) ? a["_".concat(t)] = Object.assign(Object.assign({}, n), e) : a["_".concat(t)] = null;
                }), this.setData(Object.assign({}, a));
            }
        }, t.methods = {
            onTplButtonTap: function(t) {
                var e, n, o, r = t.type, c = t.target.dataset, i = c.type, a = c.extra, s = this.data["_".concat(i)], u = "bind".concat(r);
                if ("action" !== i) {
                    if ("function" == typeof s[u]) s[u](t) && this.close();
                    if (!!!s.openType && [ "confirm", "cancel" ].includes(i) && (null === (e = this[(0, 
                    l.toCamel)("on-".concat(i))]) || void 0 === e || e.call(this, i)), "tap" !== r) {
                        var f = (null === (o = null === (n = t.detail) || void 0 === n ? void 0 : n.errMsg) || void 0 === o ? void 0 : o.indexOf("ok")) > -1;
                        this.triggerEvent(f ? "open-type-event" : "open-type-error-event", t.detail);
                    }
                } else this.onActionTap(a);
            },
            onConfirm: function() {
                this.triggerEvent("confirm"), this._onConfirm && (this._onConfirm(), this.close());
            },
            onCancel: function() {
                this.triggerEvent("close", {
                    trigger: "cancel"
                }), this.triggerEvent("cancel"), this._onCancel && (this._onCancel(), this.close());
            },
            onClose: function() {
                this.triggerEvent("close", {
                    trigger: "close-btn"
                }), this.close();
            },
            close: function() {
                this.setData({
                    visible: !1
                });
            },
            overlayClick: function() {
                this.properties.closeOnOverlayClick && (this.triggerEvent("close", {
                    trigger: "overlay"
                }), this.close()), this.triggerEvent("overlay-click");
            },
            onActionTap: function(t) {
                this.triggerEvent("action", {
                    index: t
                }), this._onAction && (this._onAction({
                    index: t
                }), this.close());
            },
            openValueCBHandle: function(t) {
                this.triggerEvent("open-type-event", t.detail);
            },
            openValueErrCBHandle: function(t) {
                this.triggerEvent("open-type-error-event", t.detail);
            }
        }, t;
    }
    return r(o, n), t(o);
}(i.SuperComponent);

g = h([ (0, i.wxComponent)() ], g);

exports.default = g;