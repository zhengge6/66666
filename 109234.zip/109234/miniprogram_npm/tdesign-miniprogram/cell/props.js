Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    align: {
        type: String,
        value: "middle"
    },
    arrow: {
        type: null,
        value: !1
    },
    bordered: {
        type: Boolean,
        value: !0
    },
    description: {
        type: String
    },
    hover: {
        type: Boolean
    },
    image: {
        type: String
    },
    jumpType: {
        type: String,
        value: "navigateTo"
    },
    leftIcon: {
        type: null
    },
    note: {
        type: String
    },
    required: {
        type: Boolean,
        value: !1
    },
    rightIcon: {
        type: null
    },
    title: {
        type: String
    },
    url: {
        type: String,
        value: ""
    }
};

exports.default = e;