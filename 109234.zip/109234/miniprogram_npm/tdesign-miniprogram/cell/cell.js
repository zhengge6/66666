Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/defineProperty"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/createClass"), n = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), c = require("../../../@babel/runtime/helpers/getPrototypeOf"), o = require("../../../@babel/runtime/helpers/inherits"), i = require("../../../@babel/runtime/helpers/typeof"), l = require("../common/src/index"), s = f(require("../common/config")), a = f(require("./props")), u = require("../common/utils");

function f(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function p(e, t, r) {
    return t = c(t), n(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, r || [], c(e).constructor) : t.apply(e, r));
}

var h = function(e, t, r, n) {
    var c, o = arguments.length, l = o < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : i(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(e, t, r, n); else for (var s = e.length - 1; s >= 0; s--) (c = e[s]) && (l = (o < 3 ? c(l) : o > 3 ? c(t, r, l) : c(t, r)) || l);
    return o > 3 && l && Object.defineProperty(t, r, l), l;
}, d = s.default.prefix, m = "".concat(d, "-cell"), b = function(n) {
    function c() {
        var e;
        return t(this, c), (e = p(this, c, arguments)).externalClasses = [ "".concat(d, "-class"), "".concat(d, "-class-title"), "".concat(d, "-class-description"), "".concat(d, "-class-note"), "".concat(d, "-class-hover"), "".concat(d, "-class-image"), "".concat(d, "-class-left"), "".concat(d, "-class-left-icon"), "".concat(d, "-class-center"), "".concat(d, "-class-right"), "".concat(d, "-class-right-icon") ], 
        e.relations = {
            "../cell-group/cell-group": {
                type: "parent"
            }
        }, e.options = {
            multipleSlots: !0
        }, e.properties = a.default, e.data = {
            prefix: d,
            classPrefix: m,
            isLastChild: !1
        }, e.observers = {
            leftIcon: function(e) {
                this.setIcon("_leftIcon", e, "");
            },
            rightIcon: function(e) {
                this.setIcon("_rightIcon", e, "");
            },
            arrow: function(e) {
                this.setIcon("_arrow", e, "chevron-right");
            }
        }, e;
    }
    return o(c, n), r(c, [ {
        key: "setIcon",
        value: function(t, r, n) {
            this.setData(e({}, t, (0, u.calcIcon)(r, n)));
        }
    }, {
        key: "onClick",
        value: function(e) {
            this.triggerEvent("click", e.detail), this.jumpLink();
        }
    }, {
        key: "jumpLink",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "url", t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "jumpType", r = this.data[e], n = this.data[t];
            r && wx[n]({
                url: r
            });
        }
    } ]);
}(l.SuperComponent);

b = h([ (0, l.wxComponent)() ], b);

exports.default = b;