Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), n = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), r = require("../../../@babel/runtime/helpers/getPrototypeOf"), i = require("../../../@babel/runtime/helpers/inherits"), a = require("../../../@babel/runtime/helpers/typeof"), l = s(require("../common/config")), o = require("../common/src/index"), u = s(require("./props"));

function s(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function c(e, t, i) {
    return t = r(t), n(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, i || [], r(e).constructor) : t.apply(e, i));
}

var d = function(e, t, n, r) {
    var i, l = arguments.length, o = l < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, n) : r;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : a(Reflect)) && "function" == typeof Reflect.decorate) o = Reflect.decorate(e, t, n, r); else for (var u = e.length - 1; u >= 0; u--) (i = e[u]) && (o = (l < 3 ? i(o) : l > 3 ? i(t, n, o) : i(t, n)) || o);
    return l > 3 && o && Object.defineProperty(t, n, o), o;
}, f = l.default.prefix, h = "".concat(f, "-radio-group"), p = function(n) {
    function r() {
        var e;
        return t(this, r), (e = c(this, r, arguments)).externalClasses = [ "".concat(f, "-class") ], 
        e.data = {
            prefix: f,
            classPrefix: h,
            radioOptions: []
        }, e.relations = {
            "../radio/radio": {
                type: "descendant",
                linked: function(e) {
                    var t = this.data, n = t.value, r = t.disabled;
                    e.setData({
                        checked: n === e.data.value
                    }), e.setDisabled(r);
                }
            }
        }, e.properties = u.default, e.controlledProps = [ {
            key: "value",
            event: "change"
        } ], e.observers = {
            value: function(e) {
                this.getChildren().forEach(function(t) {
                    t.setData({
                        checked: e === t.data.value
                    });
                });
            },
            options: function() {
                this.initWithOptions();
            },
            disabled: function(e) {
                var t;
                (null === (t = this.data.options) || void 0 === t ? void 0 : t.length) ? this.initWithOptions() : this.getChildren().forEach(function(t) {
                    t.setDisabled(e);
                });
            }
        }, e.methods = {
            getChildren: function() {
                var e = this.$children;
                return (null == e ? void 0 : e.length) || (e = this.selectAllComponents(".".concat(f, "-radio-option"))), 
                e;
            },
            updateValue: function(e) {
                this._trigger("change", {
                    value: e
                });
            },
            handleRadioChange: function(e) {
                var t = e.detail.checked, n = e.target.dataset, r = n.value, i = n.index, a = n.allowUncheck;
                this._trigger("change", !1 === t && a ? {
                    value: null,
                    index: i
                } : {
                    value: r,
                    index: i
                });
            },
            initWithOptions: function() {
                var e = this.data, t = e.options, n = e.value, r = e.keys, i = e.disabled;
                if ((null == t ? void 0 : t.length) && Array.isArray(t)) {
                    var l = [];
                    try {
                        t.forEach(function(e) {
                            var t, o, u, s = a(e);
                            "number" === s || "string" === s ? l.push({
                                label: "".concat(e),
                                value: e,
                                checked: n === e,
                                disabled: i
                            }) : "object" === s && l.push(Object.assign(Object.assign({}, e), {
                                label: e[null !== (t = null == r ? void 0 : r.label) && void 0 !== t ? t : "label"],
                                value: e[null !== (o = null == r ? void 0 : r.value) && void 0 !== o ? o : "value"],
                                checked: n === e[null !== (u = null == r ? void 0 : r.value) && void 0 !== u ? u : "value"],
                                disabled: e.disabled || i
                            }));
                        }), this.setData({
                            radioOptions: l
                        });
                    } catch (e) {
                        console.error("error", e);
                    }
                } else this.setData({
                    radioOptions: []
                });
            }
        }, e;
    }
    return i(r, n), e(r);
}(o.SuperComponent);

p = d([ (0, o.wxComponent)() ], p);

exports.default = p;