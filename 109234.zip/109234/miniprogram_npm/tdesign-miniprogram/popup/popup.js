Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), i = require("../../../@babel/runtime/helpers/inherits"), o = require("../../../@babel/runtime/helpers/typeof"), l = require("../common/src/index"), u = f(require("../common/config")), c = f(require("./props")), s = f(require("../mixins/transition")), a = f(require("../mixins/using-custom-navbar"));

function f(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function p(e, t, i) {
    return t = n(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, i || [], n(e).constructor) : t.apply(e, i));
}

var d = function(e, t, r, n) {
    var i, l = arguments.length, u = l < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : o(Reflect)) && "function" == typeof Reflect.decorate) u = Reflect.decorate(e, t, r, n); else for (var c = e.length - 1; c >= 0; c--) (i = e[c]) && (u = (l < 3 ? i(u) : l > 3 ? i(t, r, u) : i(t, r)) || u);
    return l > 3 && u && Object.defineProperty(t, r, u), u;
};

delete c.default.visible;

var b = u.default.prefix, h = "".concat(b, "-popup"), v = function(r) {
    function n() {
        var e;
        return t(this, n), (e = p(this, n, arguments)).externalClasses = [ "".concat(b, "-class"), "".concat(b, "-class-content") ], 
        e.behaviors = [ (0, s.default)(), a.default ], e.options = {
            multipleSlots: !0
        }, e.properties = c.default, e.data = {
            prefix: b,
            classPrefix: h
        }, e.methods = {
            handleOverlayClick: function() {
                this.properties.closeOnOverlayClick && this.triggerEvent("visible-change", {
                    visible: !1,
                    trigger: "overlay"
                });
            },
            handleClose: function() {
                this.triggerEvent("visible-change", {
                    visible: !1,
                    trigger: "close-btn"
                });
            }
        }, e;
    }
    return i(n, r), e(n);
}(l.SuperComponent);

v = d([ (0, l.wxComponent)() ], v);

exports.default = v;