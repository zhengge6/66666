Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../../@babel/runtime/helpers/createClass"), r = require("../../../@babel/runtime/helpers/classCallCheck"), n = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), o = require("../../../@babel/runtime/helpers/getPrototypeOf"), i = require("../../../@babel/runtime/helpers/inherits"), c = require("../../../@babel/runtime/helpers/typeof"), s = require("../common/src/index"), u = f(require("../common/config")), a = f(require("./props")), l = require("../common/utils");

function f(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function p(e, t, r) {
    return t = o(t), n(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, r || [], o(e).constructor) : t.apply(e, r));
}

var d = function(e, t, r, n) {
    var o, i = arguments.length, s = i < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : c(Reflect)) && "function" == typeof Reflect.decorate) s = Reflect.decorate(e, t, r, n); else for (var u = e.length - 1; u >= 0; u--) (o = e[u]) && (s = (i < 3 ? o(s) : i > 3 ? o(t, r, s) : o(t, r)) || s);
    return i > 3 && s && Object.defineProperty(t, r, s), s;
}, h = function(e, t, r, n) {
    return new (r || (r = Promise))(function(o, i) {
        function c(e) {
            try {
                u(n.next(e));
            } catch (e) {
                i(e);
            }
        }
        function s(e) {
            try {
                u(n.throw(e));
            } catch (e) {
                i(e);
            }
        }
        function u(e) {
            var t;
            e.done ? o(e.value) : (t = e.value, t instanceof r ? t : new r(function(e) {
                e(t);
            })).then(c, s);
        }
        u((n = n.apply(e, t || [])).next());
    });
}, m = u.default.prefix, b = "".concat(m, "-icon"), y = function(n) {
    function o() {
        var t;
        return r(this, o), (t = p(this, o, arguments)).externalClasses = [ "".concat(m, "-class") ], 
        t.properties = a.default, t.data = {
            componentPrefix: m,
            classPrefix: b,
            isImage: !1,
            iconStyle: void 0
        }, t.observers = {
            "name, color, size, style": function() {
                this.setIconStyle();
            }
        }, t.methods = {
            onTap: function(e) {
                this.triggerEvent("click", e.detail);
            },
            setIconStyle: function() {
                return h(this, void 0, void 0, e().mark(function t() {
                    var r, n, o, i, c, s, u, a, f, p, d, h, m;
                    return e().wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (r = this.data, n = r.name, o = r.color, i = r.size, c = r.classPrefix, s = -1 !== n.indexOf("/"), 
                            u = (0, l.addUnit)(i), a = o ? {
                                color: o
                            } : {}, f = i ? {
                                "font-size": u
                            } : {}, p = Object.assign(Object.assign({}, a), f), !s) {
                                e.next = 14;
                                break;
                            }
                            return e.next = 9, (0, l.getRect)(this, ".".concat(c));

                          case 9:
                            d = e.sent, h = d.height, m = u || (0, l.addUnit)(h), p.width = m, p.height = m;

                          case 14:
                            this.setData({
                                isImage: s,
                                iconStyle: "".concat((0, l.styles)(p))
                            });

                          case 15:
                          case "end":
                            return e.stop();
                        }
                    }, t, this);
                }));
            }
        }, t;
    }
    return i(o, n), t(o);
}(s.SuperComponent);

y = d([ (0, s.wxComponent)() ], y);

exports.default = y;