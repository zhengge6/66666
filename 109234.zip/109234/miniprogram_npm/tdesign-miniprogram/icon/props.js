Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    color: {
        type: String,
        value: ""
    },
    name: {
        type: String,
        value: "",
        required: !0
    },
    prefix: {
        type: String,
        value: ""
    },
    size: {
        type: null
    }
};

exports.default = e;