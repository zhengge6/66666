Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), o = require("../../../@babel/runtime/helpers/inherits"), i = require("../../../@babel/runtime/helpers/typeof"), c = require("../common/src/index"), u = a(require("../common/config")), l = a(require("./props"));

function a(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function s(e, t, o) {
    return t = n(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, o || [], n(e).constructor) : t.apply(e, o));
}

var f = function(e, t, r, n) {
    var o, c = arguments.length, u = c < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : i(Reflect)) && "function" == typeof Reflect.decorate) u = Reflect.decorate(e, t, r, n); else for (var l = e.length - 1; l >= 0; l--) (o = e[l]) && (u = (c < 3 ? o(u) : c > 3 ? o(t, r, u) : o(t, r)) || u);
    return c > 3 && u && Object.defineProperty(t, r, u), u;
}, p = u.default.prefix, d = "".concat(p, "-grid"), h = function(r) {
    function n() {
        var e;
        return t(this, n), (e = s(this, n, arguments)).externalClasses = [ "t-class" ], 
        e.relations = {
            "../grid-item/grid-item": {
                type: "descendant"
            }
        }, e.properties = l.default, e.data = {
            prefix: p,
            classPrefix: d,
            contentStyle: ""
        }, e.observers = {
            "column,hover,align,gutter,border": function() {
                this.updateContentStyle(), this.doForChild(function(e) {
                    return e.updateStyle();
                });
            }
        }, e.lifetimes = {
            attached: function() {
                this.updateContentStyle();
            }
        }, e.methods = {
            doForChild: function(e) {
                this.$children.forEach(e);
            },
            updateContentStyle: function() {
                var e = [], t = this.getContentMargin();
                t && e.push(t), this.setData({
                    contentStyle: e.join(";")
                });
            },
            getContentMargin: function() {
                var e = this.properties.gutter, t = this.properties.border;
                if (!t) return "margin-left:-".concat(e, "rpx; margin-top:-").concat(e, "rpx");
                (0, c.isObject)(t) || (t = {});
                var r = t.width, n = void 0 === r ? 2 : r;
                return "margin-left:-".concat(n, "rpx; margin-top:-").concat(n, "rpx");
            }
        }, e;
    }
    return o(n, r), e(n);
}(c.SuperComponent);

h = f([ (0, c.wxComponent)() ], h);

exports.default = h;