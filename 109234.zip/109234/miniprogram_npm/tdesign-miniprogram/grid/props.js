Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    align: {
        type: String,
        value: "center"
    },
    border: {
        type: null,
        value: !1
    },
    column: {
        type: Number,
        value: 4
    },
    gutter: {
        type: Number
    },
    hover: {
        type: Boolean,
        value: !1
    },
    theme: {
        type: String,
        value: "default"
    }
};

exports.default = e;