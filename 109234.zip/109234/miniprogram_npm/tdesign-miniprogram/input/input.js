Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), i = require("../../../@babel/runtime/helpers/getPrototypeOf"), n = require("../../../@babel/runtime/helpers/inherits"), a = require("../../../@babel/runtime/helpers/typeof"), c = require("../common/src/index"), o = u(require("../common/config")), s = u(require("./props")), l = require("../common/utils");

function u(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function f(e, t, n) {
    return t = i(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, n || [], i(e).constructor) : t.apply(e, n));
}

var h = function(e, t, r, i) {
    var n, c = arguments.length, o = c < 3 ? t : null === i ? i = Object.getOwnPropertyDescriptor(t, r) : i;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : a(Reflect)) && "function" == typeof Reflect.decorate) o = Reflect.decorate(e, t, r, i); else for (var s = e.length - 1; s >= 0; s--) (n = e[s]) && (o = (c < 3 ? n(o) : c > 3 ? n(t, r, o) : n(t, r)) || o);
    return c > 3 && o && Object.defineProperty(t, r, o), o;
}, p = o.default.prefix, d = "".concat(p, "-input"), g = function(r) {
    function i() {
        var e;
        return t(this, i), (e = f(this, i, arguments)).options = {
            multipleSlots: !0
        }, e.externalClasses = [ "".concat(p, "-class"), "".concat(p, "-class-prefix-icon"), "".concat(p, "-class-label"), "".concat(p, "-class-input"), "".concat(p, "-class-clearable"), "".concat(p, "-class-suffix"), "".concat(p, "-class-suffix-icon"), "".concat(p, "-class-tips") ], 
        e.behaviors = [ "wx://form-field" ], e.properties = s.default, e.data = {
            prefix: p,
            classPrefix: d,
            classBasePrefix: p,
            showClearIcon: !0
        }, e.lifetimes = {
            ready: function() {
                var e, t = this.properties, r = t.value, i = t.defaultValue;
                this.updateValue(null !== (e = null != r ? r : i) && void 0 !== e ? e : "");
            }
        }, e.observers = {
            prefixIcon: function(e) {
                this.setData({
                    _prefixIcon: (0, l.calcIcon)(e)
                });
            },
            suffixIcon: function(e) {
                this.setData({
                    _suffixIcon: (0, l.calcIcon)(e)
                });
            },
            clearable: function(e) {
                this.setData({
                    _clearIcon: (0, l.calcIcon)(e, "close-circle-filled")
                });
            },
            clearTrigger: function() {
                this.updateClearIconVisible();
            }
        }, e.methods = {
            updateValue: function(e) {
                var t = this.properties, r = t.maxcharacter, i = t.maxlength;
                if (r && r > 0 && !Number.isNaN(r)) {
                    var n = (0, l.getCharacterLength)("maxcharacter", e, r), a = n.length, c = n.characters;
                    this.setData({
                        value: c,
                        count: a
                    });
                } else if (i && i > 0 && !Number.isNaN(i)) {
                    var o = (0, l.getCharacterLength)("maxlength", e, i), s = o.length, u = o.characters;
                    this.setData({
                        value: u,
                        count: s
                    });
                } else this.setData({
                    value: e,
                    count: (0, l.isDef)(e) ? String(e).length : 0
                });
            },
            updateClearIconVisible: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], t = this.properties.clearTrigger;
                this.setData({
                    showClearIcon: e || "always" === t
                });
            },
            onInput: function(e) {
                var t = e.detail, r = t.value, i = t.cursor, n = t.keyCode;
                this.updateValue(r), this.triggerEvent("change", {
                    value: this.data.value,
                    cursor: i,
                    keyCode: n
                });
            },
            onFocus: function(e) {
                this.updateClearIconVisible(!0), this.triggerEvent("focus", e.detail);
            },
            onBlur: function(e) {
                if (this.updateClearIconVisible(), "function" == typeof this.properties.format) {
                    var t = this.properties.format(e.detail.value);
                    return this.updateValue(t), void this.triggerEvent("blur", {
                        value: this.data.value,
                        cursor: this.data.count
                    });
                }
                this.triggerEvent("blur", e.detail);
            },
            onConfirm: function(e) {
                this.triggerEvent("enter", e.detail);
            },
            onSuffixClick: function() {
                this.triggerEvent("click", {
                    trigger: "suffix"
                });
            },
            onSuffixIconClick: function() {
                this.triggerEvent("click", {
                    trigger: "suffix-icon"
                });
            },
            clearInput: function(e) {
                this.triggerEvent("clear", e.detail), this.setData({
                    value: ""
                });
            },
            onKeyboardHeightChange: function(e) {
                this.triggerEvent("keyboardheightchange", e.detail);
            },
            onNickNameReview: function(e) {
                this.triggerEvent("nicknamereview", e.detail);
            }
        }, e;
    }
    return n(i, r), e(i);
}(c.SuperComponent);

g = h([ (0, c.wxComponent)() ], g);

exports.default = g;