Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/slicedToArray");

require("../../../@babel/runtime/helpers/Arrayincludes");

require("../../../@babel/runtime/helpers/readOnlyError");

var t = require("../../../@babel/runtime/helpers/toConsumableArray"), i = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/createClass"), a = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), s = require("../../../@babel/runtime/helpers/inherits"), o = require("../../../@babel/runtime/helpers/typeof"), c = require("../common/src/index"), l = f(require("./props")), u = f(require("../common/config")), d = require("../common/utils");

function f(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function h(e, t, i) {
    return t = n(t), a(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, i || [], n(e).constructor) : t.apply(e, i));
}

var g = function(e, t, i, r) {
    var a, n = arguments.length, s = n < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, i) : r;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : o(Reflect)) && "function" == typeof Reflect.decorate) s = Reflect.decorate(e, t, i, r); else for (var c = e.length - 1; c >= 0; c--) (a = e[c]) && (s = (n < 3 ? a(s) : n > 3 ? a(t, i, s) : a(t, i)) || s);
    return n > 3 && s && Object.defineProperty(t, i, s), s;
}, p = function(e, t) {
    var i = {};
    for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (i[r] = e[r]);
    if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
        var a = 0;
        for (r = Object.getOwnPropertySymbols(e); a < r.length; a++) t.indexOf(r[a]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[a]) && (i[r[a]] = e[r[a]]);
    }
    return i;
}, m = u.default.prefix, v = "".concat(m, "-upload"), y = function(a) {
    function n() {
        var e;
        return i(this, n), (e = h(this, n, arguments)).externalClasses = [ "".concat(m, "-class") ], 
        e.options = {
            multipleSlots: !0
        }, e.data = {
            classPrefix: v,
            prefix: m,
            current: !1,
            proofs: [],
            customFiles: [],
            customLimit: 0,
            column: 4,
            dragBaseData: {},
            rows: 0,
            dragWrapStyle: "",
            dragList: [],
            dragging: !0,
            dragLayout: !1
        }, e.properties = l.default, e.controlledProps = [ {
            key: "files",
            event: "success"
        } ], e.observers = {
            "files, max, draggable": function(e, t) {
                this.handleLimit(e, t);
            },
            gridConfig: function() {
                this.updateGrid();
            }
        }, e.lifetimes = {
            ready: function() {
                this.handleLimit(this.data.customFiles, this.data.max), this.updateGrid();
            }
        }, e.methods = {
            uploadFiles: function(e) {
                var t = this;
                return new Promise(function(i) {
                    var r = t.data.requestMethod(e);
                    if (r instanceof Promise) return r;
                    i({});
                });
            },
            startUpload: function(e) {
                var t = this;
                return "function" == typeof this.data.requestMethod ? this.uploadFiles(e).then(function() {
                    e.forEach(function(e) {
                        e.percent = 100;
                    }), t.triggerSuccessEvent(e);
                }).catch(function(e) {
                    t.triggerFailEvent(e);
                }) : (this.triggerSuccessEvent(e), this.handleLimit(this.data.customFiles, this.data.max), 
                Promise.resolve());
            },
            onAddTap: function() {
                var e = this.properties, t = e.disabled, i = e.mediaType, r = e.source;
                t || ("media" === r ? this.chooseMedia(i) : this.chooseMessageFile(i));
            },
            chooseMedia: function(e) {
                var t = this, i = this.data, r = i.config, a = i.sizeLimit, n = i.customLimit;
                wx.chooseMedia(Object.assign(Object.assign({
                    count: n,
                    mediaType: e
                }, r), {
                    success: function(i) {
                        var r = [];
                        i.tempFiles.forEach(function(i) {
                            var n = i.size, s = i.fileType, o = i.tempFilePath, c = i.width, l = i.height, u = i.duration, f = i.thumbTempFilePath, h = p(i, [ "size", "fileType", "tempFilePath", "width", "height", "duration", "thumbTempFilePath" ]);
                            if ((0, d.isOverSize)(n, a)) {
                                var g = "".concat("image" === s ? "图片" : "视频", "大小超过限制");
                                return "number" != typeof a && (g = a.message.replace("{sizeLimit}", null == a ? void 0 : a.size)), 
                                void wx.showToast({
                                    icon: "none",
                                    title: g
                                });
                            }
                            var m = t.getRandFileName(o);
                            r.push(Object.assign({
                                name: m,
                                type: t.getFileType(e, o, s),
                                url: o,
                                size: n,
                                width: c,
                                height: l,
                                duration: u,
                                thumb: f,
                                percent: 0
                            }, h));
                        }), t.afterSelect(r);
                    },
                    fail: function(e) {
                        t.triggerFailEvent(e);
                    },
                    complete: function(e) {
                        t.triggerEvent("complete", e);
                    }
                }));
            },
            chooseMessageFile: function(e) {
                var t = this, i = this.properties, r = i.max, a = i.config, n = i.sizeLimit;
                wx.chooseMessageFile(Object.assign(Object.assign({
                    count: r,
                    type: Array.isArray(e) ? "all" : e
                }, a), {
                    success: function(i) {
                        var r = [];
                        i.tempFiles.forEach(function(i) {
                            var a = i.size, s = i.type, o = i.path, c = p(i, [ "size", "type", "path" ]);
                            if ((0, d.isOverSize)(a, n)) {
                                var l = "".concat("image" === s ? "图片" : "视频", "大小超过限制");
                                return "number" != typeof n && (l = n.message.replace("{sizeLimit}", null == n ? void 0 : n.size)), 
                                void wx.showToast({
                                    icon: "none",
                                    title: l
                                });
                            }
                            var u = t.getRandFileName(o);
                            r.push(Object.assign({
                                name: u,
                                type: t.getFileType(e, o, s),
                                url: o,
                                size: a,
                                percent: 0
                            }, c));
                        }), t.afterSelect(r);
                    },
                    fail: function(e) {
                        return t.triggerFailEvent(e);
                    },
                    complete: function(e) {
                        return t.triggerEvent("complete", e);
                    }
                }));
            },
            afterSelect: function(e) {
                this._trigger("select-change", {
                    files: t(this.data.customFiles),
                    currentSelectedFiles: [ e ]
                }), this._trigger("add", {
                    files: e
                }), this.startUpload(e);
            },
            dragVibrate: function(e) {
                var t, i = e.vibrateType, r = this.data.draggable, a = null === (t = null == r ? void 0 : r.vibrate) || void 0 === t || t, n = null == r ? void 0 : r.collisionVibrate;
                (a && "longPress" === i || n && "touchMove" === i) && wx.vibrateShort({
                    type: "light"
                });
            },
            dragStatusChange: function(e) {
                var t = e.dragging;
                this.setData({
                    dragging: t
                });
            },
            dragEnd: function(e) {
                var t = e.dragCollisionList, i = [];
                i = 0 === t.length ? this.data.customFiles : t.reduce(function(e, t) {
                    var i = t.realKey, r = t.data;
                    return t.fixed || (e[i] = Object.assign({}, r)), e;
                }, []), this.triggerDropEvent(i);
            },
            triggerDropEvent: function(e) {
                var t = this, i = this.properties.transition;
                if (i.backTransition) var r = setTimeout(function() {
                    t.triggerEvent("drop", {
                        files: e
                    }), clearTimeout(r);
                }, i.duration); else this.triggerEvent("drop", {
                    files: e
                });
            }
        }, e;
    }
    return s(n, a), r(n, [ {
        key: "onProofTap",
        value: function(e) {
            var t;
            this.onFileClick(e);
            var i = e.currentTarget.dataset.index;
            wx.previewImage({
                urls: this.data.customFiles.filter(function(e) {
                    return -1 !== e.percent;
                }).map(function(e) {
                    return e.url;
                }),
                current: null === (t = this.data.customFiles[i]) || void 0 === t ? void 0 : t.url
            });
        }
    }, {
        key: "handleLimit",
        value: function(e, t) {
            0 === t && (t = 20), this.setData({
                customFiles: e.length > t ? e.slice(0, t) : e,
                customLimit: t - e.length,
                dragging: !0
            }), this.initDragLayout();
        }
    }, {
        key: "triggerSuccessEvent",
        value: function(e) {
            this._trigger("success", {
                files: [].concat(t(this.data.customFiles), t(e))
            });
        }
    }, {
        key: "triggerFailEvent",
        value: function(e) {
            this.triggerEvent("fail", e);
        }
    }, {
        key: "onFileClick",
        value: function(e) {
            var t = e.currentTarget.dataset.file;
            this.triggerEvent("click", {
                file: t
            });
        }
    }, {
        key: "getFileType",
        value: function(e, t, i) {
            if (i) return i;
            if (1 === e.length) return e[0];
            var r = t.split("."), a = r[r.length - 1];
            return [ "avi", "wmv", "mkv", "mp4", "mov", "rm", "3gp", "flv", "mpg", "rmvb" ].includes(a.toLocaleLowerCase()) ? "video" : "image";
        }
    }, {
        key: "getRandFileName",
        value: function(e) {
            var t = e.lastIndexOf("."), i = -1 === t ? "" : e.substr(t);
            return parseInt("".concat(Date.now()).concat(Math.floor(900 * Math.random() + 100)), 10).toString(36) + i;
        }
    }, {
        key: "onDelete",
        value: function(e) {
            var t = e.currentTarget.dataset.index;
            this.deleteHandle(t);
        }
    }, {
        key: "deleteHandle",
        value: function(e) {
            var t = this.data.customFiles[e];
            this.triggerEvent("remove", {
                index: e,
                file: t
            });
        }
    }, {
        key: "updateGrid",
        value: function() {
            var e = this.properties.gridConfig, t = void 0 === e ? {} : e;
            (0, c.isObject)(t) || (t = {});
            var i = t, r = i.column, a = void 0 === r ? 4 : r, n = i.width, s = void 0 === n ? 160 : n, o = i.height, l = void 0 === o ? 160 : o;
            this.setData({
                gridItemStyle: "width:".concat(s, "rpx;height:").concat(l, "rpx"),
                column: a
            });
        }
    }, {
        key: "initDragLayout",
        value: function() {
            var e = this.properties, t = e.draggable, i = e.disabled;
            t && !i && (this.initDragList(), this.initDragBaseData());
        }
    }, {
        key: "initDragList",
        value: function() {
            var e = 0, t = this.data, i = t.column, r = t.customFiles, a = t.customLimit, n = [];
            if (r.forEach(function(t, r) {
                n.push({
                    realKey: e,
                    sortKey: r,
                    tranX: "".concat(r % i * 100, "%"),
                    tranY: "".concat(100 * Math.floor(r / i), "%"),
                    data: Object.assign({}, t)
                }), e += 1;
            }), a > 0) {
                var s = n.length;
                n.push({
                    realKey: s,
                    sortKey: s,
                    tranX: "".concat(s % i * 100, "%"),
                    tranY: "".concat(100 * Math.floor(s / i), "%"),
                    fixed: !0
                });
            }
            this.data.rows = Math.ceil(n.length / i), this.setData({
                dragList: n
            });
        }
    }, {
        key: "initDragBaseData",
        value: function() {
            var t = this, i = this.data, r = i.classPrefix, a = i.rows, n = i.column;
            if (0 !== i.customFiles.length) {
                var s = this.createSelectorQuery(), o = ".".concat(r, " >>> .t-grid-item"), c = ".".concat(r, " >>> .t-grid");
                s.select(o).boundingClientRect(), s.select(c).boundingClientRect(), s.selectViewport().scrollOffset(), 
                s.exec(function(i) {
                    var s = e(i, 3), o = s[0], c = o.width, l = o.height, u = s[1], d = u.left, f = u.top, h = s[2].scrollTop, g = {
                        rows: a,
                        classPrefix: r,
                        itemWidth: c,
                        itemHeight: l,
                        wrapLeft: d,
                        wrapTop: f + h,
                        columns: n
                    }, p = "height: ".concat(a * l, "px");
                    t.setData({
                        dragBaseData: g,
                        dragWrapStyle: p,
                        dragLayout: !0
                    }, function() {
                        var e = setTimeout(function() {
                            t.setData({
                                dragging: !1
                            }), clearTimeout(e);
                        }, 0);
                    });
                });
            } else this.setData({
                dragBaseData: {},
                dragWrapStyle: "",
                dragLayout: !1
            });
        }
    } ]);
}(c.SuperComponent);

y = g([ (0, c.wxComponent)() ], y);

exports.default = y;