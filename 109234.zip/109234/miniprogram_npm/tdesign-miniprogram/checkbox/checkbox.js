Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), a = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), r = require("../../../@babel/runtime/helpers/getPrototypeOf"), c = require("../../../@babel/runtime/helpers/inherits"), s = require("../../../@babel/runtime/helpers/typeof"), n = require("../common/src/index"), l = o(require("../common/config")), i = o(require("./props"));

function o(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function d(e, t, c) {
    return t = r(t), a(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, c || [], r(e).constructor) : t.apply(e, c));
}

var u = function(e, t, a, r) {
    var c, n = arguments.length, l = n < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, a) : r;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : s(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(e, t, a, r); else for (var i = e.length - 1; i >= 0; i--) (c = e[i]) && (l = (n < 3 ? c(l) : n > 3 ? c(t, a, l) : c(t, a)) || l);
    return n > 3 && l && Object.defineProperty(t, a, l), l;
}, f = l.default.prefix, h = "".concat(f, "-checkbox"), b = function(a) {
    function r() {
        var e;
        return t(this, r), (e = d(this, r, arguments)).externalClasses = [ "".concat(f, "-class"), "".concat(f, "-class-label"), "".concat(f, "-class-icon"), "".concat(f, "-class-content"), "".concat(f, "-class-border") ], 
        e.behaviors = [ "wx://form-field" ], e.relations = {
            "../checkbox-group/checkbox-group": {
                type: "ancestor",
                linked: function(e) {
                    var t = e.data, a = t.value, r = t.disabled, c = t.borderless, s = new Set(a), n = s.has(this.data.value), l = {
                        _disabled: null == this.data.disabled ? r : this.data.disabled
                    };
                    c && (l.borderless = !0), l.checked = this.data.checked || n, this.data.checked && e.updateValue(this.data), 
                    this.data.checkAll && (l.checked = s.size > 0), this.setData(l);
                }
            }
        }, e.options = {
            multipleSlots: !0
        }, e.properties = Object.assign(Object.assign({}, i.default), {
            theme: {
                type: String,
                value: "default"
            }
        }), e.data = {
            prefix: f,
            classPrefix: h,
            _disabled: !1
        }, e.observers = {
            disabled: function(e) {
                this.setData({
                    _disabled: e
                });
            }
        }, e.controlledProps = [ {
            key: "checked",
            event: "change"
        } ], e.methods = {
            handleTap: function(e) {
                var t = this.data, a = t._disabled, r = t.readonly, c = t.contentDisabled, s = e.currentTarget.dataset.target;
                if (!(a || r || "text" === s && c)) {
                    var n = this.data, l = n.value, i = n.label, o = !this.data.checked, d = this.$parent;
                    d ? d.updateValue(Object.assign(Object.assign({}, this.data), {
                        checked: o,
                        item: {
                            label: i,
                            value: l,
                            checked: o
                        }
                    })) : this._trigger("change", {
                        context: {
                            value: l,
                            label: i
                        },
                        checked: o
                    });
                }
            },
            setDisabled: function(e) {
                this.setData({
                    _disabled: this.data.disabled || e
                });
            }
        }, e;
    }
    return c(r, a), e(r);
}(n.SuperComponent);

b = u([ (0, n.wxComponent)() ], b);

exports.default = b;