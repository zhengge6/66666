Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), r = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), n = require("../../../@babel/runtime/helpers/getPrototypeOf"), o = require("../../../@babel/runtime/helpers/inherits"), i = require("../../../@babel/runtime/helpers/typeof"), u = require("../common/src/index"), c = a(require("../common/config")), l = a(require("./props")), s = a(require("../mixins/transition")), f = a(require("../mixins/using-custom-navbar"));

function a(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function p(e, t, o) {
    return t = n(t), r(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, o || [], n(e).constructor) : t.apply(e, o));
}

var d = function(e, t, r, n) {
    var o, u = arguments.length, c = u < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : i(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, t, r, n); else for (var l = e.length - 1; l >= 0; l--) (o = e[l]) && (c = (u < 3 ? o(c) : u > 3 ? o(t, r, c) : o(t, r)) || c);
    return u > 3 && c && Object.defineProperty(t, r, c), c;
}, b = c.default.prefix, h = "".concat(b, "-overlay"), m = function(r) {
    function n() {
        var e;
        return t(this, n), (e = p(this, n, arguments)).properties = l.default, e.behaviors = [ (0, 
        s.default)(), f.default ], e.data = {
            prefix: b,
            classPrefix: h,
            computedStyle: "",
            _zIndex: 11e3
        }, e.observers = {
            backgroundColor: function(e) {
                this.setData({
                    computedStyle: e ? "background-color: ".concat(e, ";") : ""
                });
            },
            zIndex: function(e) {
                0 !== e && this.setData({
                    _zIndex: e
                });
            }
        }, e.methods = {
            handleClick: function() {
                this.triggerEvent("click", {
                    visible: !this.properties.visible
                });
            },
            noop: function() {}
        }, e;
    }
    return o(n, r), e(n);
}(u.SuperComponent);

m = d([ (0, u.wxComponent)() ], m);

exports.default = m;