Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    backgroundColor: {
        type: String,
        value: ""
    },
    duration: {
        type: Number,
        value: 300
    },
    preventScrollThrough: {
        type: Boolean,
        value: !0
    },
    zIndex: {
        type: Number,
        value: 11e3
    }
};

exports.default = e;