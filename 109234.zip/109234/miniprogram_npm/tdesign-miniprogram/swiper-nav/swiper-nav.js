Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e, t = require("../../../@babel/runtime/helpers/createClass"), r = require("../../../@babel/runtime/helpers/classCallCheck"), n = require("../../../@babel/runtime/helpers/possibleConstructorReturn"), o = require("../../../@babel/runtime/helpers/getPrototypeOf"), i = require("../../../@babel/runtime/helpers/inherits"), u = require("../../../@babel/runtime/helpers/typeof"), a = require("../common/src/index");

function l(e, t, r) {
    return t = o(t), n(e, function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        } catch (e) {
            return !1;
        }
    }() ? Reflect.construct(t, r || [], o(e).constructor) : t.apply(e, r));
}

var c = function(e, t, r, n) {
    var o, i = arguments.length, a = i < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
    if ("object" === ("undefined" == typeof Reflect ? "undefined" : u(Reflect)) && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, r, n); else for (var l = e.length - 1; l >= 0; l--) (o = e[l]) && (a = (i < 3 ? o(a) : i > 3 ? o(t, r, a) : o(t, r)) || a);
    return i > 3 && a && Object.defineProperty(t, r, a), a;
}, s = ((e = require("../common/config")) && e.__esModule ? e : {
    default: e
}).default.prefix, p = "".concat(s, "-swiper-nav"), f = function(e) {
    function n() {
        var e;
        return r(this, n), (e = l(this, n, arguments)).externalClasses = [ "".concat(s, "-class") ], 
        e.properties = {
            current: {
                type: Number,
                value: 0
            },
            total: {
                type: Number,
                value: 0
            },
            type: {
                type: String,
                value: "dots"
            },
            minShowNum: {
                type: Number,
                value: 2
            },
            showControls: {
                type: Boolean,
                value: !1
            },
            direction: {
                type: String,
                value: "horizontal"
            },
            paginationPosition: {
                type: String,
                value: "bottom"
            }
        }, e.relations = {
            "../swiper/swiper": {
                type: "parent"
            }
        }, e.data = {
            prefix: s,
            classPrefix: p
        }, e.methods = {
            nav: function(e) {
                var t, r = e.target.dataset.dir;
                this.triggerEvent("nav-btn-change", {
                    dir: r,
                    source: "nav"
                }), this.$parent && (null === (t = this.$parent) || void 0 === t || t.doNavBtnChange(r, "nav"));
            }
        }, e;
    }
    return i(n, e), t(n);
}(a.SuperComponent);

f = c([ (0, a.wxComponent)() ], f);

exports.default = f;